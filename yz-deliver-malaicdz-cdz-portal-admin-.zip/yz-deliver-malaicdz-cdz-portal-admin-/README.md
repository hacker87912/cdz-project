# 项目名称

cdz-portal-admin
cdz运营管理后台系统

# 安装依赖
npm install

# 运行项目
npm run dev

# 构建项目
npm run build

# 项目结构说明

public: 静态资源服务的文件夹

src: 开发资源目录

babel.config.js：babel配置

postcss.config.js：postcss配置

vite.config.js：vite配置

.eslint.js：eslint配置

package.json： 项目依赖配置文件

README.md：项目说明文档

# src目录详解


* assets: 静态资源(图片及文档等)

* locales: 国际化翻译文件

* components: 公共组件

* router: 路由配置

* store: 状态管理

* services: 请求接口定义

* styles: 全局样式及字体

* utils: 自定义工具类

* pages: 页面组件

* App.js: app组件

* i18.js: 国际化配置

* main.js: 入口文件

# 注意事项

1. 增加模块和文件尽量保持目录结构清晰。

2. 在src/pages文件下新建自己的业务模块。

3. 在scr/services/中定义相关接口请求。

4. 在router/config中配置相关前端路由。

4. 在store/下面添加全局状态数据导出到index。

# React相关文档API

react官方文档: https://zh-hans.reactjs.org/

react-router官方文档: https://reactrouter.com/en/main

mobx官方文档: https://mobx.js.org/README.html

ant-design官方文档: https://ant.design/index-cn

vite官方文档：https://cn.vitejs.dev/

