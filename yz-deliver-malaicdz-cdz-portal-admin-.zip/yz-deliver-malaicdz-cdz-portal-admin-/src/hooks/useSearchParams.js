import { useMemo } from 'react'
import { useSearchParams as _useSearchParams } from 'react-router-dom'

export default function useSearchParams (defaultInit) {
  const [_searchParams, _setSearchParams] = _useSearchParams(defaultInit)

  const searchParams = useMemo(() => {
    return Array.from(_searchParams.entries()).reduce((pre, cur) => {
      const [key, value] = cur
      if (!value) return pre
      return { ...pre, [key]: value }
    }, {})
  }, [_searchParams])

  const setSearchParams = (e) => {
    Object.entries(e).forEach((item) => {
      const [key, value] = item
      if (!value) {
        delete e[key]
      }
    })
    _setSearchParams(e)
  }

  return [searchParams, setSearchParams]
}
