import { useEffect, useRef } from 'react'
import useSearchParams from '@/hooks/useSearchParams'

export default function useUpdateEffect (fn, inputs, init, getData) {
  const [searchParams, setSearchParams] = useSearchParams()
  const didMountRef = useRef(false)
  const oldParams = useRef({})

  useEffect(() => {
    const state = JSON.stringify(searchParams) === '{}'
    if (state) {
      const initValue = init()
      if (JSON.stringify(oldParams.current) === JSON.stringify(initValue)) {
        getData()
        return
      }
      didMountRef.current = false
    } else {
      didMountRef.current = true
    }
    oldParams.current = searchParams
  }, [searchParams])

  useEffect(() => {
    const state = fn(didMountRef.current)
    if (!didMountRef.current && state) {
      didMountRef.current = true
      setSearchParams({})
    }
  }, inputs)
}
