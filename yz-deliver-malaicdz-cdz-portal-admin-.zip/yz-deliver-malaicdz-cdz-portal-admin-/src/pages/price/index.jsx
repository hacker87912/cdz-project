import React, { useState, useEffect } from 'react'
import { Modal, Card, Table, Typography, Input, Button, Space, Row, Switch, message } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import ProductModal from './components/priceModal'
import Layout from '@/pages/expense/components/Layout'
import { getPrice, addPrice, editPrice, deletePrice, editPriceStatus, editPriceSort, priceDetail } from '@/services/price'
import { getProductClassifyList } from '@/services/product'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import { useTranslation } from 'react-i18next'
import Title from '@/components/localeTitle'

const { Search } = Input
const { Link } = Typography
const { confirm } = Modal

function ProductList () {
  const { t } = useTranslation()
  const [dataSource, setDataSource] = useState([])
  const [formOpen, setFormOpen] = useState('')
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [loading, setLoading] = useState(false)
  const [productClassifyOptions, setProductClassifyOptions] = useState([])
  const [record, setRecord] = useState({})
  const [search, setSearch] = useState(searchParams.keyword || '')
  const [value, setValue] = useState(searchParams.keyword || '')
  const [isSort, setIsSort] = useState(false)

  const getProductClassifyData = async () => {
    const { data = [] } = await getProductClassifyList()
    setProductClassifyOptions((data).map(e => ({ label: `${e.name}/${e.enName}`, value: e.id })))
  }

  useEffect(() => {
    getProductClassifyData()
  }, [])

  const getData = async () => {
    setLoading(true)
    const res =  await getPrice({
      current: current,
      size: pageSize,
      keyword: search
    })
    const { data: { records = [], total = 0 } = {} } = res
    setDataSource(records)
    setPaging((e => ({ ...e, total })))
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && current > totalPage) {
      setPaging((e => ({ ...e, current: totalPage })))
    }
    setLoading(false)
  }

  const init = () => {
    setPaging({ current: 1, pageSize: 10, total: 0 })
    setValue('')
    setSearch('')
    return { current: '1', pageSize: '10' }
  }

  useUpdateEffect((didMount) => {
    getData()
    didMount && setSearchParams({ current, pageSize, keyword: search })
    return true
  }, [current, pageSize, search], init, getData)

  const deleteConfirm = (id) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要删除?'),
      async onOk () {
        const res = await deletePrice(id)
        infoState(res)
      },
    })
  }

  const switchChange = (e, info) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要改变状态?'),
      async onOk () {
        const { id } = info
        const res = await editPriceStatus({ id, status: e ? 0 : 1 })
        infoState(res)
      },
    })
  }

  const columns = [
    {
      title: t('定价ID'),
      dataIndex: 'id',
      key: 'id',
      width: 200,
    },
    {
      title: t('定价产品分类'),
      dataIndex: 'productClassifyName',
      key: 'productClassifyName',
      width: 200,
      render: (_, record) => <Title name={record.productClassifyName} enName={record.productClassifyEnName} width={200} />
    },
    {
      title: t('定价产品'),
      dataIndex: 'productName',
      key: 'productName',
      width: 200,
      render: (_, record) => <Title name={record.productName} enName={record.productEnName} width={200} />
    },
    {
      title: t('是否显示'),
      dataIndex: 'status',
      key: 'status',
      render: (text, record) => (<Switch checked={!text} onChange={(e) => switchChange(e, record) } />)
    },
    {
      title: t('排序'),
      dataIndex: 'sort',
      key: 'sort',
    },
    {
      title: t('操作'),
      dataIndex: 'operation',
      key: 'operation',
      render: (_, _record) => (
        <Space>
          <Link onClick={() => formEdit(_record.id, 'edit')}>{t('编辑')}</Link>
          <Link onClick={() => formEdit(_record.id, 'sort')}>{t('排序')}</Link>
          <Link onClick={() => deleteConfirm(_record.id)}>{t('删除')}</Link>
        </Space>
      )
    },
  ]

  const formEdit = async (id, key) => {
    setLoading(true)
    const res = await priceDetail(id)
    setRecord(res.data || {})
    setFormOpen(key)
    if (key === 'sort') {
      setIsSort(true)
    }
    setLoading(false)
  }

  useEffect(() => {
    if (formOpen === 'add' || formOpen === 'edit') {
      setIsSort(false)
    }
  }, [formOpen])

  const infoState = (res) => {
    if (res.code === 0) {
      message.success(res.msg)
      getData()
    }
  }

  const add = async (values) => {
    delete values.id
    const res = await addPrice({ ...values })
    infoState(res)
  }

  const edit = async (values) => {
    const res = await editPrice({ ...values })
    infoState(res)
  }

  const editSort = async (values) => {
    const { id, sort } = values
    const res = await editPriceSort({ id, sort })
    infoState(res)
  }

  return (
    <Layout title={t('定价发布')}>
      <Card bordered={false}>
        <Row justify='space-between' style={{ marginBottom: '10px' }}>
          <Button type='primary' onClick={() => setFormOpen('add')}>{t('新增定价产品')}</Button>
          <Search
            enterButton
            placeholder={t('请输入你需要搜索的名称')}
            allowClear
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onSearch={(v) => { setPaging((e) => ({ ...e, current: 1 })); setSearch(v) }}
            style={{
              width: 300,
            }}
          />
        </Row>
        <Table
          loading={loading}
          rowKey="id"
          size='small'
          columns={columns}
          dataSource={dataSource}
          pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100], showTotal: total => `${t('共')} ${total} ${t('条')}` }}
          onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
        />
      </Card>
      <ProductModal
        open={formOpen}
        setOpen={setFormOpen}
        title={formOpen === 'add' ? t('新增') : (formOpen === 'edit' ? t('编辑') : (formOpen === 'sort' ? t('排序') : '')) }
        portFunc={formOpen === 'add' ? add : formOpen === 'edit' ? edit : editSort }
        productClassifyOptions={productClassifyOptions}
        record={record}
        isSort={isSort}
      />
    </Layout>
  )
}
export default ProductList
