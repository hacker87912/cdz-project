import React, { useEffect, useState } from 'react'
import { Modal, Form, Input, Switch, InputNumber, Select, Typography, Row } from 'antd'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { getClassifyProduct } from '@/services/product'

const { Link } = Typography

function PriceModal ({ open, setOpen, title = '', record, portFunc = () => {}, productClassifyOptions, isSort }) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [form] = Form.useForm()
  const [confirmLoading, setConfirmLoading] = useState(false)
  const [productOptions, setProductOptions] = useState([])
  const [productLoading, setProductLoading] = useState(false)

  const getProductOptions = async (classify) => {
    if (!classify) {
      return
    }
    setProductLoading(true)
    const { data = [] } = await getClassifyProduct(classify)
    setProductOptions(data.map(e => ({ label: `${e.title}/${e.enTitle}`, value: e.id })))
    setProductLoading(false)
  }

  useEffect(() => {
    if (title === t('编辑') || title === t('排序')) {
      const { id, productClassify, title, tencentId, sort, status } = record
      form.setFieldsValue({ id, productClassify, title, tencentId, sort, status: status ? false : true })
    }
  }, [record, open])

  useEffect(() => {
    if (open === 'edit') {
      const { productClassify, productId } = record
      getProductOptions(productClassify).then(() => {
        form.setFieldValue('productId', productId)
      })
    }
  }, [record, open])

  const clear = () => {
    setConfirmLoading(false)
    setOpen(false)
    form.resetFields()
  }

  const onFinish = async (values) => {
    setConfirmLoading(true)
    values.status = values.status ? 0 : 1
    await portFunc({ ...values, id: form.getFieldValue('id') })
    clear()
  }
  const onOk = () => {
    form.submit()
  }

  const onValuesChange = (changedValues) => {
    const [key] = Object.keys(changedValues)
    if (key === 'status') {
      form.setFieldValue('status', changedValues['status'] ? 1 : 0)
    } else if (key === 'productClassify') {
      form.setFieldValue('productId', '')
      getProductOptions(changedValues[key])
    }
  }
  return (
    <>
      <Modal forceRender width={open === 'add' ? 900 : (open === 'edit' ? 900 : 600)} title={title} open={open} onOk={onOk} onCancel={clear} confirmLoading={confirmLoading} maskClosable={false}>
        <Form
          form={form}
          labelCol={{
            span: open === 'add' ? 7 : (open === 'edit' ? 7 : 6),
          }}
          style={{ padding: '20px 60px 20px 0'}}
          onFinish={onFinish}
          onValuesChange={onValuesChange}
          initialValues={{ status: 1 }}
        >
          {!isSort && (
            <>
              <Row style={{ marginLeft: '5px' }}>
                <Form.Item
                  style={{ flex: 1, marginRight: '5px', overflow: 'hidden' }}
                  label={t('定价产品分类')}
                  name="productClassify"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                  ]}
                >
                  <Select
                    style={{ flex: 1, marginRight: '5px' }}
                    options={productClassifyOptions}
                  />
                </Form.Item>
                <Link onClick={() => navigate('/cms/product/classify')} style={{ height: '30px', lineHeight: '30px' }}>{t('管理')}</Link>
              </Row>
              <Row style={{ marginLeft: '5px' }}>
                <Form.Item
                  style={{ flex: 1, marginRight: '5px', overflow: 'hidden' }}
                  label={t('定价产品')}
                  name="productId"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                  ]}
                >
                  <Select
                    style={{ flex: 1, marginRight: '5px' }}
                    options={productOptions}
                    loading={productLoading}
                  />
                </Form.Item>
                <Link onClick={() => navigate('/cms/product')} style={{ height: '30px', lineHeight: '30px' }}>{t('管理')}</Link>
              </Row>
              <Form.Item
                label={t('腾讯产品ID')}
                name="tencentId"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('是否显示')}
                name="status"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
            </>
          )}
          <Form.Item
            label={t('排序')}
            name="sort"
            help={t('输入数字，数字越小排在最前面')}
            rules={[
              {
                required: true,
                message: t('请必填')
              },
            ]}
          >
            <InputNumber style={{ width: '400px' }} />
          </Form.Item>
        </Form>
      </Modal>
    </>
  )
}
export default PriceModal
