import React, { useState } from 'react'
import { Tabs, Space, Card, Input, Button, Modal, Typography, Spin, message, Form } from 'antd'
import ContentTitle from '@/components/contentTitle'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import Editor from '@/components/editor'
import { serviceQuery, addService, policyQuery, addPolicy, versionQuery, addVersion, serviceDetail, policyDetail, versionDetail } from '@/services/documents'
import dayjs from 'dayjs'
import { useTranslation } from 'react-i18next'

const { TextArea } = Input
const { Paragraph, Text } = Typography

const detailApi = {
  'service': serviceDetail,
  'policy': policyDetail,
  'version': versionDetail
}
const getDataApi = {
  'service': serviceQuery,
  'policy': policyQuery,
  'version': versionQuery
}

function Document () {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [searchParams, setSearchParams] = useSearchParams()
  const [activeKey, setActiveKey] = useState(searchParams.tab || 'service')
  const [open, setOpen] = useState(false)
  const [confirmLoading, setConfirmLoading] = useState(false)
  const [loading, setLoading] = useState(false)

  const getData = async () => {
    setLoading(true)
    const res = await getDataApi[activeKey]()
    form.setFieldsValue({ data: res.data })
    setLoading(false)
  }

  const init = () => {
    setActiveKey('service')
    return { tab: 'service' }
  }

  useUpdateEffect((didMount) => {
    getData()
    didMount && setSearchParams({ tab: activeKey })
    return true
  }, [activeKey], init, getData)

  const style = { marginTop: '16px', border: '1px solid rgba(5, 5, 5, 0.06)', padding: '18px', maxHeight: '700px', overflow: 'auto' }
  const { data = {} } = form.getFieldsValue(true)
  const items = [
    {
      key: 'service',
      label: t('服务条款'),
      children: (
        <>
          {!loading && (
            <>
              <Text type="secondary">{t('最近一次更新')}：{dayjs(data.updateTime).format('YYYY-MM-DD HH:mm:ss')}</Text>
              <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.detail }} style={style} />
              <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.enDetail }} style={style} />
            </>
          )
          }
        </>
      ),
    },
    {
      key: 'policy',
      label: t('隐私政策'),
      children: (
        <>
          {!loading && (
            <>
              <Text type="secondary">{t('最近一次更新')}：{dayjs(data.updateTime).format('YYYY-MM-DD HH:mm:ss')}</Text>
              <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.detail }} style={style} />
              <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.enDetail }} style={style} />
            </>
          )
          }
        </>
      ),
    },
    {
      key: 'version',
      label: t('版本说明'),
      children: (!loading && <Paragraph>{data.detail}</Paragraph>),
    }
  ]

  const tabs = (e) => {
    setActiveKey(e)
    form.resetFields()
  }

  const tabEdit = async () => {
    setLoading(true)
    const { data: _data = {} } = await detailApi[activeKey](data.id)
    form.setFieldsValue({ detail: _data.detail, enDetail: _data.enDetail })
    setOpen(true)
    setLoading(false)
  }

  const tabBarExtraContent = (
    <Button type="link" onClick={tabEdit}>
      {t('编辑')}
    </Button>
  )

  const edit = async (values) => {
    const { enDetail, detail } = values
    let res
    if (activeKey === 'service') {
      res = await addService({ id: data.id, enDetail, detail })
    } else if (activeKey === 'policy') {
      res = await addPolicy({ id: data.id, enDetail, detail })
    } else {
      res = await addVersion({ id: data.id, detail })
    }
    return res
  }

  const handleOk = () => {
    form.submit()
  }

  const onFinish = (values) => {
    setConfirmLoading(true)
    edit(values).then((e) => {
      if (e.code === 0) {
        message.success(e.msg)
        getData()
      }
    })
    setConfirmLoading(false)
    setOpen(false)
  }

  const handleCancel = () => {
    setOpen(false)
  }

  return (
    <Spin spinning={loading}>
      <Space
        direction="vertical"
        size="middle"
        style={{ display: 'flex' }}
      >
        <ContentTitle title={t('条款政策版本维护')} />
        <Card bordered={false}>
          <Tabs activeKey={activeKey} items={items} onChange={tabs} tabBarExtraContent={tabBarExtraContent} />
        </Card>
        <Modal
          forceRender
          title={`${activeKey === 'service' ? t('服务条款') : activeKey === 'policy' ? t('隐私政策') : t('版本说明')}${t('编辑')}`}
          open={open}
          onOk={handleOk}
          confirmLoading={confirmLoading}
          onCancel={handleCancel}
          width={1000}
          maskClosable={false}
        >
          <Form
            form={form}
            onFinish={onFinish}
          >
            {(activeKey === 'service' || activeKey === 'policy') && (
              <>
                <Form.Item
                  label={t('中文')}
                  name="detail"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                    {
                      validator: (_, value) => {
                        if (value !== '<p><br></p>') {
                          return Promise.resolve()
                        }
                        return Promise.reject(new Error(t('请必填')))
                      },
                      validateTrigger: 'onBlur'
                    },
                  ]}
                >
                  <Editor />
                </Form.Item>
                <Form.Item
                  label={t('英文')}
                  name="enDetail"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                    {
                      validator: (_, value) => {
                        if (value !== '<p><br></p>') {
                          return Promise.resolve()
                        }
                        return Promise.reject(new Error(t('请必填')))
                      },
                      validateTrigger: 'onBlur'
                    },
                  ]}
                >
                  <Editor />
                </Form.Item>
              </>
            )}
            {activeKey === 'version' && (
              <>
                <Form.Item
                  label={t('版本说明')}
                  name="detail"
                  rules={[
                    {
                      required: true,
                      whitespace: true,
                      message: t('请必填')
                    },
                  ]}
                >
                  <TextArea autoSize={{ minRows: 2, maxRows: 6 }} maxLength={100} />
                </Form.Item>
              </>
            )}
          </Form>
        </Modal>
      </Space>
    </Spin>
  )
}

export default Document
