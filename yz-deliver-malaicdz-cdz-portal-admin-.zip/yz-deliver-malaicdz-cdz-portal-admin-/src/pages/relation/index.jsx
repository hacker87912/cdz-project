import React, { useState } from 'react'
import { Card, DatePicker, Table, Button, Row } from 'antd'
import Layout from '@/pages/expense/components/Layout'
import { getRecordList, getRecordListExport } from '@/services/relation'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import dayjs from 'dayjs'
import { DownloadOutlined } from '@ant-design/icons'
import { useTranslation } from 'react-i18next'
import Title from '@/components/localeTitle'

const { RangePicker } = DatePicker

function SearchTableBox ({ columns, dataSource, paging, setPaging = () => {}, loading, date, dateChange, handleExportCurrentExcel }) {
  const { t } = useTranslation()
  const [startDate, endDate] = date
  return (
    <>
      <Row justify='space-between'>
        <RangePicker
          allowClear
          showTime
          value={[startDate ? dayjs(startDate) : '',endDate ? dayjs(endDate) : '']}
          onChange={(_, e) => { setPaging((e) => ({ ...e, current: 1 })); dateChange(e) }} />
        <Button type="link" icon={<DownloadOutlined />} onClick={handleExportCurrentExcel} />
      </Row>
      <Table
        loading={loading}
        style={{ marginTop: '16px' }}
        rowKey="id"
        size='small'
        columns={columns}
        dataSource={dataSource}
        pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100], showTotal: total => `${t('共')} ${total} ${t('条')}` }}
        onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
      />
    </>
  )
}

function LogList () {
  const { t } = useTranslation()
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [loading, setLoading] = useState(false)
  const [list, setList] = useState([])
  const [date, setDate] = useState([searchParams.startDate || '', searchParams.endDate || ''])

  const getData = async () => {
    const [startDate, endDate] = date
    const res = await getRecordList({
      current: current,
      size: pageSize,
      startTime: startDate,
      endTime: endDate,
    })
    const { data: { records = [], total = 0 } = {} } = res
    setList(records)
    setPaging((e => ({ ...e, total })))
    setLoading(false)
  }

  const init = () => {
    setPaging({ current: 1, pageSize: 10, total: 0 })
    setDate(['', ''])
    return { current: '1', pageSize: '10' }
  }

  useUpdateEffect((didMount) => {
    setLoading(true)
    getData()
    didMount && setSearchParams({ current, pageSize, startDate: date[0], endDate: date[1] })
    return true
  }, [current, pageSize, JSON.stringify(date)], init, getData)

  const columns = [
    { title: t('序号'), dataIndex: 'id', key: 'id', render: (text, record, index) => <span>{(current - 1) * pageSize + index + 1}</span>, width: 70 },
    { title: t('姓名'), dataIndex: 'fullName', key: 'fullName', width: 100, render: (text) => <Title name={text} width={80} /> },
    { title: t('电子邮件'), dataIndex: 'mail', key: 'mail', width: 130, render: (text) => <Title name={text} width={130} /> },
    { title: t('联系电话'), dataIndex: 'phone', key: 'phone', width: 130, render: (text) => <Title name={text} width={130} /> },
    { title: t('公司'), dataIndex: 'company', key: 'company', width: 300, render: (text) => <Title name={text} width={200} /> },
    { title: t('留言内容'), dataIndex: 'remark', key: 'remark', width: 300, render: (text) => <Title name={text} width={250} /> },
    { title: t('留言时间'), dataIndex: 'createTime', key: 'createTime', width: 150, render: (text) => <Title name={text} width={250} /> },
  ]

  // 下载文件流
  const downLoadFile = (blob, fileName) => {
    if (window.navigator.msSaveOrOpenBlob) { // IE10
      navigator.msSaveBlob(blob, fileName)
    } else {
      let link = document.createElement('a')
      link.style.display = 'none'
      link.href = URL.createObjectURL(blob)
      link.download = fileName
      link.click()
      URL.revokeObjectURL(link.href)
    }
  }

  const handleExportCurrentExcel = async () => {
    const [startTime, endTime] = date
    const res = await getRecordListExport({ startTime, endTime })
    const blob = new Blob([res], {type: 'application/vnd.ms-excel'})
    console.log(blob)
    const fileName = `${t('联系记录')}-${dayjs().format('YYYY-MM-DD HH:mm:ss')}.xlsx`
    downLoadFile(blob, fileName)
  }

  return (
    <Layout title={t('联系记录')}>
      <Card bordered={false}>
        <SearchTableBox
          loading={loading}
          columns={columns}
          dataSource={list}
          paging={paging}
          setPaging={setPaging}
          date={date}
          dateChange={setDate}
          handleExportCurrentExcel={handleExportCurrentExcel}
        />
      </Card>
    </Layout>
  )
}
export default LogList
