import React from 'react'
import { Space } from 'antd'
import ContentTitle from '@/components/contentTitle'

export default function Layout ({ children, title, showBack, path }) {
  return (
    <Space
      direction="vertical"
      size="middle"
      style={{ display: 'flex' }}
    >
      <ContentTitle showBack={showBack} title={title} path={path} />
      {children}
    </Space>
  )
}
