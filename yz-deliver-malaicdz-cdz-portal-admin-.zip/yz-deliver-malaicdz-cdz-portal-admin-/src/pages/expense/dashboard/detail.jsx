import React from 'react'
import { Card, Typography, List, Row, Col } from 'antd'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'

const { Title, Link } = Typography

const data = [
  { name: '腾讯' , amount: '1000000' },
  { name: '腾讯2' , amount: '1000000' },
  { name: '腾讯3' , amount: '1000000' },
  { name: '腾讯4' , amount: '1000000' },
]

function Detail () {
  const navigate = useNavigate()
  return (
    <Layout title='月度汇总账单详情' showBack>
      <Card bordered={false}>
        <Title level={5}>2023年2月月度汇总账单详情</Title>
        <List
          header={<div><label>收费总金额：</label><span>1000</span></div>}
          bordered
          pagination
          dataSource={data}
          renderItem={(item, index) => (
            <List.Item actions={[<Link key={item.name} onClick={() => navigate('/expense/bill/billDetail') }>账单明细</Link>]}>
              <Row style={{ width: '100%' }}>
                <Col span={2}>{`账单${index}`}</Col>
                <Col span={7}>{item.name}</Col>
                <Col>{item.amount}</Col>
              </Row>
            </List.Item>
          )}
        />
      </Card>
    </Layout>
  )
}
export default Detail
