import React, { useEffect } from 'react'
import { DatePicker, Space, Typography, Popover, Card, Descriptions, Table } from 'antd'
import { QuestionCircleFilled } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import styles from './index.module.scss'
import Layout from '../components/Layout'

const { Text, Title, Link } = Typography

function Dashboard () {
  const navigate = useNavigate()
  useEffect(() => {

  }, [])

  const headerPopoverContent = (
    <div>
      <Text type="secondary" className={styles['font-size-12']}>按计费周期：按资源使用时间统计生成月度账单。</Text><br />
      <Text type="secondary" className={styles['font-size-12']}>如：您在1月31日23:00～23:59使用的按小时结算的按量计费资源，按计费周期，该笔费用统计到1月账单。</Text>
    </div>
  )

  const columns = [
    {
      title: '序号',
      dataIndex: 'number',
      key: 'number',
    },
    {
      title: '月份',
      dataIndex: 'month',
      key: 'month',
      render: (text) => <Link onClick={() => navigate('/expense/dashboard/detail')}>{text}</Link>
    },
    {
      title: '收费总金额',
      dataIndex: 'totalMoney',
      key: 'totalMoney',
    },
  ]

  const dataSource = [
    { number: '1', month: '2023年02月', totalMoney: '100' },
    { number: '2', month: '2023年02月', totalMoney: '100' },
    { number: '3', month: '2023年02月', totalMoney: '100' },
    { number: '4', month: '2023年02月', totalMoney: '100' },
  ]

  return (
    <Layout title='费用概览'>
      <Space>
        <DatePicker picker="month" />
        <Text type="secondary" className={styles['font-size-12']}>按计费周期（按资源使用时间统计生成月度账单）</Text>
        <Popover placement="top" content={headerPopoverContent}>
          <QuestionCircleFilled style={{ color: 'rgba(0, 0, 0, 0.45)' }} />
        </Popover>

      </Space>
      <Card bordered={false}>
        <Descriptions layout="vertical" size="small" column={5} colon={false}>
          <Descriptions.Item label="未出账账单客户">10</Descriptions.Item>
          <Descriptions.Item label="已出账账单客户">10</Descriptions.Item>
          <Descriptions.Item label="未结算账单客户">10</Descriptions.Item>
          <Descriptions.Item label="已结算账单客户">10</Descriptions.Item>
          <Descriptions.Item label="累计未结算账单数量"><Link onClick={() => navigate('/expense/bill') }>12</Link></Descriptions.Item>
        </Descriptions>
      </Card>
      <Card bordered={false}>
        <Title level={5}>月度汇总账单收费金额</Title>
        <Table rowKey="number" size='small' columns={columns} dataSource={dataSource} />
      </Card>
    </Layout>
  )
}

export default Dashboard
