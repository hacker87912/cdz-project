import React, { useEffect, useState } from 'react'
import { Space, Card, Table, Typography, DatePicker, Input, Row, Button } from 'antd'
import { DownloadOutlined } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
import ExportJsonExcel from 'js-export-excel'
// import styles from './index.module.scss'

const { Link } = Typography
const { Search } = Input

function OrderList () {
  const navigate = useNavigate()
  const [dataSource, setDataSource] = useState([])

  useEffect(() => {
    setDataSource([
      { number: '1', orderNumber: '121', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
      { number: '2', orderNumber: '122', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
      { number: '3', orderNumber: '123', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
      { number: '4', orderNumber: '124', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
      { number: '5', orderNumber: '125', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
      { number: '6', orderNumber: '126', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
      { number: '7', orderNumber: '127', product: '产品', client: '腾讯', subProduct: '子产品', type: '类型', orderCreationTime: '2023-01-10 14:28:43', state: '未出账' },
    ])
  }, [])

  const columns = [
    {
      title: '序号',
      dataIndex: 'number',
      key: 'number',
    },
    {
      title: '订单号',
      dataIndex: 'orderNumber',
      key: 'orderNumber',
    },
    {
      title: '客户',
      dataIndex: 'client',
      key: 'client',
    },
    {
      title: '产品',
      dataIndex: 'product',
      key: 'product',
    },
    {
      title: '子产品',
      dataIndex: 'subProduct',
      key: 'subProduct',
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: '状态',
      dataIndex: 'state',
      key: 'state',
    },
    {
      title: '订单创建时间',
      dataIndex: 'orderCreationTime',
      key: 'orderCreationTime',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      render: () => <Link onClick={() => navigate('/expense/order/detail')}>详情</Link>
    },
  ]

  const handleExportCurrentExcel = () => {
    const sheetFilter = columns.map(e => e.dataIndex).slice(0, columns.length - 1)
    const option = {}
    option.fileName = '订单列表'
    option.datas = [
      {
        sheetData: dataSource,
        sheetName: '订单列表',
        sheetFilter: sheetFilter,
        sheetHeader: columns.map(e => e.title).slice(0, columns.length - 1),
        // columnWidths: [10, 10, 10, 10]
      },
    ]
    const toExcel = new ExportJsonExcel(option)
    toExcel.saveExcel()
  }

  return (
    <Layout title='订单列表'>
      <Card bordered={false}>
        <Row justify="space-between" style={{ marginBottom: '15px' }}>
          <Space size="middle">
            <DatePicker picker="month" />
            <Search
              placeholder="input search text"
              allowClear
              // onSearch={onSearch}
              style={{
                width: 200,
              }}
            />
            <Link>重置</Link>
          </Space>
          <Button type="link" icon={<DownloadOutlined />} onClick={handleExportCurrentExcel} />
        </Row>
        <Table rowKey="number" size='small' columns={columns} dataSource={dataSource} />
      </Card>
    </Layout>
  )
}

export default OrderList
