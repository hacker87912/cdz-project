import React from 'react'
import { Card, Typography, Space, Divider, Descriptions, Table } from 'antd'
import { CheckCircleOutlined } from '@ant-design/icons'
import Layout from '../components/Layout'

const { Title } = Typography

function Detail () {
  const columns = [
    {
      title: '子订单号',
      dataIndex: 'suborderNumber',
      key: 'suborderNumber',
    },
    {
      title: '产品',
      dataIndex: 'product',
      key: 'product',
    },
    {
      title: '规格',
      dataIndex: 'specification',
      key: 'specification',
    },
    {
      title: '数量',
      dataIndex: 'quantity',
      key: 'quantity',
    },
    {
      title: '付费方式',
      dataIndex: 'payment',
      key: 'payment',
    },
    {
      title: '订单金额',
      dataIndex: 'orderAmount',
      key: 'orderAmount',
    },
  ]

  const dataSource = [
    { suborderNumber: '1', product: '产品1', specification: '规格', quantity: '数量', payment: '付款方式', orderAmount: '订单金额' },
    { suborderNumber: '2', product: '产品2', specification: '规格', quantity: '数量', payment: '付款方式', orderAmount: '订单金额' },
    { suborderNumber: '3', product: '产品3', specification: '规格', quantity: '数量', payment: '付款方式', orderAmount: '订单金额' },
    { suborderNumber: '4', product: '产品4', specification: '规格', quantity: '数量', payment: '付款方式', orderAmount: '订单金额' },
    { suborderNumber: '5', product: '产品5', specification: '规格', quantity: '数量', payment: '付款方式', orderAmount: '订单金额' },
    { suborderNumber: '6', product: '产品6', specification: '规格', quantity: '数量', payment: '付款方式', orderAmount: '订单金额' },

  ]
  return (
    <Layout title='订单详情' showBack>
      <Card bordered={false}>
        <Space size="middle">
          <CheckCircleOutlined style={{ fontSize: '24px', color: '#52c41a', marginTop: '-1px' }} />
          <Title type="success" level={4}>处理成功</Title>
        </Space>
        <Divider style={{ marginTop: '14px' }} />
        <Descriptions colon={false} column={2}>
          {
            [
              { label: '订单号', value: '20210517281003598415611' },
              { label: '订单类型', value: '新购' },
              { label: '订单创建人', value: 'xxx' },
              { label: '创建时间', value: '2021-05-17 12:33:48' }
            ].map(e => (<Descriptions.Item key={e.label} label={e.label}>{e.value}</Descriptions.Item>))
          }
        </Descriptions>
        <div style={{ marginTop: '8px' }}>
          <Title level={5}>月度汇总账单收费金额</Title>
          <Table rowKey="suborderNumber" size='small' columns={columns} dataSource={dataSource} />
        </div>
      </Card>
    </Layout>
  )
}
export default Detail
