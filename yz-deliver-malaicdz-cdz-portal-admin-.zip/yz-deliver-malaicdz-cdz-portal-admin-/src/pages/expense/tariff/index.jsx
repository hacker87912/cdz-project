import React, { useEffect, useState } from 'react'
// import { useLocation, Navigate } from 'react-router-dom'
// import styles from './index.module.scss'
import { Tabs, Card, Table, Typography, Segmented, Input, Button, Space } from 'antd'
import { EditOutlined } from '@ant-design/icons'
import Layout from '../components/Layout'

const { Link, Text } = Typography

function TariffContent ({ options, edit, dataSource, setDataSource }) {
  const [editRow, setEditRow] = useState('')
  const [dataCopy, setDataCopy] = useState([])

  useEffect(() => {
    setDataCopy(dataSource)
  }, [dataSource])

  const updateTable = (field, index, value, callback) => {
    const data = [...dataCopy]
    data[index][field] = value
    callback(data)
  }

  const inputChange = (field, index, value) => {
    updateTable(field, index, value, setDataCopy)
  }

  const columns = [
    {
      title: '模型',
      dataIndex: 'model',
      key: 'model',
    },
    {
      title: '规格',
      dataIndex: 'specification',
      key: 'specification',
    },
    {
      title: 'CPU（核心）',
      dataIndex: 'CPU',
      key: 'CPU',
    },
    {
      title: 'Mem（G）',
      dataIndex: 'Mem',
      key: 'Mem',
    },
    {
      title: '按使用情况（美元/小时）',
      dataIndex: 'use',
      key: 'use',
      render: (text, record, index) => (
        <Space>
          <Text>{editRow === record.id ? <Input value={record._use || text} onChange={(e) => inputChange('_use', index, e.target.value)} /> : text}</Text>
          {(edit && !(editRow === record.id)) && <EditOutlined onClick={() => setEditRow(record.id)} /> }
          {editRow === record.id && (
            <Space>
              <Button type="primary" size="small" onClick={() => { updateTable('use', index, (record._use || record.use), setDataSource); setEditRow('')}}>确认</Button>
              <Button size="small" onClick={() => { updateTable('_use', index, '', setDataCopy); setEditRow('')}}>取消</Button>
            </Space>
          )}
        </Space>
      )
    },
  ]

  return (
    <>
      <Segmented options={options} style={{ marginBottom: '10px' }} />
      <Table rowKey="id" size='small' columns={columns} dataSource={dataSource} />
    </>
  )
}

function Tariff () {
  const [edit, setEdit] = useState(false)
  const [dataSource, setDataSource] = useState([
    { id: '1', model: '模型1', specification: '规格', CPU: 'CPU', Mem: 'Mem', use: 'use' },
    { id: '2', model: '模型2', specification: '规格', CPU: 'CPU', Mem: 'Mem', use: 'use' },
    { id: '3', model: '模型3', specification: '规格', CPU: 'CPU', Mem: 'Mem', use: 'use' },
    { id: '4', model: '模型4', specification: '规格', CPU: 'CPU', Mem: 'Mem', use: 'use' },
    { id: '5', model: '模型5', specification: '规格', CPU: 'CPU', Mem: 'Mem', use: 'use' },
    { id: '6', model: '模型6', specification: '规格', CPU: 'CPU', Mem: 'Mem', use: 'use' },
  ])

  const items = [
    { label: '计算', key: '计算', children: <TariffContent {...{ edit, setEdit, dataSource, setDataSource }} options={['云服务CVM', '云硬盘CRS']} /> },
    { label: '存储', key: '存储', children: <TariffContent {...{ edit, setEdit, dataSource, setDataSource }} options={['对象存储CSP']} /> },
    { label: '网络', key: '网络', children: <TariffContent {...{ edit, setEdit, dataSource, setDataSource }} options={['负载均衡CLB', '私有网络VPC', '诊断工具', '弹性网卡ENI', 'NAT网络', '云联网CCN', 'VPN连接', '弹性公网IP']} /> },
    { label: '数据库', key: '数据库', children: <TariffContent {...{ edit, setEdit, dataSource, setDataSource }} options={['云数据库Redis', '云数据库MySQL']} /> },
  ]

  const operation = () => {
    if (edit) {
      setEdit(false)
    } else {
      setEdit(true)
    }
  }

  const tabBarExtraContent = (
    <Space size="middle">
      <Link>整体折旧</Link>
      <Link onClick={operation}>{edit ? '保存' : '编辑'}</Link>
    </Space>
  )

  return (
    <Layout title='资费包设置'>
      <Card bordered={false}>
        <Tabs
          defaultActiveKey="1"
          type="card"
          size="large"
          items={items}
          tabBarExtraContent={tabBarExtraContent}
        />
      </Card>
    </Layout>
  )
}

export default Tariff
