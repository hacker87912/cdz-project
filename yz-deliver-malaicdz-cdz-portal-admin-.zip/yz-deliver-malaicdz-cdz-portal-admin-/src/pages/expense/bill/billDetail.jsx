import React, { useState } from 'react'
import { Space, Card, Typography, Input, Row, Tabs, Alert, DatePicker, Select, Checkbox, Table, Button } from 'antd'
import { DownloadOutlined } from '@ant-design/icons'
import styles from './index.module.scss'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'

const { Link } = Typography
const { Search } = Input

function AlertBox ({ data, type = 'info', ...rest }) {
  const description = (
    data.map((e, i) => (<p key={i}>{e}</p>))
  )
  return (
    <Alert description={description} type={type} showIcon {...rest} />
  )
}

function BillDetail () {
  const navigate = useNavigate()
  const [alertInfo, setAlertInfo] = useState(['1.资源账单记录您使用的资源每个月的使用详情及产生的费用。', '2.每月 3 号出账，当前月份账单出账未完成，以下费用不是最终的本月账单费用，仅供参考。账单概览数据可能有延迟，实时数据请您查看明细账单。'])

  const columns = [
    {
      title: '资源ID',
      dataIndex: 'resourceID',
      key: 'resourceID',
    },
    {
      title: '资源名称',
      dataIndex: 'resourceName',
      key: 'resourceName',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      render: () => <Link onClick={() => navigate('/expense/bill/resourceBillDetail')}>资源账单详情</Link>
    },
  ]

  const dataSource = [
    { resourceID: '1', resourceName: '资源1' },
    { resourceID: '2', resourceName: '资源2' },
    { resourceID: '3', resourceName: '资源3' },
    { resourceID: '4', resourceName: '资源4' },
    { resourceID: '5', resourceName: '资源5' },
  ]
  const content = (
    <Space
      direction="vertical"
      size="middle"
      style={{ display: 'flex' }}
    >
      <AlertBox className={styles['alert-box']} data={alertInfo} />
      <Space size="middle">
        <DatePicker picker="month" />
        <Select
          defaultValue="0"
          style={{ width: 120 }}
          options={[
            { value: '0', label: '全部可用区' },
            { value: '1', label: 'CDZ区' },
            { value: '2', label: '非CDZ区' },
          ]}
        />
        <Link>重置</Link>
        <Checkbox>不显示0美元费用</Checkbox>
      </Space>
      <Card bordered={false}>
        <Row justify="space-between" style={{ marginBottom: '15px' }}>
          <div className={styles['bill-total']}>现金支出（含税）<strong>0.84美元</strong><span>=   优惠后总价（不含税） 0.84 美元 - 代金券支出0.00 美元 + 扣税0.00 美元</span></div>
          <Search
            placeholder="input search text"
            allowClear
            // onSearch={onSearch}
            style={{
              width: 400,
            }}
          />
          <Button type="link" icon={<DownloadOutlined />} />
        </Row>
        <Table rowKey="resourceID" size='small' columns={columns} dataSource={dataSource} />
      </Card>
    </Space>
  )

  const tabs = [
    {
      key: '资源ID账单',
      label: '资源ID账单',
      children: content,
    },
    {
      key: '明细账单',
      label: '明细账单',
      children: content,
    },
  ]

  const tabChange = (key) => {
    if (key === '资源ID账单') {
      setAlertInfo(['1.资源账单记录您使用的资源每个月的使用详情及产生的费用。', '2.每月 3 号出账，当前月份账单出账未完成，以下费用不是最终的本月账单费用，仅供参考。账单概览数据可能有延迟，实时数据请您查看明细账单。'])
    } else if (key === '明细账单') {
      setAlertInfo([
        '支持页面在线查询近18个月账单数据，超过18个月的历史账单及数据量过大的月份账单可下载文件至本地查看。',
        '资源ID账单数据可能有延迟，实时数据请您查看明细账单。次月1号出账，当前月份账单出账未完成，以下费用不是最终的本月账单费用，仅供参考。',
        '明细账单费用最多支持8位小数，资源ID账单展示的费用为四舍五入后保留2位小数的费用，实际从账户扣费时按2位小数进行扣费（即扣到分）。从账户扣费时按2位小数进行扣费（即扣到分）。'
      ])
    }
  }

  return (
    <Layout title='账单详情' showBack>
      <Tabs defaultActiveKey="资源ID账单" items={tabs} onChange={tabChange} />
    </Layout>
  )
}
export default BillDetail
