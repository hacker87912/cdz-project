import React, { useEffect, useState } from 'react'
import { Space, Card, Table, Typography, DatePicker, Select, Input, Row, Button, Modal, Descriptions, Radio } from 'antd'
import { DownloadOutlined } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
// import styles from './index.module.scss'
import UploadBox from '@/components/upload'
import BillTemplate from '@/components/pdf/billTemplate'

const { Link } = Typography
const { Search } = Input

function BillList () {
  const navigate = useNavigate()
  const [isProofOpen, setIsProofOpen] = useState(false)
  const [radioValue, setRadioValue] = useState(1)
  const [pdfOpen, setPdfOpen] = useState(false)
  const [pdfOk, setPdfOk] = useState(false)
  useEffect(() => {

  }, [])

  const columns = [
    {
      title: '账单月份',
      dataIndex: 'billMonth',
      key: 'billMonth',
    },
    {
      title: '账单统计周期',
      dataIndex: 'period',
      key: 'period',
    },
    {
      title: '客户',
      dataIndex: 'client',
      key: 'client',
    },
    {
      title: 'CDZ费用',
      dataIndex: 'CDZ_expense',
      key: 'CDZ_expense',
    },
    {
      title: '非CDZ费用',
      dataIndex: 'CDZ_not_expense',
      key: 'CDZ_not_expense',
    },
    {
      title: '总费用',
      dataIndex: 'sumExpense',
      key: 'sumExpense',
    },
    {
      title: '状态',
      dataIndex: 'state',
      key: 'state',
    },
    {
      title: 'CDZ费用结算',
      dataIndex: 'closeAccount',
      key: 'closeAccount',
    },
    {
      title: '操作',
      dataIndex: 'operation',
      key: 'operation',
      render: () => (
        <Space>
          <Link onClick={() => navigate('/expense/bill/billDetail')}>账单详情</Link>
          <Link onClick={() => setIsProofOpen(true)}>结算凭证</Link>
          <Link onClick={() => setPdfOpen(true)}>下载账单</Link>
        </Space>
      )
    },
  ]

  const dataSource = [
    { id: '1', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '2', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '3', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '4', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '5', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '6', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '7', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
    { id: '8', billMonth: '2023年02月', period: '按量计费', client: '腾讯', CDZ_expense: '1', CDZ_not_expense: '2', sumExpense: '3', state: '未出账', closeAccount: '未结算' },
  ]

  return (
    <Layout title='账单列表'>
      <Card bordered={false}>
        <Row justify="space-between" style={{ marginBottom: '15px' }}>
          <Space size="middle">
            <DatePicker picker="month" />
            <Select
              defaultValue="0"
              style={{ width: 120 }}
              options={[
                { value: '0', label: '全部' },
                { value: '1', label: '未出账' },
                { value: '2', label: '已出账' },
              ]}
            />
            <Select
              defaultValue="0"
              style={{ width: 120 }}
              options={[
                { value: '0', label: '全部' },
                { value: '1', label: '未结算' },
                { value: '2', label: '已结算' },
              ]}
            />
            <Search
              placeholder="input search text"
              allowClear
              // onSearch={onSearch}
              style={{
                width: 200,
              }}
            />
            <Link>重置</Link>
          </Space>
          <Button type="link" icon={<DownloadOutlined />} />
        </Row>
        <Table rowKey="id" size='small' columns={columns} dataSource={dataSource} />
      </Card>
      <Modal width={700} title="结算凭证" open={isProofOpen} onOk={() => setIsProofOpen(false)} onCancel={() => setIsProofOpen(false)}>
        <div style={{ padding: '24px' }}>
          <Descriptions column={1}>
            <Descriptions.Item label="是否结算" labelStyle={{ color: 'rgba(0, 0, 0, 0.88)' }}>
              <Radio.Group onChange={(e) => setRadioValue(e.target.value)} value={radioValue}>
                <Radio value={1}>是</Radio>
                <Radio value={0}>否</Radio>
              </Radio.Group>
            </Descriptions.Item>
            <Descriptions.Item label="上传凭证" labelStyle={{ color: 'rgba(0, 0, 0, 0.88)' }}><UploadBox /></Descriptions.Item>
          </Descriptions>
        </div>
      </Modal>
      <Modal width={1000} title="预览" open={pdfOpen} onOk={() => setPdfOk(true)} onCancel={() => setPdfOpen(false)}>
        <BillTemplate id="billPDF" name="PDF账单" open={pdfOk} />
      </Modal>
    </Layout>
  )
}

export default BillList
