import React from 'react'
import { Typography, Card, Space, Row, Popover, Table, Progress } from 'antd'
import Layout from '../components/Layout'
import { QuestionCircleFilled } from '@ant-design/icons'
import { Column } from '@ant-design/charts'

const { Text, Title } = Typography

function ResourceBillDetail () {
  const columns = [
    {
      title: '组件',
      dataIndex: 'component',
      key: 'component',
    },
    {
      title: '用量',
      dataIndex: 'dosage',
      key: 'dosage',
    },
    {
      title: '费用/占比',
      dataIndex: 'expenseRatio',
      key: 'expenseRatio',
      render: (text) => <div style={{ display: 'flex' }}><Text>{text}</Text><Progress percent={30} style={{ flex: 1 }} /></div>
    },
  ]

  const dataSource = [
    { id: '1', component: '组件1', dosage: '--', expenseRatio: '0.07（100%）' },
    { id: '2', component: '组件2', dosage: '--', expenseRatio: '0.08（100%）' },
  ]

  const config = {
    padding: 32,
    columnWidthRatio: 0.5,
    data: [
      { date: '2022-12', value: 38 },
      { date: '2023-1', value: 50 },
      { date: '2023-2', value: 10 },
      { date: '2023-3', value: 60 },
      { date: '2023-4', value: 20 },
      { date: '2023-5', value: 40 },
    ],
    xField: 'date',
    yField: 'value',
    label: {
      // 可手动配置 label 数据标签位置
      position: 'middle',
      // 'top', 'bottom', 'middle',
      // 配置样式
      style: {
        fill: '#FFFFFF',
        opacity: 0.6,
      },
    },
    xAxis: {
      label: {
        autoHide: true,
        autoRotate: false,
      },
    },
    meta: {
      date: {
        alias: '日期',
      },
      sales: {
        value: '消费金额',
      },
    },
  }
  return (
    <Layout title='资源账单详情' showBack>
      <Text>2023-03-01 00:00:00 至 2023-03-31 23:59:59</Text>
      <Card bordered={false}>
        <Space
          direction="vertical"
          size="middle"
          style={{ display: 'flex' }}
        >
          <Row justify="center">
            <Space size="small">
              <Text>总费用</Text>
              <Popover placement="top" content={<Text>折后总费用</Text>}>
                <QuestionCircleFilled style={{ color: 'rgba(0, 0, 0, 0.45)' }} />
              </Popover>
            </Space>
          </Row>
          <Row justify="center">
            <Space size="small">
              <Title level={2}>0.07</Title>
              <Text>美金</Text>
            </Space>
          </Row>
          <Table rowKey="id" size='small' columns={columns} dataSource={dataSource} pagination={false} />
        </Space>
      </Card>
      <Card bordered={false}>
        <Title level={5}>近6个月消费走势</Title>
        <Column {...config} />
      </Card>
    </Layout>
  )
}
export default ResourceBillDetail
