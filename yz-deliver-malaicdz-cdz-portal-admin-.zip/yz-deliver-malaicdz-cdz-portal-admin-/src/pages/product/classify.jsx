import React from 'react'
import Template from '@/pages/topNav/components/template'
import Layout from '@/pages/expense/components/Layout'
import { getProductClassify, addProductClassify, editProductClassify, deleteProductClassify, editProductClassifySort, productClassifyDetail } from '@/services/product'
import { useTranslation } from 'react-i18next'

function Classify () {
  const { t } = useTranslation()

  return (
    <Layout title={t('产品分类')} showBack path="/cms/product">
      <Template
        title="产品分类"
        add={addProductClassify}
        edit={editProductClassify}
        deleteFunc={deleteProductClassify}
        getApi={getProductClassify}
        editSort={editProductClassifySort}
        getDetail={productClassifyDetail}
      />
    </Layout>
  )
}
export default Classify
