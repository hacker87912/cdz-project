import React, { useEffect, useState } from 'react'
import { Modal, Form, Input, Switch, InputNumber, Select, Typography, Row } from 'antd'
import { useNavigate } from 'react-router-dom'
import Editor from '@/components/editor'
import { useTranslation } from 'react-i18next'

const { Link } = Typography

function ProductModal ({ open, setOpen, title = '', record, portFunc = () => {}, productClassifyOptions, isSort }) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [form] = Form.useForm()
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open === 'edit' || open === 'sort') {
      const { id, classify, title, enTitle, subTitle, subEnTitle, fileUrl, moreUrl, buyNowUrl, sort, detail, status, enDetail } = record
      form.setFieldsValue({ id, classify, title, enTitle, subTitle, subEnTitle, fileUrl, moreUrl, buyNowUrl, sort, status: status ? false : true, detail, enDetail })
    }
  }, [record, open])

  const clear = () => {
    setConfirmLoading(false)
    setOpen('')
    form.resetFields()
  }

  const onFinish = async (values) => {
    setConfirmLoading(true)
    values.status = values.status ? 0 : 1
    await portFunc({ ...values, id: form.getFieldValue('id') })
    clear()
  }
  const onOk = () => {
    form.submit()
  }

  const onValuesChange = (changedValues) => {
    const [key] = Object.keys(changedValues)
    if (key === 'status') {
      form.setFieldValue('status', changedValues['status'] ? 1 : 0)
    }
  }
  return (
    <>
      <Modal forceRender width={open === 'add' ? 900 : (open === 'edit' ? 900 : 600)} title={title} open={open} onOk={onOk} onCancel={clear} confirmLoading={confirmLoading} maskClosable={false}>
        <Form
          form={form}
          labelCol={{
            span: open === 'add' ? 6 : (open === 'edit' ? 6 : 4),
          }}
          style={{ padding: '20px 60px 20px 0'}}
          onFinish={onFinish}
          onValuesChange={onValuesChange}
          initialValues={{ status: 1 }}
        >
          {!isSort && (
            <>
              <Row style={{ marginLeft: '5px' }}>
                <Form.Item
                  style={{ flex: 1, marginRight: '5px', overflow: 'hidden' }}
                  label={t('产品分类')}
                  name="classify"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                  ]}
                >
                  <Select
                    style={{ flex: 1, marginRight: '5px' }}
                    options={productClassifyOptions}
                  />
                </Form.Item>
                <Link onClick={() => navigate('/cms/product/classify')} style={{ height: '30px', lineHeight: '30px' }}>{t('管理')}</Link>
              </Row>
              <Form.Item
                label={t('产品名称(中文)')}
                name="title"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 10,
                    message: t('名称长度最多10位'),
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('产品名称(英文)')}
                name="enTitle"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 50,
                    message: t('名称长度最多50位'),
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('产品副标题(中文)')}
                name="subTitle"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 100,
                    message: t('名称长度最多100位'),
                  },
                ]}
              >
                <Input.TextArea />
              </Form.Item>
              <Form.Item
                label={t('产品副标题(英文)')}
                name="subEnTitle"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 500,
                    message: t('名称长度最多500位'),
                  },
                ]}
              >
                <Input.TextArea />
              </Form.Item>
              <Form.Item
                label={t('立即购买')}
                name="buyNowUrl"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('文档跳转')}
                name="fileUrl"
                rules={[
                  {
                    required: true,
                    message: t('请必填')
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('了解更多跳转')}
                name="moreUrl"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('产品内容(中文)')}
                name="detail"
                rules={[
                  {
                    required: true,
                    message: t('请必填')
                  },
                  {
                    validator: (_, value) => {
                      if (value !== '<p><br></p>') {
                        return Promise.resolve()
                      }
                      return Promise.reject(new Error(t('请必填')))
                    },
                    validateTrigger: 'onBlur'
                  },
                ]}
              >
                <Editor />
              </Form.Item>
              <Form.Item
                label={t('产品内容(英文)')}
                name="enDetail"
                rules={[
                  {
                    required: true,
                    message: t('请必填')
                  },
                  {
                    validator: (_, value) => {
                      if (value !== '<p><br></p>') {
                        return Promise.resolve()
                      }
                      return Promise.reject(new Error(t('请必填')))
                    },
                    validateTrigger: 'onBlur'
                  },
                ]}
              >
                <Editor />
              </Form.Item>
              <Form.Item
                label={t('是否显示')}
                name="status"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
            </>
          )}
          <Form.Item
            label={t('排序')}
            name="sort"
            help={t('输入数字，数字越小排在最前面')}
            rules={[
              {
                required: true,
                message: t('请必填')
              },
            ]}
          >
            <InputNumber style={{ width: '400px' }} />
          </Form.Item>
        </Form>
      </Modal>
    </>
  )
}
export default ProductModal
