import React, { useState } from 'react'
import { Tabs, Card, DatePicker, Space, Input, Table } from 'antd'
import Layout from '@/pages/expense/components/Layout'
import { getOperationLogPageList, getLoginLogPageList } from '@/services/logs'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import dayjs from 'dayjs'
import { useTranslation } from 'react-i18next'

const { RangePicker } = DatePicker
const { Search } = Input

function SearchTableBox ({ columns, dataSource, paging, setPaging = () => {}, loading, date, dateChange, setSearch, inputValue, setInputValue }) {
  const { t } = useTranslation()
  const [startDate, endDate] = date
  return (
    <>
      <Space size='large'>
        <RangePicker
          allowClear
          showTime
          value={[startDate ? dayjs(startDate) : '',endDate ? dayjs(endDate) : '']}
          onChange={(_, e) => dateChange(e)} />
        <Search
          enterButton
          placeholder={t('请输入你需要搜索的名称')}
          allowClear
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onSearch={(v) => { setPaging((e) => ({ ...e, current: 1 })); setSearch(v) }}
          style={{
            width: 300,
          }}
        />
      </Space>
      <Table
        loading={loading}
        style={{ marginTop: '16px' }}
        rowKey="id"
        size='small'
        columns={columns}
        dataSource={dataSource}
        pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100], showTotal: total => `${t('共')} ${total} ${t('条')}` }}
        onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
      />
    </>
  )
}

function LogList () {
  const { t } = useTranslation()
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [loading, setLoading] = useState(false)
  const [operationData, setOperationData] = useState([])
  const [loginData, setLoginData] = useState([])
  const [activeKey, setActiveKey] = useState(searchParams.tab || 'operationLog')
  const [date, setDate] = useState([searchParams.startDate || '', searchParams.endDate || ''])
  const [search, setSearch] = useState(searchParams.keyword || '')
  const [value, setValue] = useState(searchParams.keyword || '')

  const getData = async (port, setData) => {
    const [startDate, endDate] = date
    const res = await port({
      current: current,
      size: pageSize,
      startDate,
      endDate,
      key: search
    })
    const { data: { records = [], total = 0 } = {} } = res
    setData(records)
    setPaging((e => ({ ...e, total })))
    setLoading(false)
  }

  const init = () => {
    setActiveKey('operationLog')
    setPaging({ current: 1, pageSize: 10, total: 0 })
    setValue('')
    setSearch('')
    setDate(['', ''])
    return { current: '1', pageSize: '10', tab: 'operationLog' }
  }

  const getDatas = () => {
    activeKey === 'operationLog' && getData(getOperationLogPageList, setOperationData)
    activeKey === 'loginLog' && getData(getLoginLogPageList, setLoginData)
  }

  useUpdateEffect((didMount) => {
    setLoading(true)
    getDatas()
    didMount && setSearchParams({ current, pageSize, tab: activeKey, keyword: search, startDate: date[0], endDate: date[1] })
    return true
  }, [current, pageSize, activeKey, JSON.stringify(date), search], init, getDatas)

  const operationColumns = [
    { title: t('序号'), dataIndex: 'id', key: 'id', render: (text, record, index) => <span>{(current - 1) * pageSize + index + 1}</span>, },
    { title: t('操作时间'), dataIndex: 'createTime', key: 'createTime' },
    { title: t('操作人'), dataIndex: 'userName', key: 'userName' },
    { title: t('操作人账号'), dataIndex: 'userAccount', key: 'userAccount' },
    { title: t('系统模块'), dataIndex: 'sysModule', key: 'sysModule' },
    { title: t('操作类型'), dataIndex: 'operateType', key: 'operateType' },
    { title: t('请求路径'), dataIndex: 'url', key: 'url' },
  ]
  const loginColumns = [
    { title: t('序号'), dataIndex: 'id', key: 'id', render: (text, record, index) => <span>{(current - 1) * pageSize + index + 1}</span>, },
    { title: t('登录时间'), dataIndex: 'createTime', key: 'createTime' },
    { title: t('登录人'), dataIndex: 'userName', key: 'userName' },
    { title: t('登录账号'), dataIndex: 'userAccount', key: 'userAccount' },
    { title: t('登录IP'), dataIndex: 'ip', key: 'ip' },
    { title: t('登录地址'), dataIndex: 'loginAddr', key: 'loginAddr' },
  ]
  const items = [
    {
      key: 'operationLog',
      label: t('操作日志'),
      children: (
        <SearchTableBox
          loading={loading}
          columns={operationColumns}
          dataSource={operationData}
          paging={paging}
          setPaging={setPaging}
          date={date}
          dateChange={setDate}
          setSearch={setSearch}
          inputValue={value}
          setInputValue={setValue}
        />
      ),
    },
    {
      key: 'loginLog',
      label: t('登录日志'),
      children: (
        <SearchTableBox
          loading={loading}
          columns={loginColumns}
          dataSource={loginData}
          paging={paging}
          setPaging={setPaging}
          date={date}
          dateChange={setDate}
          setSearch={setSearch}
          inputValue={value}
          setInputValue={setValue}
        />
      ),
    },
  ]

  const tabs = (e) => {
    setActiveKey(e)
    setPaging({ current: 1, pageSize: 10, total: 0 })
    setDate(['', ''])
    setSearch('')
  }
  return (
    <Layout title={t('日志管理')}>
      <Card bordered={false}>
        <Tabs activeKey={activeKey} items={items} onChange={tabs} />
      </Card>
    </Layout>
  )
}
export default LogList
