import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Space, Table, Input, Button, Switch, message, Modal, Card } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/account'
import CreateAccount from './createAccount'
import ContentTitle from '@/components/contentTitle'
import { decrypt } from '@/utils/utils'

function AccountManage () {
  const { t } = useTranslation()
  const [keyword, setKeyword] = useState('')
  const [tableData, setTableData] = useState([])
  const [pageNo, setPageNo] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totals, setTotals] = useState(0)
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [accountId, setAccountId] = useState('')
  useEffect(() => {
    queryAccountList()
  }, [pageNo, pageSize, keyword])

  // 分页查询account列表
  const queryAccountList = async () => {
    setLoading(true)
    const res = await API.accountQuery({
      current: pageNo,
      size: pageSize,
      key: keyword
    })
    const { records = [], total = 0 } = res.data || {}
    setLoading(false)
    setTableData(records)
    setTotals(total)
  }
  // 切换状态
  const changeAccountStatus = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要改变状态?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('账户名称')}: ${record.userNickname}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.accountStatus({ id: record.id, userStatus: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryAccountList()
        }
      }
    })
  }
  // 点击创建
  const clickCreateAccount = () => {
    setAccountId('')
    setOpen(true)
  }
  // 点击编辑
  const clickEditAccount = (record) => {
    setAccountId(record.id)
    setOpen(true)
  }
  // 点击重置密码
  const clickResetAccount = (record) => {
    Modal.confirm({
      title: t('确认是否要重置密码?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('账户名称')}: ${record.userNickname}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.accountReset({ id: record.id })
        if (res.code === 0) {
          const pwd = decrypt(res.data)
          Modal.confirm({
            title: t('重置密码'),
            content: pwd,
            okText: t('复制'),
            okType: 'primary',
            onOk () {
              var copyipt = document.createElement('input')
              copyipt.setAttribute('value', pwd)
              document.body.appendChild(copyipt)
              copyipt.select()
              document.execCommand('copy')
              document.body.removeChild(copyipt)
              message.success(t('复制成功'))

            }
          })
        }
      }
    })

  }
  // 点击删除
  const clickDeleteAccount = (record) => {
    Modal.confirm({
      title: t('确认是否要删除?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('账户名称')}: ${record.userNickname}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.accountDelete({ id: record.id })
        if (res.code === 0) {
          message.success(t('删除成功'))
          queryAccountList()
        }
      }
    })
  }
  // 提交account回调
  const handleAccountSubmit = () => {
    setOpen(false)
    if (accountId) {
      queryAccountList()
    } else {
      pageNo === 1 ? queryAccountList() : setPageNo(1)
    }
  }
  const columns = [
    {
      title: t('序号'),
      key: 'index',
      render: (text, record, index) => <span>{(pageNo - 1) * pageSize + index + 1}</span>,
      width: 80
    },
    {
      title: t('账号'),
      dataIndex: 'userName',
    },
    {
      title: t('账户名称'),
      dataIndex: 'userNickname',
      width: 150,
      ellipsis: true
    },
    {
      title: t('创建时间'),
      dataIndex: 'createTime',
      // render: (text, record, index) => <span>{text}</span>,
    },
    {
      title: t('账号角色'),
      dataIndex: 'adminRoleName',
    },
    {
      title: t('用户状态'),
      dataIndex: 'userStatus',
      width: 100,
      render: (_, record) => <Switch checked={!!record.userStatus} onChange={(status) => changeAccountStatus(record, status)} />,
    },
    {
      title: t('操作'),
      key: 'action',
      width: 200,
      render: (_, record) => (
        <Space size='middle'>
          <a onClick={() => clickEditAccount(record)}>{t('编辑')}</a>
          <a onClick={() => clickResetAccount(record)}>{t('重置密码')}</a>
          <a onClick={() => clickDeleteAccount(record)}>{t('删除')}</a>
        </Space>
      ),
    },
  ]
  return (
    <>
      <div className={styles['account-manage']}>
        <div className={styles['title']}>
          <ContentTitle title={t('账号管理')}/>
        </div>
        <Card bordered={false}>
          <div className={styles['search-content']}>
            <Button
              type='primary'
              className={styles['add-btn']}
              onClick={clickCreateAccount}
              size='middle'
            >
              {t('新增账号')}
            </Button>
            <Input.Search
              placeholder={t('请输入账号ID/名称')}
              className={styles['search-ipt']}
              onSearch={(val) => {
                setPageNo(1)
                setKeyword(val)
              }}
              enterButton
              allowClear
            />
          </div>
          <div className={styles['table-content']}>
            <Table
              dataSource={tableData}
              columns={columns}
              rowKey='id'
              loading={loading}
              pagination={{
                showQuickJumper: true,
                showSizeChanger: true,
                pageSize,
                current: pageNo,
                total: totals,
                showTotal: total => `${t('共')} ${total} ${t('条')}`
              }}
              onChange={(pagination) => {
                setPageNo(pagination.current)
                setPageSize(pagination.pageSize)
              }}
              size='small'
              responsive
            />
          </div>
        </Card>
      </div>

      <CreateAccount
        open={open}
        onClose={() => setOpen(false)}
        accountId={accountId}
        onSubmit={handleAccountSubmit}
      />
    </>

  )
}

export default AccountManage
