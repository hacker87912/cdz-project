import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Select, Input, message, Switch, Button, Row, Col } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/account'


function CreateAccount ({ accountId, open, onClose, onSubmit }) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [accountInfo, setAccountInfo] = useState({})
  const [initAccountInfo, setInitAccountInfo] = useState({})
  const [roleList, setRoleList] = useState([])
  const [pwdReadOnly, setPwdReadOnly] = useState(true)
  const [confirmLoading, setConfirmLoading] = useState(false)
  const [form] = Form.useForm()
  useEffect(() => {
    checkRoleList()
  }, [])
  useEffect(() => {
    open && queryAccountInfo()
  }, [open])

  // 初始化
  const queryAccountInfo = async () => {
    const initData = {
      userName: '',
      userNickname: '',
      phone: '',
      mail: '',
      adminRoleId: '',
      pwd: '',
      userStatus: true
    }
    setAccountInfo(initData)
    setInitAccountInfo(initData)
    form.setFieldsValue(initData)
    if (accountId) {
      const res = await API.accountCheck({ id: accountId })
      const resData = res?.data || {}
      const accountData = {
        ...resData,
        userStatus: !!resData.userStatus
      }
      setAccountInfo(accountData)
      setInitAccountInfo(accountData)
      form.setFieldsValue(accountData)
    }

  }
  // 查询角色下拉列表
  const checkRoleList = async () => {
    const res = await API.roleCheck({ key: '' })
    const resData = res?.data || []
    const roleData = resData.map(item => ({ value: item.id, label: item.roleName }))
    setRoleList(roleData)

  }
  // 提交表单数据
  const submitAccount = async () => {
    const postData = {
      ...accountInfo,
      userStatus: +accountInfo.userStatus,
      password: accountInfo.pwd
    }
    let accountApi = API.accountAdd
    let msg = t('创建成功')

    if (accountId) {
      postData.id = accountId
      accountApi = API.accountEdit
      msg = t('编辑成功')
    }
    setConfirmLoading(true)
    const res = await accountApi(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(msg)
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitAccount()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(accountInfo) === JSON.stringify(initAccountInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setAccountInfo({
      ...accountInfo,
      ...changedValues
    })
  }
  return (
    <Modal
      className={styles['create-account']}
      title={accountId ? t('编辑') : t('新增')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Form
        form={form}
        name='account-form'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Form.Item
          label={t('账号')}
          name='userName'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入账号'),
            },
            {
              pattern: /^[0-9a-zA-Z]{6,30}$/,
              message: t('账号由字母,数字组成，长度6到30位'),
            },
          ]}
        >
          <Input placeholder={t('请输入账号')} />
        </Form.Item>

        <Form.Item
          label={t('账号名称')}
          name='userNickname'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入账号名称'),
            },
            {
              type: 'string',
              min: 1,
              max: 50,
              message: t('账号名称长度不超过50'),
            },
          ]}
        >
          <Input placeholder={t('请输入账号名称')} />
        </Form.Item>
        <Form.Item
          label={t('手机号')}
          name='phone'
          rules={[
            {
              required: true,
              message: t('请输入手机号码'),
            },
            {
              pattern: /^(\+)[0-9]{1,3}[0-9]{4,14}(?:x.+)?$/,
              message: t('手机号码必须要有国际区号(以+号开头)'),
            },
          ]}
        >
          <Input placeholder={t('请输入手机号码')} />
        </Form.Item>
        <Form.Item
          label={t('电子邮箱')}
          name='mail'
          rules={[
            {
              pattern: /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/,
              message: t('邮箱格式不正确'),
            },
          ]}
        >
          <Input placeholder={t('请输入邮箱')} />
        </Form.Item>

        <Row >
          <Form.Item
            style={{width: '100%'}}
            label={t('账号角色')}
            name='adminRoleId'
            rules={[
              {
                required: true,
                message: t('请选择账号角色'),
              },
            ]}
          >
            <Select
              placeholder={t('请选择账号角色')}
              options={roleList}
            />
          </Form.Item>
          <Button
            type='link'
            onClick={() => navigate('/account/role')}
            style={{ marginLeft: '-100px'}}>
            {t('管理')}
          </Button>
        </Row>
        {
          !accountId && <Form.Item
            label={t('密码')}
            name='pwd'
            rules={[
              {
                required: true,
                whitespace: true,
                message: t('请输入账号密码'),
              },
              {
                pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])(.{8,30})$/,
                message: t('密码为字母+数字组合，长度8到30位'),
              },
            ]}
          >
            <Input.Password
              placeholder={t('请输入账号密码')}
              readOnly={pwdReadOnly}
              onFocus={() => setPwdReadOnly(false)}
              onBlur={() => setPwdReadOnly(true)}/>
          </Form.Item>
        }
        <Form.Item
          label={t('用户状态')}
          name='userStatus'
          valuePropName='checked'
          required
        >
          <Switch />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default CreateAccount
