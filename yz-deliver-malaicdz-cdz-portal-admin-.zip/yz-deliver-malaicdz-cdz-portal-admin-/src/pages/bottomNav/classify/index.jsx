import React from 'react'
import Template from '@/pages/topNav/components/template'
import Layout from '@/pages/expense/components/Layout'
import { bottomNavClassifyQuery, addBottomNavClassify, editBottomNavClassify, deleteBottomNavClassify, editBottomNavClassifySort, bottomNavClassifyDetail } from '@/services/bottomNav'
import { useTranslation } from 'react-i18next'

function Classify () {
  const { t } = useTranslation()

  return (
    <Layout title={t('底部菜单分类')} showBack path="/cms/bottomnav">
      <Template
        title="底部菜单分类"
        add={addBottomNavClassify}
        edit={editBottomNavClassify}
        deleteFunc={deleteBottomNavClassify}
        getApi={bottomNavClassifyQuery}
        editSort={editBottomNavClassifySort}
        getDetail={bottomNavClassifyDetail}
      />
    </Layout>
  )
}
export default Classify
