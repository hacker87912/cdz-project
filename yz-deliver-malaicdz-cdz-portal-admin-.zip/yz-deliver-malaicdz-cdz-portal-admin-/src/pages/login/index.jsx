import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { LockOutlined, UserOutlined } from '@ant-design/icons'
import { Button, Form, Input, Avatar } from 'antd'
import * as API from '@/services/auth'
import styles from './index.module.scss'
import { useStore } from '@/store'
import { getItem, setItem } from '@/utils/storage'
import { encrypt } from '@/utils/utils'

const Login = function () {
  const { t, i18n } = useTranslation()
  const navigate = useNavigate()
  const { global } = useStore()
  useEffect(() => {
    if (getItem('Authorization')) {
      navigate('/', { replace: true })
    }
  }, [])

  // 切换语言
  const handleChangeLang = () => {
    const lang = global.locale === 'zh' ? 'en' : 'zh'
    global.setLocale(lang)
    // i18n.changeLanguage(lang)
    window.location.reload()
  }
  // 提交登录
  const onFinish = async (values) => {
    const { username, password } = values
    const res = await API.login({
      loginAccount: username,
      loginPwd: encrypt(password)
    })
    if (res.code === 0) {
      // message.success(t('登录成功'))
      global.setUserInfo(res.data || {})
      setItem('Authorization', res.data?.token)
      navigate('/', { replace: true })
    }
  }
  return (
    <div className={styles['login-body']}>
      <div className={styles['login-form-container']}>
        <Form
          className={styles['login-form']}
          initialValues={{
            username: '',
            password: ''
          }}
          onFinish={onFinish}
        >
          <Form.Item>
            <div className={styles['login-title']}>
              <Avatar src='https://staticintl.cloudcachetci.com/cms/backend-cms/naaw358_%E5%90%88%E8%A7%84.png' alt='logo' style={{width: 100, height: 100}} />
              <h1 className={styles['login-title']}>{t('CDZ运营管理平台')}</h1>
            </div>
          </Form.Item>
          <Form.Item
            name='username'
            rules={[
              {
                required: true,
                message: () => t('请输入用户名'),
              },
            ]}
          >
            <Input
              prefix={<UserOutlined className='site-form-item-icon' />}
              size='large'
              placeholder={t('请输入用户名')}
              className={styles['login-form-input']}
            />
          </Form.Item>
          <Form.Item
            name='password'
            rules={[
              {
                required: true,
                message: t('请输入密码'),
              },
            ]}
          >
            <Input
              prefix={<LockOutlined className='site-form-item-icon' />}
              type='password'
              size='large'
              placeholder={t('请输入密码')}
              className={styles['login-form-input']}
            />
          </Form.Item>
          {/* <Form.Item>
            <Link to='/'>{t('忘记密码')}</Link>
          </Form.Item> */}
          <Form.Item>
            <Button
              type='primary'
              block
              htmlType='submit'
              className={styles['login-form-button']}
            >
              {t('登录')}
            </Button>
          </Form.Item>
          <Form.Item>
            <Button
              type='link'
              className={styles['change-locale']}
              onClick={handleChangeLang}
            >
              {global.locale === 'zh' ? 'English' : '简体中文'}
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  )
}

export default Login
