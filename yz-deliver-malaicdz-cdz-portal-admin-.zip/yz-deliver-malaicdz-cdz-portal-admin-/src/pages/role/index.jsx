import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Space, Table, Input, Button, Switch, message, Modal, Card } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/role'
import CreateRole from './createRole'
import SetAccess from './setAccess'
import ContentTitle from '@/components/contentTitle'

function RoleManage () {
  const { t } = useTranslation()
  const [keyword, setKeyword] = useState('')
  const [tableData, setTableData] = useState([])
  const [pageNo, setPageNo] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totals, setTotals] = useState(0)
  const [loading, setLoading] = useState(false)
  const [openCreate, setOpenCreate] = useState(false)
  const [openAccess, setOpenAccess] = useState(false)
  const [roleInfoCreate, setRoleInfoCreate] = useState({})  // 当前新建编辑的角色
  const [roleInfoAccess, setRoleInfoAccess] = useState({}) // 当前设置权限的角色
  useEffect(() => {
    queryRoleList()
  }, [pageNo, pageSize, keyword])

  // 分页查询角色列表
  const queryRoleList = async () => {
    setLoading(true)
    const res = await API.roleQuery({
      current: pageNo,
      size: pageSize,
      key: keyword
    })
    const { records = [], total = 0 } = res.data || {}
    setLoading(false)
    setTableData(records)
    setTotals(total)
  }
  // 切换状态
  const changeRoleStatus = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要改变状态?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('角色名称')}: ${record.roleName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.roleStatus({ id: record.id, status: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryRoleList()
        }
      }
    })
  }
  // 点击创建
  const clickCreateRole = () => {
    setRoleInfoCreate({})
    setOpenCreate(true)
  }
  // 点击编辑
  const clickEditRole = (record) => {
    setRoleInfoCreate(record)
    setOpenCreate(true)
  }
  // 点击设置权限
  const clickSetAccess = (record) => {
    setRoleInfoAccess(record)
    setOpenAccess(true)
  }
  // 点击删除
  const clickDeleteRole = (record) => {
    Modal.confirm({
      title: t('确认是否要删除?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('角色名称')}: ${record.roleName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.roleDelete({ id: record.id })
        if (res.code === 0) {
          message.success(t('删除成功'))
          queryRoleList()
        }
      }
    })

  }
  // 新建编辑回调
  const handleRoleCreateSubmit = () => {
    setOpenCreate(false)
    if (roleInfoCreate.id) {
      queryRoleList()
    } else {
      pageNo === 1 ? queryRoleList() : setPageNo(1)
    }
  }
  // 设置权限回调
  const handleRoleAccessSubmit = () => {
    setOpenAccess(false)
    queryRoleList()

  }
  const columns = [
    {
      title: t('序号'),
      key: 'index',
      width: 80,
      render: (text, record, index) => <span>{(pageNo - 1) * pageSize + index + 1}</span>,
    },
    {
      title: t('角色名称'),
      dataIndex: 'roleName',
    },
    {
      title: t('角色描述'),
      dataIndex: 'roleDescribe',
      width: 200,
      ellipsis: true
    },
    {
      title: t('创建时间'),
      dataIndex: 'createTime',
      // render: (text, record, index) => <span>{text}</span>,
    },
    {
      title: t('更新时间'),
      dataIndex: 'updateTime',
    },
    {
      title: t('角色状态'),
      dataIndex: 'status',
      width: 100,
      render: (_, record) => <Switch checked={!!record.status} onChange={(status) => changeRoleStatus(record, status)} />,
    },
    {
      title: t('操作'),
      width: 200,
      key: 'action',
      render: (_, record) => (
        <Space size='middle'>
          <a onClick={() => clickSetAccess(record)}>{t('设置权限')}</a>
          <a onClick={() => clickEditRole(record)}>{t('编辑')}</a>
          <a onClick={() => clickDeleteRole(record)}>{t('删除')}</a>
        </Space>
      ),
    },
  ]
  return (
    <>
      <div className={styles['role-manage']}>
        <div className={styles['title']}>
          <ContentTitle title={t('角色管理')}/>
        </div>
        <Card bordered={false}>

          <div className={styles['search-content']}>
            <Button
              type='primary'
              className={styles['add-btn']}
              onClick={clickCreateRole}
              size='middle'
            >
              {t('新增角色')}
            </Button>
            <Input.Search
              placeholder={t('请输入角色名称')}
              className={styles['search-ipt']}
              onSearch={(val) => {
                setPageNo(1)
                setKeyword(val)
              }}
              enterButton
              allowClear
            />
          </div>
          <div className={styles['table-content']}>
            <Table
              dataSource={tableData}
              columns={columns}
              rowKey='id'
              loading={loading}
              pagination={{
                showQuickJumper: true,
                showSizeChanger: true,
                pageSize,
                current: pageNo,
                total: totals,
                showTotal: total => `${t('共')} ${total} ${t('条')}`
              }}
              onChange={(pagination) => {
                setPageNo(pagination.current)
                setPageSize(pagination.pageSize)
              }}
              size='small'
              responsive
            />
          </div>
        </Card>
      </div>
      {/* 创建/编辑角色 */}
      <CreateRole
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        roleId={roleInfoCreate.id}
        onSubmit={handleRoleCreateSubmit}
      />
      {/* 设置角色权限 */}
      <SetAccess
        open={openAccess}
        onClose={() => setOpenAccess(false)}
        roleInfo={roleInfoAccess}
        onSubmit={handleRoleAccessSubmit}
      />
    </>

  )
}

export default RoleManage
