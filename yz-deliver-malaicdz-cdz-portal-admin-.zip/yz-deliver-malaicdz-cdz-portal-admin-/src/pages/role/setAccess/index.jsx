import React, { useEffect, useState } from 'react'
// import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Tree, Alert, Checkbox, message } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/role'


function SetAccess ({ roleInfo, open, onClose, onSubmit }) {
  const { t } = useTranslation()
  const [accessTreeData, setAccessTreeData] = useState([])
  const [initAccessTreeData, setInitAccessTreeData] = useState([])
  const [accessPageList, setAccessPageList] = useState([])
  const [selectedKeys, setSelectedKeys] = useState([])
  const [confirmLoading, setConfirmLoading] = useState(false)
  useEffect(() => {
    open && getAccessTree()
  }, [open])

  // 获取角色权限初始化
  const getAccessTree = async () => {
    const res = await API.roleAccess({ id: roleInfo.id })
    const treeData = res?.data?.menuList || []
    const allPageList = treeData.map(nodeItem => nodeItem.pageList).flat()
    allPageList.forEach(pageItem => {
      pageItem.checkAll = pageItem.buttonList.length && pageItem.buttonList.every(btnItem => btnItem.checked)
    })
    const allChecked = treeData.some(nodeItem => nodeItem.checked)
    const accessData = [{
      id: '0',
      name: t('全部权限'),
      children: treeData,
      pageList: allPageList,
      type: 1,
      checked: allChecked,
      parentId: ''
    }]
    setAccessTreeData(accessData)
    setInitAccessTreeData(accessData)
    setSelectedKeys(['0'])
    setAccessPageList(allPageList)
  }
  // 提交保存权限
  const submitAccess = async () => {
    const treeData = [...accessTreeData]
    // 获取勾选的菜单
    const menuIds = []
    const loopMenucheck = (arr) => {
      arr.forEach(nodeItem => {
        if (nodeItem.checked && nodeItem.type === 1 && nodeItem.id !== '0') {
          menuIds.push(nodeItem.id)
        }
        loopMenucheck(nodeItem.children)
      })
    }
    loopMenucheck(treeData)
    if (!menuIds.length) {
      return message.error(t('必须选择菜单权限'))
    }
    // 获取勾选的权限按钮
    const allPageList = treeData[0]?.pageList
    const buttonIds = allPageList
      .map(pageItem => pageItem.buttonList)
      .flat()
      .filter(btnItem => btnItem.checked)
      .map(btn => btn.id)
    setConfirmLoading(true)
    const res = await API.roleReset({ id: roleInfo.id, menuIds, buttonIds })
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success({ content: t('权限设置成功'), duration: 1 })
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    submitAccess()
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(accessTreeData) === JSON.stringify(initAccessTreeData)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })
    }
  }
  // 树节点勾选
  const handleOnCheck = (id, parentId, val) => {
    // 为了比较treeData差异所以深拷贝一下
    const treeData = JSON.parse(JSON.stringify(accessTreeData))
    // 子节点递归
    const loopChildCheck = (arr, val) => {
      arr.forEach(nodeItem => {
        nodeItem.checked = val
        loopChildCheck(nodeItem.children, val)
      })
    }
    // 父节点递归
    const loopParentCheck = (parentId) => {
      const loopcheck = (arr) => {
        arr.forEach(nodeItem => {
          if (nodeItem.id === parentId) {
            nodeItem.checked = nodeItem.children.some(child => child.checked)
            loopParentCheck(nodeItem.parentId)
          } else {
            loopcheck(nodeItem.children)
          }
        })
      }
      loopcheck(treeData)
    }
    // 当前节点递归
    const loop = (arr) => {
      arr.forEach(nodeItem => {
        if (nodeItem.id === id) {
          nodeItem.checked = val
          nodeItem.children.forEach(child => {
            child.checked = val
            loopChildCheck(child.children, val)
          })
        } else {
          loop(nodeItem.children)
        }
      })
      arr.forEach(nodeItem => {
        if (nodeItem.id === parentId) {
          nodeItem.checked = nodeItem.children.some(child => child.checked)
          loopParentCheck(nodeItem.parentId)
        } else {
          loop(nodeItem.children)
        }
      })
    }
    loop(treeData)
    setAccessTreeData(treeData)
  }
  // 树节点选中
  const handleOnSelect = ([id]) => {
    const treeData = [...accessTreeData]
    const loop = (arr) => {
      arr.forEach(nodeItem => {
        if (nodeItem.id === id) {
          const pageList = nodeItem.pageList.map(pageItem => {
            const checkAll = pageItem.buttonList.length && pageItem.buttonList.every(btn => btn.checked)
            return ({ ...pageItem, checkAll })
          })
          setAccessPageList(pageList)
        } else {
          loop(nodeItem.children)
        }
      })
    }
    loop(treeData)
    setSelectedKeys([id])
  }
  // 页面权限按钮全选
  const onCheckAllChange = (pageId, val) => {
    const pageList = [...accessPageList]
    pageList.forEach(pageItem => {
      if (pageItem.id === pageId) {
        pageItem.buttonList.forEach(buttonItem => {
          buttonItem.checked = val
        })
        pageItem.checkAll = val
        syncToAccessTreePageList(pageItem)

      }
    })
    setAccessPageList(pageList)
  }
  // 页面权限按钮勾选
  const onCheckButtonChange = (pageId, buttonId, val) => {
    const pageList = [...accessPageList]
    pageList.forEach(pageItem => {
      if (pageItem.id === pageId) {
        pageItem.buttonList.forEach(buttonItem => {
          if (buttonItem.id === buttonId) {
            buttonItem.checked = val
          }
        })
        pageItem.checkAll = pageItem.buttonList.every(btn => btn.checked)
        syncToAccessTreePageList(pageItem)
      }
    })
    setAccessPageList(pageList)

  }
  // 同步页面权限按钮到树节点
  const syncToAccessTreePageList = (pageItem) => {
    // 为了比较treeData差异所以深拷贝一下
    const treeData = JSON.parse(JSON.stringify(accessTreeData))
    const loop = (arr) => {
      arr.forEach(nodeItem => {
        nodeItem.pageList.forEach(pt => {
          if (pt.id === pageItem.id) {
            pt.buttonList = pageItem.buttonList
            pt.checkAll = pageItem.checkAll
          }
        })
        loop(nodeItem.children)
      })
    }
    loop(treeData)
    setAccessTreeData(treeData)
  }

  return (
    <Modal
      className={styles['set-access']}
      title={roleInfo.roleName + t('权限设置')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={900}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <div className={styles['hd']}>
        <Alert
          message={t('功能权限：用来控制角色用户有哪些菜单页面，以及菜单页面对应的功能操作')}
          type='info'
          showIcon
        />
      </div>
      <div className={styles['bd']}>
        <div className={styles['left']}>
          {
            accessTreeData.length > 0 && <Tree
              defaultExpandAll={true}
              selectedKeys={selectedKeys}
              onSelect={handleOnSelect}
              fieldNames={{
                title: 'name',
                key: 'id'
              }}
              titleRender={({ name, type, checked, id, parentId }) => {
                return type === 1 ?
                  <Checkbox
                    checked={checked}
                    onChange={(e) => handleOnCheck(id, parentId, e.target.checked)}
                  >
                    {name}
                  </Checkbox> : <span>{name}</span>
              }}
              treeData={accessTreeData}
            />
          }
        </div>
        <div className={styles['right']}>
          <ul className={styles['access-list']}>
            {
              accessPageList.map(pageItem => (

                <li className={styles['access-item']} key={pageItem.id}>
                  <div className={styles['title']}>
                    <p>{pageItem.name}</p>
                    <Checkbox
                      checked={pageItem.checkAll}
                      onChange={(e) => onCheckAllChange(pageItem.id,  e.target.checked)}
                      disabled={!pageItem.buttonList?.length}
                    >
                      {t('全选')}
                    </Checkbox>
                  </div>
                  <div className={styles['group']}>
                    {
                      pageItem.buttonList.length ? pageItem.buttonList.map(buttonItem => (
                        <Checkbox
                          className={styles['checkbox-item']}
                          key={buttonItem.id}
                          checked={buttonItem.checked}
                          onChange={(e) => onCheckButtonChange(pageItem.id, buttonItem.id, e.target.checked)}
                        >
                          {buttonItem.name}
                        </Checkbox>
                      )) : <p className={styles['no-btn']}>{t('无')}</p>
                    }
                  </div>
                </li>
              ))
            }

          </ul>
        </div>
      </div>
    </Modal>
  )
}

export default SetAccess
