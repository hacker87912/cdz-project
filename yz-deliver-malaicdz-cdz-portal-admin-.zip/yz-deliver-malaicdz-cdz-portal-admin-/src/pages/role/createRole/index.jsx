import React, { useEffect, useState } from 'react'
// import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Input, message, Switch } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/role'


function CreateRole ({ roleId, open, onClose, onSubmit }) {
  const { t } = useTranslation()
  const [roleInfo, setRoleInfo] = useState({})
  const [initRoleInfo, setInitRoleInfo] = useState({})
  const [confirmLoading, setConfirmLoading] = useState(false)
  const [form] = Form.useForm()
  useEffect(() => {
    if (open) {
      queryRoleInfo()
    }
  }, [open])
  // 初始化
  const queryRoleInfo = async () => {
    const initData = {
      roleName: '',
      roleDescribe: '',
      status: true
    }
    setRoleInfo(initData)
    setInitRoleInfo(initData)
    form.setFieldsValue(initData)
    if (roleId) {
      const res = await API.roleCheck({ id: roleId })
      const resData = res?.data || {}
      const roleData = {
        ...resData,
        status: !!resData.status
      }
      setRoleInfo(roleData)
      setInitRoleInfo(roleData)
      form.setFieldsValue(roleData)
    }

  }
  // 提交表单数据
  const submitRole = async () => {
    const postData = {
      ...roleInfo,
      status: +roleInfo.status
    }
    let roleApi = API.roleAdd
    let msg = t('创建成功')

    if (roleId) {
      postData.id = roleId
      roleApi = API.roleEdit
      msg = t('编辑成功')
    }
    setConfirmLoading(true)
    const res = await roleApi(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(msg)
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitRole()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(roleInfo) === JSON.stringify(initRoleInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setRoleInfo({
      ...roleInfo,
      ...changedValues
    })
  }
  return (
    <Modal
      className={styles['create-role']}
      title={roleId ? t('编辑') : t('新增')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Form
        form={form}
        name='role-form'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Form.Item
          label={t('角色名称')}
          name='roleName'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入角色名称'),
            },
            {
              type: 'string',
              min: 1,
              max: 50,
              message: t('角色名称长度最多50位'),
            },
          ]}
        >
          <Input placeholder={t('请输入角色名称')} />
        </Form.Item>
        <Form.Item
          label={t('角色描述')}
          name='roleDescribe'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入角色描述'),
            }
          ]}
        >
          <Input.TextArea placeholder={t('请输入角色描述')} maxLength={500} showCount />
        </Form.Item>
        <Form.Item
          label={t('角色状态')}
          name='status'
          valuePropName='checked'
          required
        >
          <Switch />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default CreateRole
