import React, { useState, useEffect } from 'react'
import { Modal, Card, Table, Typography, Button, Space, Switch, message } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import NavModal from './components/navModal'
import { navBarQuery, addNavMenu, editNavMenu, deleteNavMenu, editNavStatus, editNavSort, navBarDetail } from '@/services/topNav'
import Layout from '@/pages/expense/components/Layout'
import { useStore } from '@/store'
import { toJS } from 'mobx'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import { useTranslation } from 'react-i18next'
import Title from '@/components/localeTitle'

const { Link } = Typography
const { confirm } = Modal

function TopNav () {
  const { t } = useTranslation()
  const [dataSource, setDataSource] = useState([])
  const [formOpen, setFormOpen] = useState('')
  const { topNav } = useStore()
  const [entranceOptions, setEntranceOptions] = useState([])
  const [classifyOptions, setClassifyOptions] = useState([])
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [loading, setLoading] = useState(false)
  const [record, setRecord] = useState({})

  const selectData = async () => {
    await topNav.getNavEntrance()
    await topNav.getNavClassify()
  }

  useEffect(() => {
    selectData().then(() => {
      setEntranceOptions(toJS(topNav.navEntranceData).map(e => ({ label: `${e.name}/${e.enName}`, value: e.id })))
      setClassifyOptions(toJS(topNav.navClassifyData).map(e => ({ label: `${e.name}/${e.enName}`, value: e.id })))
    })
  }, [])

  const getData = async () => {
    setLoading(true)
    const res =  await navBarQuery({
      current: current,
      size: pageSize,
    })
    const { data: { records = [], total = 0 } = {} } = res
    setDataSource(records)
    setPaging((e => ({ ...e, total })))
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && current > totalPage) {
      setPaging((e => ({ ...e, current: totalPage })))
    }
    setLoading(false)
  }

  const init = () => {
    setPaging({ current: 1, pageSize: 10, total: 0 })
    return { current: '1', pageSize: '10' }
  }

  useUpdateEffect((didMount) => {
    getData()
    didMount && setSearchParams({ current, pageSize })
    return true
  }, [current, pageSize], init, getData)

  const infoState = (res) => {
    if (res.code === 0) {
      message.success(res.msg)
      getData()
    }
  }

  const add = async (values) => {
    delete values.id
    const res = await addNavMenu({ ...values })
    infoState(res)
  }

  const edit = async (values) => {
    const res = await editNavMenu({ ...values })
    infoState(res)
  }

  const editSort = async (values) => {
    const { id, sort } = values
    const res = await editNavSort({ id, sort })
    infoState(res)
  }

  const deleteConfirm = (id) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要删除?'),
      async onOk () {
        const res = await deleteNavMenu(id)
        infoState(res)
      },
    })
  }

  const switchChange = (e, info) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要改变状态?'),
      async onOk () {
        const { id } = info
        const res = await editNavStatus({ id, status: e ? 1 : 0 })
        infoState(res)
      },
    })
  }

  const columns = [
    {
      title: t('导航入口'),
      dataIndex: 'entrance',
      key: 'entrance',
      width: 200,
      render: (_, record) => <Title name={record.entranceName} enName={record.entranceEnName} width={200} />
    },
    {
      title: t('菜单分类'),
      dataIndex: 'classify',
      key: 'classify',
      width: 200,
      render: (_, record) => <Title name={record.classifyName} enName={record.classifyEnName} width={200} />
    },
    {
      title: t('菜单名称'),
      dataIndex: 'name',
      key: 'name',
      width: 150,
      render: (_, record) => <Title name={record.name} enName={record.enName} width={150} />
    },
    {
      title: t('跳转URL'),
      dataIndex: 'url',
      key: 'url',
      width: 200,
      render: (_, record) => <Title name={record.classifyName} enName={record.classifyEnName} width={200} />
    },
    {
      title: t('是否显示'),
      dataIndex: 'status',
      key: 'status',
      render: (text, record) => (<Switch checked={text} onChange={(e) => switchChange(e, record) } />)
    },
    {
      title: t('排序'),
      dataIndex: 'sort',
      key: 'sort',
    },
    {
      title: t('操作'),
      dataIndex: 'operation',
      key: 'operation',
      render: (_, _record) => (
        <Space>
          <Link onClick={() => formEdit(_record.id, 'edit')}>{t('编辑')}</Link>
          <Link onClick={() => formEdit(_record.id, 'sort')}>{t('排序')}</Link>
          <Link onClick={() => deleteConfirm(_record.id)}>{t('删除')}</Link>
        </Space>
      )
    },
  ]

  const formEdit = async (id, key) => {
    setLoading(true)
    const res = await navBarDetail(id)
    setRecord(res.data || {})
    setFormOpen(key)
    setLoading(false)
  }

  return (
    <Layout title={t('顶部导航')}>
      <Card bordered={false}>
        <Button type='primary' style={{ marginBottom: '10px' }} onClick={() => setFormOpen('add')}>{t('新增导航菜单入口')}</Button>
        <Table
          loading={loading}
          rowKey="id"
          size='small'
          columns={columns}
          dataSource={dataSource}
          pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100], showTotal: total => `${t('共')} ${total} ${t('条')}` }}
          onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
        />
      </Card>
      <NavModal
        portFunc={formOpen === 'add' ? add : formOpen === 'edit' ? edit : editSort }
        open={formOpen}
        setOpen={setFormOpen}
        title={formOpen === 'add' ? t('新增') : (formOpen === 'edit' ? t('编辑') : (formOpen === 'sort' ? t('排序') : '')) }
        entranceOptions={entranceOptions}
        classifyOptions={classifyOptions}
        record={record}
      />
    </Layout>
  )
}
export default TopNav
