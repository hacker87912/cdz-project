import React from 'react'
import Template from '../components/template'
import Layout from '@/pages/expense/components/Layout'
import { addNavEntrance, editNavEntrance, deleteNavEntrance, editEntranceSort, navEntranceDetail, navEntranceQuery } from '@/services/topNav'
import { useTranslation } from 'react-i18next'

function Entry () {
  const { t } = useTranslation()
  return (
    <Layout title={t('导航入口')} showBack path="/cms/topnav">
      <Template
        title="导航入口"
        add={addNavEntrance}
        edit={editNavEntrance}
        deleteFunc={deleteNavEntrance}
        getApi={navEntranceQuery}
        editSort={editEntranceSort}
        getDetail={navEntranceDetail}
      />
    </Layout>
  )
}
export default Entry
