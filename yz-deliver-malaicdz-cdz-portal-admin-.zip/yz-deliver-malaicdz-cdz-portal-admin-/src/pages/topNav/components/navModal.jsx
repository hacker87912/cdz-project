import React, { useState, useEffect } from 'react'
import { Modal, Form, Input, Switch, InputNumber, Select, Typography, Row } from 'antd'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

const { Link } = Typography

function NavModal ({ open, setOpen, title = '', portFunc = () => {}, entranceOptions = [], classifyOptions = [], record }) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [form] = Form.useForm()
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open === 'edit' || open === 'sort') {
      const { id, entrance, classify, name, enName, status, url, sort } = record
      form.setFieldsValue({ id, entrance, classify, name, enName, status, url, sort })
    }
  }, [record, open])

  const clear = () => {
    setConfirmLoading(false)
    setOpen(false)
    form.resetFields()
  }

  const onFinish = async (_values) => {
    setConfirmLoading(true)
    const values = { ..._values, ...form.getFieldsValue(true) }
    await portFunc({ ...values, id: form.getFieldValue('id') })
    clear()
  }
  const onOk = () => {
    form.submit()
  }

  const onValuesChange = (changedValues) => {
    const [key] = Object.keys(changedValues)
    if (key === 'status') {
      form.setFieldValue('status', changedValues['status'] ? 1 : 0)
    }
  }
  return (
    <>
      <Modal
        width={open === 'add' ? 800 : (open === 'edit' ? 800 : 600)}
        title={title}
        open={open}
        onOk={onOk}
        onCancel={clear}
        confirmLoading={confirmLoading}
        maskClosable={false}
      >
        <Form
          labelCol={{
            span: open === 'add' ? 6 : (open === 'edit' ? 6 : 4),
          }}
          style={{ padding: '20px 60px 20px 0'}}
          form={form}
          onFinish={onFinish}
          onValuesChange={onValuesChange}
          initialValues={{ status: 1 }}
        >
          {!(title === t('排序')) && (
            <>
              <Row style={{ marginLeft: '5px' }}>
                <Form.Item
                  style={{ flex: 1, marginRight: '5px', overflow: 'hidden' }}
                  label={t('导航入口')}
                  name="entrance"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                  ]}
                >
                  <Select
                    options={entranceOptions}
                  />
                </Form.Item>
                <Link onClick={() => navigate('/cms/topnav/entry')} style={{ height: '30px', lineHeight: '30px' }}>{t('管理')}</Link>
              </Row>
              <Row style={{ marginLeft: '5px' }}>
                <Form.Item
                  style={{ flex: 1, marginRight: '5px', overflow: 'hidden' }}
                  label={t('菜单分类')}
                  name="classify"
                  rules={[
                    {
                      required: true,
                      message: t('请必填')
                    },
                  ]}
                >
                  <Select
                    style={{ flex: 1, marginRight: '5px' }}
                    options={classifyOptions}
                  />
                </Form.Item>
                <Link onClick={() => navigate('/cms/topnav/classify')} style={{ height: '30px', lineHeight: '30px' }}>{t('管理')}</Link>
              </Row>
              <Form.Item
                label={t('菜单名称(中文)')}
                name="name"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 30,
                    message: t('名称长度最多30位'),
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('菜单名称(英文)')}
                name="enName"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 100,
                    message: t('名称长度最多100位'),
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t('是否显示')}
                name="status"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
              <Form.Item
                label={t('跳转URL')}
                name="url"
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                ]}
              >
                <Input />
              </Form.Item>
            </>
          )}
          <Form.Item
            label={t('排序')}
            name="sort"
            help={t('输入数字，数字越小排在最前面')}
            rules={[
              {
                required: true,
                message: t('请必填')
              },
            ]}
          >
            <InputNumber style={{ width: '400px' }} />
          </Form.Item>

        </Form>

      </Modal>
    </>
  )
}
export default NavModal
