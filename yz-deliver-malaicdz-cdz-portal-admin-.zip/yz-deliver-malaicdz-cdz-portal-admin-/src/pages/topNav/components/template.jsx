import { Button, Table, Space, Typography, Card, Modal, Form, Input, InputNumber, message } from 'antd'
import React, { useEffect, useState } from 'react'
import { ExclamationCircleFilled } from '@ant-design/icons'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import { useTranslation } from 'react-i18next'
import Title from '@/components/localeTitle'

const { Link } = Typography
const { confirm } = Modal

function Template ({
  title = '',
  add = () => {},
  edit = () => {},
  deleteFunc = () => {},
  getApi = () => {},
  editSort = () => {},
  getDetail = () => {},
  fields = ['name', 'enName', 'sort']
}) {
  const { t } = useTranslation()
  const [formOpen, setFormOpen] = useState('')
  const [form] = Form.useForm()
  const [confirmLoading, setConfirmLoading] = useState(false)
  const [record, setRecord] = useState({})
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState([])
  const [_name, _enName, _sort] = fields

  const getData = async () => {
    setLoading(true)
    const res = await getApi({
      current: current,
      size: pageSize,
    })
    const { data: { records = [], total = 0 }} = res
    setData(records)
    setPaging((e => ({ ...e, total })))
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && current > totalPage) {
      setPaging((e => ({ ...e, current: totalPage })))
    }
    setLoading(false)
  }

  const init = () => {
    setPaging({ current: 1, pageSize: 10, total: 0 })
    return { current: '1', pageSize: '10' }
  }

  useUpdateEffect((didMount) => {
    getData()
    didMount && setSearchParams({ current, pageSize })
    return true
  }, [current, pageSize], init, getData)

  const infoState = (res) => {
    if (res.code === 0) {
      message.success(res.msg)
      getData()
    }
  }

  const deleteConfirm = (id) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要删除?'),
      async onOk () {
        const res = await deleteFunc(id)
        infoState(res)
      },
    })
  }

  const columns = [
    {
      title: t(title),
      dataIndex: _name,
      key: _name,
      width: 400,
      render: (_, record) => <Title width={400} name={record[_name]} enName={record[_enName]} />
    },
    {
      title: t('排序'),
      dataIndex: _sort,
      key: _sort,
    },
    {
      title: t('操作'),
      dataIndex: 'operation',
      key: 'operation',
      render: (_, _record) => (
        <Space size='middle'>
          <Link onClick={() => formEdit(_record.id, 'edit')}>{t('编辑')}</Link>
          <Link onClick={() => formEdit(_record.id, 'sort')}>{t('排序')}</Link>
          <Link onClick={() => deleteConfirm(_record.id)}>{t('删除')}</Link>
        </Space>
      )
    },
  ]

  const formEdit = async (id, key) => {
    setLoading(true)
    const res = await getDetail(id)
    setRecord(res.data || {})
    setFormOpen(key)
    setLoading(false)
  }

  useEffect(() => {
    if (formOpen === 'edit' || formOpen === 'sort') {
      form.setFieldsValue({ id: record.id, [_name]: record[_name], [_enName]: record[_enName], [_sort]: record[_sort] })
    }
  }, [record, formOpen])

  const onOk = () => {
    form.submit()
  }

  const clear = () => {
    setConfirmLoading(false)
    setFormOpen('')
    form.resetFields()
  }

  const onFinish = async (values) => {
    setConfirmLoading(true)
    let res
    if (formOpen === 'add') {
      res = await add(values)
    } else if (formOpen === 'edit') {
      res = await edit({ ...values, id: form.getFieldValue('id') })
    } else if (formOpen === 'sort') {
      res = await editSort({ id: form.getFieldValue('id'), sort: values.sort })
    }
    infoState(res)
    clear()
  }
  return (
    <>
      <Card bordered={false}>
        <Button type='primary' style={{ marginBottom: '10px' }} onClick={() => setFormOpen('add')}>{t(`新增${title}`)}</Button>
        <Table
          loading={loading}
          rowKey="id"
          size='small'
          columns={columns}
          dataSource={data}
          pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100], showTotal: total => `${t('共')} ${total} ${t('条')}` }}
          onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
        />
      </Card>
      <Modal
        width={formOpen === 'add' ? 800 : (formOpen === 'edit' ? 800 : 600)}
        title={formOpen === 'add' ? t('新增') : (formOpen === 'edit' ? t('编辑') : t('排序'))}
        open={formOpen}
        onOk={onOk}
        onCancel={clear}
        confirmLoading={confirmLoading}
        maskClosable={false}
      >
        <Form
          labelCol={{
            span: formOpen === 'add' ? 7 : (formOpen === 'edit' ? 7 : 4),
          }}
          wrapperCol={{
            span: 16,
          }}
          style={{ padding: '20px 0'}}
          form={form}
          onFinish={onFinish}
        >
          {!(formOpen === 'sort') && (
            <>
              <Form.Item
                label={t(`${title}(中文)`)}
                name={_name}
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 10,
                    message: t('长度最多10位'),
                  },
                ]}
              >
                <Input />
              </Form.Item>
              <Form.Item
                label={t(`${title}(英文)`)}
                name={_enName}
                rules={[
                  {
                    required: true,
                    whitespace: true,
                    message: t('请必填')
                  },
                  {
                    type: 'string',
                    min: 1,
                    max: 50,
                    message: t('长度最多50位'),
                  },
                ]}
              >
                <Input />
              </Form.Item>
            </>
          )}
          <Form.Item
            label={t('排序')}
            name={_sort}
            help={t('输入数字，数字越小排在最前面')}
            rules={[
              {
                required: true,
                message: t('请必填')
              },
            ]}
          >
            <InputNumber style={{ width: '400px' }} />
          </Form.Item>

        </Form>

      </Modal>
    </>
  )
}
export default Template
