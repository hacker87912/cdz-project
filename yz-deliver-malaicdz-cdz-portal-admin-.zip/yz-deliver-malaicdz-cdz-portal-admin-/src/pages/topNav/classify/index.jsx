import React from 'react'
import Template from '../components/template'
import Layout from '@/pages/expense/components/Layout'
import { addNavClassify, editNavClassify, deleteNavClassify, editClassifySort, navClassifyDetail, navClassifyQuery } from '@/services/topNav'
import { useTranslation } from 'react-i18next'

function Classify () {
  const { t } = useTranslation()
  return (
    <Layout title={t('菜单分类')} showBack path="/cms/topnav">
      <Template
        title='菜单分类'
        add={addNavClassify}
        edit={editNavClassify}
        deleteFunc={deleteNavClassify}
        getApi={navClassifyQuery}
        editSort={editClassifySort}
        getDetail={navClassifyDetail}
      />
    </Layout>
  )
}
export default Classify
