import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Space, Card, Spin, Typography } from 'antd'
import ContentTitle from '@/components/contentTitle'
import { getDetailById } from '@/services/messages'
import { useTranslation } from 'react-i18next'

const { Title, Text } = Typography

function Detail () {
  const { t } = useTranslation()
  const params = useParams()
  const [data, setData] = useState({})
  const [loading, setLoading] = useState(true)

  const getData = async () => {
    const res = await getDetailById(params.id)
    setData(res.data)
    setLoading(false)
  }

  useEffect(() => {
    getData()
  }, [])

  return (
    <Spin spinning={loading}>
      <Space
        direction="vertical"
        size="middle"
        style={{ display: 'flex' }}
      >
        <ContentTitle title={t('公告详情')} showBack />
        {!loading && (
          <Card bordered={false}>
            <Title>{data.title}</Title>
            <Text type="secondary">{t('发布时间')}：{data.releaseTime}</Text>
            <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.content }} style={{ marginTop: '16px' }} />
          </Card>
        )}
        {!loading && (
          <Card bordered={false}>
            <Title>{data.enTitle}</Title>
            <Text type="secondary">{t('发布时间')}：{data.releaseTime}</Text>
            <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.enContent }} style={{ marginTop: '16px' }} />
          </Card>
        )}
      </Space>
    </Spin>
  )
}

export default Detail
