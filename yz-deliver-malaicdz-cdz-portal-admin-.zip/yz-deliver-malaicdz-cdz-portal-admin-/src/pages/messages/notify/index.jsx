import React, { useState, useEffect } from 'react'
import { Space, Card, Input, Modal, Typography, Table, Row, Button, Switch, Form, message } from 'antd'
import ContentTitle from '@/components/contentTitle'
import useSearchParams from '@/hooks/useSearchParams'
import useUpdateEffect from '@/hooks/useUpdateEffect'
import { ExclamationCircleFilled } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import Editor from '@/components/editor'
import { addNotification, editNotification, getNotification, updateReleaseStatus, getDetailById, deleteNotification } from '@/services/messages'
import { useTranslation } from 'react-i18next'
import Title from '@/components/localeTitle'

const { Link } = Typography
const { Search } = Input
const { confirm } = Modal

function FormBox ({ open, setOpen, title = '', record, portFunc = () => {} }) {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open === 'edit') {
      const { id, title, enTitle, content, enContent, releaseStatus } = record
      form.setFieldsValue({ id, title, enTitle, content, enContent, releaseStatus })
    }
  }, [record, open])

  const onValuesChange = (changedValues) => {
    const [key] = Object.keys(changedValues)
    if (key === 'releaseStatus') {
      form.setFieldValue('releaseStatus', changedValues['releaseStatus'] ? 1 : 0)
    }
  }

  const clear = () => {
    setConfirmLoading(false)
    setOpen('')
    form.resetFields()
  }

  const onFinish = async (values) => {
    setConfirmLoading(true)
    await portFunc({ ...values, id: form.getFieldValue('id') }, clear)
  }

  const onOk = () => {
    form.submit()
  }

  return (
    <Modal forceRender width={800} title={title} open={open} onOk={onOk} onCancel={clear} confirmLoading={confirmLoading} maskClosable={false}>
      <Form
        form={form}
        labelCol={{
          span: 6,
        }}
        style={{ padding: '20px 60px 20px 0'}}
        onFinish={onFinish}
        onValuesChange={onValuesChange}
        initialValues={{ status: 0 }}
      >
        <Form.Item
          label={t('通知公告标题(中文)')}
          name="title"
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请必填')
            },
            {
              type: 'string',
              min: 1,
              max: 50,
              message: t('名称长度最多50位'),
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label={t('通知公告标题(英文)')}
          name="enTitle"
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请必填')
            },
            {
              type: 'string',
              min: 1,
              max: 200,
              message: t('名称长度最多200位'),
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label={t('产品内容(中文)')}
          name="content"
          rules={[
            {
              required: true,
              message: t('请必填')
            },
            {
              validator: (_, value) => {
                if (value !== '<p><br></p>') {
                  return Promise.resolve()
                }
                return Promise.reject(new Error(t('请必填')))
              },
              validateTrigger: 'onBlur'
            },
          ]}
        >
          <Editor />
        </Form.Item>
        <Form.Item
          label={t('产品内容(英文)')}
          name="enContent"
          rules={[
            {
              required: true,
              message: t('请必填')
            },
            {
              validator: (_, value) => {
                if (value !== '<p><br></p>') {
                  return Promise.resolve()
                }
                return Promise.reject(new Error(t('请必填')))
              },
              validateTrigger: 'onBlur'
            },
          ]}
        >
          <Editor />
        </Form.Item>
        <Form.Item
          label={t('是否发布')}
          name="releaseStatus"
          valuePropName="checked"
        >
          <Switch />
        </Form.Item>
      </Form>

    </Modal>
  )
}

function Notify () {
  const navigate = useNavigate()
  const { t } = useTranslation()
  const [loading, setLoading] = useState(false)
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [list, setList] = useState([])
  const [record, setRecord] = useState({})
  const [search, setSearch] = useState(searchParams.keyword || '')
  const [value, setValue] = useState(searchParams.keyword || '')
  const [formOpen, setFormOpen] = useState('')

  const getData = async () => {
    setLoading(true)
    const res =  await getNotification({
      current: current,
      size: pageSize,
      key: search
    })
    const { data: { records = [], total = 0 } = {} } = res
    setList(records)
    setPaging((e => ({ ...e, total })))
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && current > totalPage) {
      setPaging((e => ({ ...e, current: totalPage })))
    }
    setLoading(false)
  }

  const init = () => {
    setPaging({ current: 1, pageSize: 10, total: 0 })
    setValue('')
    setSearch('')
    return { current: '1', pageSize: '10' }
  }

  useUpdateEffect((didMount) => {
    getData()
    didMount && setSearchParams({ current, pageSize, keyword: search })
    return true
  }, [current, pageSize, search], init, getData)

  const columns = [
    { title: t('序号'), dataIndex: 'id', key: 'id', render: (text, record, index) => <span>{(current - 1) * pageSize + index + 1}</span>, },
    { title: t('通知公告标题'), dataIndex: 'title', key: 'title', width: 400, render: (_, _record) => (
      <Link onClick={() => navigate(`/message/notify/detail/${_record.id}`)}>
        <Title width={400} name={_record.title} enName={_record.enTitle} />
      </Link>
    ) },
    { title: t('发布时间'), dataIndex: 'releaseTime', key: 'releaseTime' },
    { title: t('是否发布'), dataIndex: 'releaseStatus', key: 'releaseStatus', render: (text, record) => (<Switch checked={text} onChange={(e) => switchChange(e, record) } />) },
    { title: t('操作'), dataIndex: 'operation', key: 'operation', render: (_, _record) => (
      <Space>
        <Link onClick={() => navigate(`/message/notify/detail/${_record.id}`)}>{t('查看')}</Link>
        <Link onClick={() => formEdit(_record.id)}>{t('编辑')}</Link>
        <Link onClick={() => deleteConfirm(_record.id)}>{t('删除')}</Link>
      </Space>
    ) },
  ]

  const switchChange = (e, info) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要改变状态?'),
      async onOk () {
        const { id } = info
        const res = await updateReleaseStatus({ id, releaseStatus: e ? 1 : 0 })
        infoState(res)
      },
    })
  }

  const formEdit = async (id) => {
    setLoading(true)
    const res = await getDetailById(id)
    setRecord(res.data || {})
    setFormOpen('edit')
    setLoading(false)
  }

  const deleteConfirm = (id) => {
    confirm({
      title: t('提示'),
      icon: <ExclamationCircleFilled />,
      content: t('确认是否要删除?'),
      async onOk () {
        const res = await deleteNotification(id)
        infoState(res)
      },
    })
  }

  const infoState = (res, clear = () => {}) => {
    if (res.code === 0) {
      message.success(res.msg)
      clear()
      getData()
    }
  }

  const add = async (values, clear) => {
    delete values.id
    const res = await addNotification({ ...values })
    infoState(res, clear)
  }

  const edit = async (values, clear) => {
    const res = await editNotification({ ...values })
    infoState(res, clear)
  }

  return (
    <Space
      direction="vertical"
      size="middle"
      style={{ display: 'flex' }}
    >
      <ContentTitle title={t('通知公告')} />
      <Card bordered={false}>
        <Row justify='space-between'>
          <Button type='primary' onClick={() => setFormOpen('add')}>{t('新增公告')}</Button>
          <Search
            enterButton
            placeholder={t('请输入通知公告标题')}
            allowClear
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onSearch={(v) => { setPaging((e) => ({ ...e, current: 1 })); setSearch(v) }}
            style={{
              width: 300,
            }}
          />
        </Row>
        <Table
          loading={loading}
          style={{ marginTop: '16px' }}
          rowKey="id"
          size='small'
          columns={columns}
          dataSource={list}
          pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100], showTotal: total => `${t('共')} ${total} ${t('条')}` }}
          onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
        />
      </Card>
      <FormBox
        open={formOpen}
        setOpen={setFormOpen}
        title={formOpen === 'add' ? t('新增') : t('编辑') }
        record={record}
        portFunc={formOpen === 'add' ? add : edit }
      />
    </Space>
  )
}

export default Notify
