import React, { useState, useEffect } from 'react'
import { Space, Card, Input, Modal, Typography, Table, Row, Select } from 'antd'
import ContentTitle from '@/components/contentTitle'
import useSearchParams from '@/hooks/useSearchParams'

const { Search } = Input
const { Link } = Typography

function SearchTableBox ({ isModal = false, loading, columns, data, paging, setPaging, placeholder }) {
  return (
    <>
      <Row justify='end'>
        <Space size='middle'>
          {isModal && (
            <>
              <Select
                style={{ width: 130 }}
                defaultValue='全部'
                options={[{ label: '全部', value: 0 }, { label: '已发送', value: 1 }, { label: '未发送', value: 2 }]}
              />
              <Select
                style={{ width: 130 }}
                defaultValue='全部'
                options={[{ label: '全部', value: 0 }, { label: '已查看', value: 1 }, { label: '未查看', value: 2 }]}
              />
            </>
          )}
          {!isModal && (
            <Select
              style={{ width: 130 }}
              defaultValue='全部'
              options={[{ label: '全部', value: 0 }, { label: '账单出账通知', value: 1 }, { label: '其他', value: 2 }]}
            />
          )}
          <Search
            enterButton
            placeholder={placeholder}
            allowClear
            // onSearch={setSearch}
            style={{
              width: 200,
            }}
          />
        </Space>
      </Row>
      <Table
        loading={loading}
        style={{ marginTop: '16px' }}
        rowKey="id"
        size='small'
        columns={columns}
        dataSource={data}
        pagination={{ ...paging, showSizeChanger: true, showQuickJumper: true, pageSizeOptions: [10, 20, 50, 100] }}
        onChange={({ current, pageSize }) => setPaging((e) => ({ ...e, current, pageSize }))}
      />
    </>
  )
}

function Mail () {
  const [loading, setLoading] = useState(false)
  const [searchParams, setSearchParams] = useSearchParams()
  const [paging, setPaging] = useState({ current: Number(searchParams.current) || 1, pageSize: Number(searchParams.pageSize) || 10, total: 0 })
  const { current, pageSize } = paging
  const [list, setList] = useState([])
  const [open, setOpen] = useState(false)

  const getData = async () => {
    const { data: { records = [], total = 0 } = {} } = {}
    setList([{ send: '发送', check: '查看' }])
    setPaging((e => ({ ...e, total })))
    setLoading(false)
  }

  useEffect(() => {
    // setLoading(true)
    getData()
    setSearchParams({ current, pageSize })
  }, [current, pageSize])

  const columns = [
    { title: '序号', dataIndex: 'id', key: 'id', render: (text, record, index) => <span>{(current - 1) * pageSize + index + 1}</span>, },
    { title: '消息标题', dataIndex: 'fullName', key: 'fullName' },
    { title: '消息类型', dataIndex: 'mail', key: 'mail' },
    { title: '已发送', dataIndex: 'send', key: 'send', render: (text) => <Link onClick={() => setOpen(true)}>{text}</Link> },
    { title: '已查看', dataIndex: 'check', key: 'check', render: (text) => <Link onClick={() => setOpen(true)}>{text}</Link> },
    { title: '发送时间', dataIndex: 'createTime', key: 'createTime' },
  ]

  const handleOk = () => {

  }

  return (
    <Space
      direction="vertical"
      size="middle"
      style={{ display: 'flex' }}
    >
      <ContentTitle title="站内信" />
      <Card bordered={false}>
        <SearchTableBox
          loading={loading}
          columns={columns}
          data={list}
          pagination={paging}
          setPaging={setPaging}
          placeholder="请输入消息标题"
        />
      </Card>
      <Modal
        title='明细'
        open={open}
        onOk={handleOk}
        onCancel={() => setOpen(false)}
        width={1000}
        footer={null}
      >
        <SearchTableBox
          isModal={true}
          loading={loading}
          columns={columns}
          data={list}
          pagination={paging}
          setPaging={setPaging}
          placeholder="请输入客户ID/名称"
        />
      </Modal>
    </Space>
  )
}

export default Mail
