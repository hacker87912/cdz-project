import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Input, message } from 'antd'
import * as API from '@/services/home'

function SortModal ({ open, onClose, sortRecord = {}, tab = 'banner',  onSubmit }) {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [sortInfo, setSortInfo] = useState({})

  useEffect(() => {
    if (open) {
      querySortInfo()
    }
  }, [open])

  // 初始化
  const querySortInfo = () => {
    const sortData = { sort: sortRecord.sort }
    setSortInfo(sortData)
    form.setFieldsValue(sortData)
  }

  // 提交数据
  const submitSort = async () => {
    let sortApi
    switch(tab) {
    case 'banner' : sortApi = API.bannerSort
      break
    case 'product' : sortApi = API.productSort
      break
    case 'customer' : sortApi = API.customerSort
      break
    }
    const res = await sortApi({ id: sortRecord.id, sort: +sortInfo.sort })
    if (res.code === 0) {
      message.success(t('排序成功'))
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitSort()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    onClose()
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setSortInfo({
      ...sortInfo,
      ...changedValues
    })
  }

  return (
    <Modal
      className={styles['sort-modal']}
      title={t('排序')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={500}
      forceRender
    >
      <Form
        form={form}
        name='sortForm'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Form.Item
          label={t('排序')}
          name='sort'
          rules={[
            {
              required: true,
              message: t('请输入排序数字'),
            },
          ]}
          extra={t('输入数字，数字越小排在最前面')}
        >
          <Input type='number' placeholder={t('输入数字')} />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default SortModal
