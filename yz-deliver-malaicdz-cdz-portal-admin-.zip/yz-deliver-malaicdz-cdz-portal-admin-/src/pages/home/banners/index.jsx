import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Space, Table, Input, Button, Image, message, Modal, Switch } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/home'
import CreateBanner from '../createBanner'
import SortModal from '../sortModal'
import LocaleTitle from '@/components/localeTitle'

function BannerList () {
  const { t } = useTranslation()
  const [keyword, setKeyword] = useState('')
  const [tableData, setTableData] = useState([])
  const [pageNo, setPageNo] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totals, setTotals] = useState(0)
  const [loading, setLoading] = useState(false)
  const [openCreate, setOpenCreate] = useState(false)
  const [openSort, setOpenSort] = useState(false)
  const [bannerInfoCreate, setBannerInfoCreate] = useState({})  // 当前新建编辑的banner
  const [bannerInfoSort, setBannerInfoSort] = useState({})  // 当前排序的banner
  useEffect(() => {
    queryBannerList()
  }, [pageNo, pageSize, keyword])

  // 分页查询banner列表
  const queryBannerList = async () => {
    setLoading(true)
    const res = await API.bannerQuery({
      current: pageNo,
      size: pageSize,
      keyword
    })
    const { records = [], total = 0 } = res.data || {}
    setLoading(false)
    setTableData(records)
    setTotals(total)
    // 处理分页边界情况
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && pageNo > totalPage) {
      setPageNo(totalPage)
    }
  }
  // 切换状态
  const changeBannerStatus = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要改变状态?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('轮播图名称')}: ${record.title}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.bannerStatus({ id: record.id, status: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryBannerList()
        }
      }
    })
  }
  // 点击创建
  const clickCreateBanner = () => {
    setBannerInfoCreate({})
    setOpenCreate(true)
  }
  // 点击编辑
  const clickEditBanner = (record) => {
    setBannerInfoCreate(record)
    setOpenCreate(true)
  }
  // 点击排序
  const clickSortBanner = (record) => {
    setBannerInfoSort(record)
    setOpenSort(true)
  }
  // 点击删除
  const clickDeleteBanner = (record) => {
    Modal.confirm({
      title: t('确认是否要删除?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('轮播图名称')}: ${record.title}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.bannerDel({ id: record.id })
        if (res.code === 0) {
          message.success(t('删除成功'))
          queryBannerList()
        }
      }
    })

  }
  // 新建编辑回调
  const handleBannerCreateSubmit = () => {
    setOpenCreate(false)
    if (bannerInfoCreate.id) {
      queryBannerList()
    } else {
      pageNo === 1 ? queryBannerList() : setPageNo(1)
    }
  }
  // 排序回调
  const handleSortSubmit = () => {
    setOpenSort(false)
    queryBannerList()
  }
  const columns = [
    {
      title: t('轮播图名称'),
      dataIndex: 'title',
      width: 100,
      ellipsis: true
    },
    {
      title: t('图片(中文)'),
      dataIndex: 'cosUrl',
      width: 100,
      render: (_, record) => <Image src={record.cosUrl} />,
    },
    {
      title: t('图片(英文)'),
      dataIndex: 'cosEnUrl',
      width: 100,
      render: (_, record) => <Image src={record.cosEnUrl} />,
    },
    {
      title: t('跳转URL'),
      render: (_, record) => <LocaleTitle name={record.url} width={200}/>,
    },
    {
      title: t('是否显示'),
      dataIndex: 'status',
      width: 100,
      render: (_, record) => <Switch checked={!!record.status} onChange={(status) => changeBannerStatus(record, status)} />,
    },
    {
      title: t('排序'),
      dataIndex: 'sort',
      width: 100,
    },
    {
      title: t('操作'),
      key: 'action',
      width: 200,
      render: (_, record) => (
        <Space size="middle">
          <a onClick={() => clickEditBanner(record)}>{t('编辑')}</a>
          <a onClick={() => clickSortBanner(record)}>{t('排序')}</a>
          <a onClick={() => clickDeleteBanner(record)}>{t('删除')}</a>
        </Space>
      ),
    },
  ]
  return (
    <>
      <div className={styles['banner-list']}>
        <div className={styles['search-content']}>
          <Button
            type='primary'
            className={styles['add-btn']}
            onClick={clickCreateBanner}
            size='middle'
          >
            {t('新增轮播图')}
          </Button>
          <Input.Search
            placeholder={t('请输入名称')}
            className={styles['search-ipt']}
            onSearch={(val) => {
              setPageNo(1)
              setKeyword(val)
            }}
            enterButton
            allowClear
          />
        </div>
        <div className={styles['table-content']}>
          <Table
            dataSource={tableData}
            columns={columns}
            rowKey='id'
            loading={loading}
            pagination={{
              showQuickJumper: true,
              showSizeChanger: true,
              pageSize,
              current: pageNo,
              total: totals,
              showTotal: total => `${t('共')} ${total} ${t('条')}`
            }}
            onChange={(pagination) => {
              setPageNo(pagination.current)
              setPageSize(pagination.pageSize)
            }}
            size='small'
            responsive
          />
        </div>
      </div>

      {/* 创建/编辑banner */}
      <CreateBanner
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        bannerRecord={bannerInfoCreate}
        onSubmit={handleBannerCreateSubmit}
      />
      {/* 排序修改 */}
      <SortModal
        open={openSort}
        onClose={() => setOpenSort(false)}
        sortRecord={bannerInfoSort}
        onSubmit={handleSortSubmit}
        tab='banner'
      />
    </>

  )
}

export default BannerList
