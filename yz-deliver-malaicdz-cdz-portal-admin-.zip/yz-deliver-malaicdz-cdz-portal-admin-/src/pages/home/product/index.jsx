import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Space, Table, Input, Button, message, Modal, Switch } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/home'
import CreateProduct from '../createProduct'
import SortModal from '../sortModal'
import LocaleTitle from '@/components/localeTitle'

function ProductList () {
  const { t } = useTranslation()
  const [keyword, setKeyword] = useState('')
  const [tableData, setTableData] = useState([])
  const [pageNo, setPageNo] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totals, setTotals] = useState(0)
  const [loading, setLoading] = useState(false)
  const [openCreate, setOpenCreate] = useState(false)
  const [openSort, setOpenSort] = useState(false)
  const [productInfoCreate, setProductInfoCreate] = useState({})  // 当前新建编辑的product
  const [productInfoSort, setProductInfoSort] = useState({})  // 当前排序的product
  useEffect(() => {
    queryProductList()
  }, [pageNo, pageSize, keyword])

  // 分页查询product列表
  const queryProductList = async () => {
    setLoading(true)
    const res = await API.productQuery({
      current: pageNo,
      size: pageSize,
      keyword
    })
    const { records = [], total = 0 } = res.data || {}
    setLoading(false)
    setTableData(records)
    setTotals(total)
    // 处理分页边界情况
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && pageNo > totalPage) {
      setPageNo(totalPage)
    }
  }
  // 切换状态
  const changeProductStatus = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要改变状态?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('产品名称')}: ${record.productName}/${record.productEnName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.productStatus({ id: record.id, status: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryProductList()
        }
      }
    })
  }
  // 点击创建
  const clickCreateProduct = () => {
    setProductInfoCreate({})
    setOpenCreate(true)
  }
  // 点击编辑
  const clickEditProduct = (record) => {
    setProductInfoCreate(record)
    setOpenCreate(true)
  }
  // 点击排序
  const clickSortProduct = (record) => {
    setProductInfoSort(record)
    setOpenSort(true)
  }
  // 点击删除
  const clickDeleteProduct = (record) => {
    Modal.confirm({
      title: t('确认是否要删除?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('产品名称')}: ${record.productName}/${record.productEnName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.productDel({ id: record.id })
        if (res.code === 0) {
          message.success(t('删除成功'))
          queryProductList()
        }
      }
    })

  }
  // 新建编辑回调
  const handleProductCreateSubmit = () => {
    setOpenCreate(false)
    if (productInfoCreate.id) {
      queryProductList()
    } else {
      pageNo === 1 ? queryProductList() : setPageNo(1)
    }
  }
  // 排序回调
  const handleSortSubmit = () => {
    setOpenSort(false)
    queryProductList()
  }
  const columns = [
    {
      title: t('产品分类'),
      render: (_, record) => <LocaleTitle name={record.classifyName} enName={record.classifyEnName} width={150}/>,
    },
    {
      title: t('产品标题'),
      render: (_, record) => <LocaleTitle name={record.productName} enName={record.productEnName} width={200}/>,
    },
    {
      title: t('是否显示'),
      dataIndex: 'status',
      render: (_, record) => <Switch checked={!!record.status} onChange={(status) => changeProductStatus(record, status)} />,
    },
    {
      title: t('排序'),
      dataIndex: 'sort',
    },
    {
      title: t('操作'),
      key: 'action',
      width: 200,
      render: (_, record) => (
        <Space size="middle">
          <a onClick={() => clickEditProduct(record)}>{t('编辑')}</a>
          <a onClick={() => clickSortProduct(record)}>{t('排序')}</a>
          <a onClick={() => clickDeleteProduct(record)}>{t('删除')}</a>
        </Space>
      ),
    },
  ]
  return (
    <>
      <div className={styles['product-list']}>
        <div className={styles['search-content']}>
          <Button
            type="primary"
            className={styles['add-btn']}
            onClick={clickCreateProduct}
            size='middle'
          >
            {t('新增优势产品')}
          </Button>
          <Input.Search
            placeholder={t('请输入名称')}
            className={styles['search-ipt']}
            onSearch={(val) => {
              setPageNo(1)
              setKeyword(val)
            }}
            enterButton
            allowClear
          />
        </div>
        <div className={styles['table-content']}>
          <Table
            dataSource={tableData}
            columns={columns}
            rowKey='id'
            loading={loading}
            pagination={{
              showQuickJumper: true,
              showSizeChanger: true,
              pageSize,
              current: pageNo,
              total: totals,
              showTotal: total => `${t('共')} ${total} ${t('条')}`
            }}
            onChange={(pagination) => {
              setPageNo(pagination.current)
              setPageSize(pagination.pageSize)
            }}
            size='small'
            responsive
          />
        </div>
      </div>

      {/* 创建/编辑 */}
      <CreateProduct
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        productRecord={productInfoCreate}
        onSubmit={handleProductCreateSubmit}
      />
      {/* 排序修改 */}
      <SortModal
        open={openSort}
        onClose={() => setOpenSort(false)}
        sortRecord={productInfoSort}
        onSubmit={handleSortSubmit}
        tab='product'
      />
    </>

  )
}

export default ProductList
