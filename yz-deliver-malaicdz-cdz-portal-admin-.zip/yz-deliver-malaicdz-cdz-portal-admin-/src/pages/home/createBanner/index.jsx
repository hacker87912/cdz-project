import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Upload, Input, Switch, message } from 'antd'
import { LoadingOutlined, PlusOutlined, ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/home'
import { $put } from '@/utils/request'

function CreateBanner ({ open, onClose, bannerRecord = {}, onSubmit }) {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [bannerInfo, setBannerInfo] = useState({})
  const [initBannerInfo, setInitBannerInfo] = useState({})
  const [loadingZh, setLoadingZh] = useState(false)
  const [loadingEn, setLoadingEn] = useState(false)
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open) {
      queryBannerInfo()
    }
  }, [open])

  // 初始化
  const queryBannerInfo = async () => {
    const initData = {
      title: '',
      url: '',
      cosUrl: '',
      cosEnUrl: '',
      sort: '',
      status: true
    }
    setBannerInfo(initData)
    setInitBannerInfo(initData)
    form.setFieldsValue(initData)
    if (bannerRecord.id) {
      const res = await API.bannerDetail({ id: bannerRecord.id })
      const resData = res?.data || {}
      const bannerData = {
        ...resData,
        status: !!resData.status
      }
      setBannerInfo(bannerData)
      setInitBannerInfo(bannerData)
      form.setFieldsValue(bannerData)
    }
  }

  // 提交数据
  const submitBanner = async () => {
    const postData = {
      ...bannerInfo,
      sort: +bannerInfo.sort,
      status: +bannerInfo.status
    }
    let bannerApi = API.bannerAdd
    let msg = t('创建成功')

    if (bannerRecord.id) {
      postData.id = bannerRecord.id
      bannerApi = API.bannerUpdate
      msg = t('编辑成功')
    }
    setConfirmLoading(true)
    const res = await bannerApi(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(msg)
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitBanner()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(bannerInfo) === JSON.stringify(initBannerInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setBannerInfo({
      ...bannerInfo,
      ...changedValues
    })
  }
  // 自定义上传
  const customRequest = (field) => async ({ file }) => {
    // 获取密钥
    const res = await API.uploadImgSecret({ filenameExtension: `.${file.name.split('.').pop()}` })
    const { credentials, fileInformation } = res.data || {}
    // 计算签名
    const signature = window.CosAuth({
      SecretId: credentials.tmpSecretId,
      SecretKey: credentials.tmpSecretKey,
      Method: 'PUT',
      Pathname: fileInformation.filePath,
    })
    // url encode
    var camSafeUrlEncode = function (str) {
      return encodeURIComponent(str)
        .replace(/!/g, '%21')
        .replace(/'/g, '%27')
        .replace(/\(/g, '%28')
        .replace(/\)/g, '%29')
        .replace(/\*/g, '%2A')
    }
    // 上传文件到腾讯云
    var prefix = 'https://' + fileInformation.bucket + '.cos.' + fileInformation.region + '.myqcloud.com'
    var url = prefix + camSafeUrlEncode(fileInformation.filePath).replace(/%2F/g, '/')
    const uploadRes = await $put(url, file, { headers: { 'Authorization': signature, 'x-cos-security-token': credentials.sessionToken } })
    if (uploadRes.status === 200 && uploadRes.headers?.etag) {
      if (field === 'cosUrl') {
        setLoadingZh(false)
        setBannerInfo({
          ...bannerInfo,
          cosUrl: url
        })
        form.setFieldsValue({
          ...bannerInfo,
          cosUrl: url
        })
      } else if (field === 'cosEnUrl') {
        setLoadingEn(false)
        setBannerInfo({
          ...bannerInfo,
          cosEnUrl: url
        })
        form.setFieldsValue({
          ...bannerInfo,
          cosEnUrl: url
        })
      }

    } else {
      message.error(uploadRes.msg || t('上传失败'))
    }
  }

  return (
    <Modal
      className={styles['create-banner']}
      title={bannerRecord.id ? t('编辑') : t('新增')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Form
        form={form}
        name='bannerForm'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Form.Item
          label={t('轮播图名称')}
          name='title'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入名称'),
            },
            {
              type: 'string',
              min: 1,
              max: 100,
              message: t('名称长度最多100位'),
            },
          ]}
        >
          <Input placeholder={t('轮播图名称')} />
        </Form.Item>
        <Form.Item
          label={t('图片(中文)')}
          name='cosUrl'
          rules={[
            {
              required: true,
              message: t('请上传图片'),
            },
          ]}
          extra={t('只能上传jpg/png/bmp/jpeg格式文件')}
          getValueProps={value => value}
          getValueFromEvent={() => setLoadingZh(true)}
        >
          <Upload
            accept='image/png, image/jpeg, image/bmp, image/jpg'
            listType='picture-card'
            className='banner-uploader'
            showUploadList={false}
            maxCount={1}
            customRequest={customRequest('cosUrl')}
          >
            {bannerInfo.cosUrl ? (
              <img
                src={bannerInfo.cosUrl}
                alt=''
                style={{
                  width: '100%',
                  height: '100%'
                }}
              />
            ) : (
              <div>
                {loadingZh ? <LoadingOutlined /> : <PlusOutlined />}
                <div style={{ marginTop: 8 }}>{t('上传')}</div>
              </div>
            )}
          </Upload>
        </Form.Item>
        <Form.Item
          label={t('图片(英文)')}
          name='cosEnUrl'
          rules={[
            {
              required: true,
              message: t('请上传图片'),
            },
          ]}
          extra={t('只能上传jpg/png/bmp/jpeg格式文件')}
          getValueProps={value => value}
          getValueFromEvent={() => setLoadingEn(true)}
        >
          <Upload
            accept='image/png, image/jpeg, image/bmp, image/jpg'
            listType='picture-card'
            className='banner-uploader'
            showUploadList={false}
            maxCount={1}
            customRequest={customRequest('cosEnUrl')}
          >
            {bannerInfo.cosEnUrl ? (
              <img
                src={bannerInfo.cosEnUrl}
                alt=''
                style={{
                  width: '100%',
                  height: '100%'
                }}
              />
            ) : (
              <div>
                {loadingEn ? <LoadingOutlined /> : <PlusOutlined />}
                <div style={{ marginTop: 8 }}>{t('上传')}</div>
              </div>
            )}
          </Upload>
        </Form.Item>
        <Form.Item
          label={t('跳转url')}
          name='url'
          rules={[
            {
              type: 'url',
              message: t('url不合法'),
            },
          ]}
        >
          <Input placeholder={t('url或本地链接')} />
        </Form.Item>
        <Form.Item
          label={t('排序')}
          name='sort'
          rules={[
            {
              required: true,
              message: t('请输入排序数字'),
            },
          ]}
          extra={t('输入数字，数字越小排在最前面')}
        >
          <Input type='number' placeholder={t('输入数字')} />
        </Form.Item>
        <Form.Item
          label={t('是否显示')}
          name='status'
          valuePropName='checked'
          required
        >
          <Switch />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default CreateBanner
