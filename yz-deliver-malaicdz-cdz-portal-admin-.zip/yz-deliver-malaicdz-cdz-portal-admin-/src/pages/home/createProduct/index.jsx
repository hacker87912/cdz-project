import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Select, Input, Switch, message, Row, Button } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import * as API from '@/services/home'
import { getProductClassifyList, getClassifyProduct } from '@/services/product'

function CreateProduct ({ open, onClose, productRecord = {}, onSubmit }) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const [form] = Form.useForm()
  const [productInfo, setProductInfo] = useState({})
  const [initProductInfo, setInitProductInfo] = useState({})
  const [productClassifyOptions, setProductClassifyOptions] = useState([])
  const [productListOptions, setProductListOptionst] = useState([])
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open) {
      queryProductInfo()
    }
  }, [open])
  useEffect(() => {
    getClassifyListData()
  }, [])

  // 获取产品分类
  const getClassifyListData = async () => {
    const res = await getProductClassifyList()
    setProductClassifyOptions((res.data || []).map(item => ({ label: `${item.name}/${item.enName}`, value: item.id })))
  }
  // 根据分类获取产品
  const getProductListData = async (classify) => {
    setProductListOptionst([])
    form.setFieldValue('productId', '')
    const res =  await getClassifyProduct(classify)
    const list = res.data || []
    setProductListOptionst(list.map(item => ({ label: `${item.title}/${item.enTitle}`, value: item.id })))
  }
  // 初始化
  const queryProductInfo = async () => {
    const initData = {
      classify: '',
      productId: '',
      sort: '',
      status: true
    }
    setProductInfo(initData)
    setInitProductInfo(initData)
    form.setFieldsValue(initData)
    setProductListOptionst([])
    if (productRecord.id) {
      const res = await API.productDetail({ id: productRecord.id })
      const resData = res?.data || {}
      const productData = {
        ...resData,
        status: !!resData.status
      }
      await getProductListData(productData.classify)
      setProductInfo(productData)
      setInitProductInfo(productData)
      form.setFieldsValue(productData)
    }
  }

  // 提交数据
  const submitProduct = async () => {
    const postData = {
      ...productInfo,
      sort: +productInfo.sort,
      status: +productInfo.status,
      title: productListOptions.find(item => item.id === productInfo.type)?.title
    }
    let productApi = API.productAdd
    let msg = t('创建成功')

    if (productRecord.id) {
      postData.id = productRecord.id
      productApi = API.productUpdate
      msg = t('编辑成功')
    }
    setConfirmLoading(true)
    const res = await productApi(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(msg)
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitProduct()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(productInfo) === JSON.stringify(initProductInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setProductInfo({
      ...productInfo,
      ...changedValues
    })
  }

  return (
    <Modal
      className={styles['create-product']}
      title={productRecord.id ? t('编辑') : t('新增')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Form
        form={form}
        name='productForm'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Row>
          <Form.Item
            style={{ width: '100%' }}
            label={t('产品分类')}
            name="classify"
            rules={[
              {
                required: true,
                message: t('请必填')
              },
            ]}
          >
            <Select
              placeholder={t('请选择产品分类')}
              options={productClassifyOptions}
              onChange={(val) => getProductListData(val)}
            />
          </Form.Item>
          <Button
            type='link'
            style={{ marginLeft: '-100px' }}
            onClick={() => navigate('/cms/product/classify')}
          >
            {t('管理')}
          </Button>
        </Row>
        <Row>
          <Form.Item
            style={{ width: '100%' }}

            label={t('产品')}
            name='productId'
            rules={[
              {
                required: true,
                message: t('请选择产品'),
              },
            ]}
          >
            <Select
              placeholder={t('请选择产品')}
              options={productListOptions}
            />
          </Form.Item>
          <Button
            type='link'
            style={{ marginLeft: '-100px' }}
            onClick={() => navigate('/cms/product')}
          >
            {t('管理')}
          </Button>
        </Row>
        <Form.Item
          label={t('排序')}
          name='sort'
          rules={[
            {
              required: true,
              message: t('请输入排序数字'),
            },
          ]}
          extra={t('输入数字，数字越小排在最前面')}
        >
          <Input type='number' placeholder={t('输入数字')} />
        </Form.Item>
        <Form.Item
          label={t('是否显示')}
          name='status'
          valuePropName='checked'
          required
        >
          <Switch />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default CreateProduct
