import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Upload, Input, Switch, message } from 'antd'
import { LoadingOutlined, PlusOutlined, ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/home'
import Editor from '@/components/editor'
import { $put } from '@/utils/request'

function CreateCustomer ({ open, onClose, customerRecord = {}, onSubmit }) {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [customerInfo, setCustomerInfo] = useState({})
  const [initCustomerInfo, setInitCustomerInfo] = useState({})
  const [loading, setLoading] = useState(false)
  const [logoLoading, setLogoLoading] = useState(false)
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open) {
      queryCustomerInfo()
    }
  }, [open])

  // 初始化
  const queryCustomerInfo = async () => {
    const initData = {
      title: '',
      enTitle: '',
      detail: '<p><br></p>',
      enDetail: '<p><br></p>',
      subTitle: '',
      subEnTitle: '',
      cosUrl: '',
      logoUrl: '',
      sort: '',
      status: true,
      isExpand: false
    }
    setCustomerInfo(initData)
    setInitCustomerInfo(initData)
    form.setFieldsValue(initData)
    if (customerRecord.id) {
      const res = await API.customerDetail({ id: customerRecord.id })
      const resData = res?.data || {}
      const customerData = {
        ...resData,
        status: !!resData.status,
        isExpand: !!resData.isExpand
      }
      setCustomerInfo(customerData)
      setInitCustomerInfo(customerData)
      form.setFieldsValue(customerData)
    }
  }

  // 提交数据
  const submitCustomer = async () => {
    const postData = {
      ...customerInfo,
      status: +customerInfo.status,
      isExpand: +customerInfo.isExpand
    }
    let customerApi = API.customerAdd
    let msg = t('创建成功')

    if (customerRecord.id) {
      postData.id = customerRecord.id
      customerApi = API.customerUpdate
      msg = t('编辑成功')
    }
    setConfirmLoading(true)
    const res = await customerApi(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(msg)
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitCustomer()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(customerInfo) === JSON.stringify(initCustomerInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setCustomerInfo({
      ...customerInfo,
      ...changedValues
    })
  }
  // 自定义上传
  const customRequest = (field) => async ({ file }) => {
    // 获取密钥
    const res = await API.uploadImgSecret({ filenameExtension: `.${file.name.split('.').pop()}` })
    const { credentials, fileInformation } = res.data || {}
    // 计算签名
    const signature = window.CosAuth({
      SecretId: credentials.tmpSecretId,
      SecretKey: credentials.tmpSecretKey,
      Method: 'PUT',
      Pathname: fileInformation.filePath,
    })
    // url encode
    var camSafeUrlEncode = function (str) {
      return encodeURIComponent(str)
        .replace(/!/g, '%21')
        .replace(/'/g, '%27')
        .replace(/\(/g, '%28')
        .replace(/\)/g, '%29')
        .replace(/\*/g, '%2A')
    }
    // 上传文件到腾讯云
    var prefix = 'https://' + fileInformation.bucket + '.cos.' + fileInformation.region + '.myqcloud.com'
    var url = prefix + camSafeUrlEncode(fileInformation.filePath).replace(/%2F/g, '/')
    const uploadRes = await $put(url, file, { headers: { 'Authorization': signature, 'x-cos-security-token': credentials.sessionToken } })
    if (uploadRes.status === 200 && uploadRes.headers?.etag) {
      if (field === 'cosUrl') {
        setLoading(false)
        setCustomerInfo({
          ...customerInfo,
          cosUrl: url
        })
        form.setFieldsValue({
          ...customerInfo,
          cosUrl: url
        })
      } else if (field === 'logoUrl') {
        setLogoLoading(false)
        setCustomerInfo({
          ...customerInfo,
          logoUrl: url
        })
        form.setFieldsValue({
          ...customerInfo,
          logoUrl: url
        })
      }

    } else {
      message.error(uploadRes.msg || t('上传失败'))
    }
  }
  return (
    <Modal
      className={styles['create-customer']}
      title={customerRecord.id ? t('编辑') : t('新增')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Form
        form={form}
        name='customerForm'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <Form.Item
          label={t('客户名称(中文)')}
          name='title'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入名称'),
            },
            {
              type: 'string',
              min: 1,
              max: 30,
              message: t('名称长度最多30位'),
            },
          ]}
        >
          <Input placeholder={t('输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('客户名称(英文)')}
          name='enTitle'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入名称'),
            },
            {
              type: 'string',
              min: 1,
              max: 500,
              message: t('名称长度最多500位'),
            },
          ]}
        >
          <Input placeholder={t('输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('客户副标题(中文)')}
          name='subTitle'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入标题'),
            },
            {
              type: 'string',
              min: 1,
              max: 100,
              message: t('名称长度最多100位'),
            },
          ]}
        >
          <Input.TextArea placeholder={t('输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('客户副标题(英文)')}
          name='subEnTitle'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入标题'),
            },
            {
              type: 'string',
              min: 1,
              max: 500,
              message: t('名称长度最多500位'),
            },
          ]}
        >
          <Input.TextArea placeholder={t('输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('图片')}
          name='cosUrl'
          rules={[
            {
              required: true,
              message: t('请上传图片'),
            },
          ]}
          extra={t('只能上传jpg/png/bmp/jpeg格式文件')}
          getValueProps={value => value}
          getValueFromEvent={() => setLoading(true)}
        >
          <Upload
            accept='image/png, image/jpeg, image/bmp, image/jpg'
            listType='picture-card'
            className='customer-uploader'
            showUploadList={false}
            maxCount={1}
            customRequest={customRequest('cosUrl')}
          >
            {customerInfo.cosUrl ? (
              <img
                src={customerInfo.cosUrl}
                alt=''
                style={{
                  width: '100%',
                  height: '100%'
                }}
              />
            ) : (
              <div>
                {loading ? <LoadingOutlined /> : <PlusOutlined />}
                <div style={{ marginTop: 8 }}>{t('上传')}</div>
              </div>
            )}
          </Upload>
        </Form.Item>
        <Form.Item
          label={t('客户logo')}
          name='logoUrl'
          rules={[
            {
              required: true,
              message: t('请上传图片'),
            },
          ]}
          extra={t('只能上传jpg/png/bmp/jpeg格式文件')}
          getValueProps={value => value}
          getValueFromEvent={() => setLogoLoading(true)}
        >
          <Upload
            accept='image/png, image/jpeg, image/bmp, image/jpg'
            listType='picture-card'
            className='customer-uploader'
            showUploadList={false}
            maxCount={1}
            customRequest={customRequest('logoUrl')}
          >
            {customerInfo.logoUrl ? (
              <img
                src={customerInfo.logoUrl}
                alt=''
                style={{
                  width: '100%',
                  height: '100%'
                }}
              />
            ) : (
              <div>
                {logoLoading ? <LoadingOutlined /> : <PlusOutlined />}
                <div style={{ marginTop: 8 }}>{t('上传')}</div>
              </div>
            )}
          </Upload>
        </Form.Item>
        <Form.Item
          label={t('客户详情(中文)')}
          name='detail'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请编辑客户详情内容'),
            },
            {
              validator: (_, value) => {
                if (value !== '<p><br></p>') {
                  return Promise.resolve()
                }
                return Promise.reject(new Error(t('请编辑客户详情内容')))
              },
              validateTrigger: 'onBlur'
            },
          ]}
        >
          <Editor />
        </Form.Item>
        <Form.Item
          label={t('客户详情(英文)')}
          name='enDetail'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请编辑客户详情内容'),
            },
            {
              validator: (_, value) => {
                if (value !== '<p><br></p>') {
                  return Promise.resolve()
                }
                return Promise.reject(new Error(t('请编辑客户详情内容')))
              },
              validateTrigger: 'onBlur'
            },
          ]}
        >
          <Editor />
        </Form.Item>
        <Form.Item
          label={t('排序')}
          name='sort'
          rules={[
            {
              required: true,
              message: t('请输入排序数字'),
            },
          ]}
          extra={t('输入数字，数字越小排在最前面')}
        >
          <Input type='number' placeholder={t('输入数字')} />
        </Form.Item>
        <Form.Item
          label={t('是否显示')}
          name='status'
          valuePropName='checked'
          required
        >
          <Switch />
        </Form.Item>
        <Form.Item
          label={t('是否展开')}
          name='isExpand'
          valuePropName='checked'
          required
        >
          <Switch />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default CreateCustomer
