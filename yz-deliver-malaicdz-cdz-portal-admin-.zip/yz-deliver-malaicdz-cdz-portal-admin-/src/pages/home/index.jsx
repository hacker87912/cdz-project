import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Tabs, Card } from 'antd'
import { useSearchParams } from 'react-router-dom'
import Banner from './banners'
import Product from './product'
import Customer from './customer'
import ContentTitle from '@/components/contentTitle'

function HomeSet () {
  const { t } = useTranslation()
  const [searchParams, setSearchParams] = useSearchParams()
  const [currentTab, setCurrentTab] = useState('')
  useEffect(() => {
    setCurrentTab(searchParams.get('tab') || 'banner')
  }, [searchParams])

  const tabItems = [
    {
      key: 'banner',
      label: t('轮播图'),
      children: <Banner />,
    },
    {
      key: 'product',
      label: t('优势产品'),
      children: <Product />,
    },
    {
      key: 'customer',
      label: t('客户案例'),
      children: <Customer />,
    },
  ]
  const handleTabsChange = (val) => {
    setCurrentTab(val)
    setSearchParams({tab: val})
  }
  return (
    <div className={styles['home-release']}>
      <div className={styles['title']}>
        <ContentTitle title={t('首页发布')}/>
      </div>
      <Card bordered={false}>
        <Tabs
          items={tabItems}
          activeKey={currentTab}
          onChange={handleTabsChange}
          destroyInactiveTabPane={true}
        />
      </Card>
    </div>
  )
}

export default HomeSet
