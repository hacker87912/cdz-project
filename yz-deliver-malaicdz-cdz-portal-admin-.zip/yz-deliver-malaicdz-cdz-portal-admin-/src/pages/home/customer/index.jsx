import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Space, Table, Input, Button, Image, message, Modal, Switch } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/home'
import CreateCustomer from '../createCustomer'
import SortModal from '../sortModal'
import LocaleTitle from '@/components/localeTitle'

function CustomerList () {
  const { t } = useTranslation()
  const [keyword, setKeyword] = useState('')
  const [tableData, setTableData] = useState([])
  const [pageNo, setPageNo] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totals, setTotals] = useState(0)
  const [loading, setLoading] = useState(false)
  const [openCreate, setOpenCreate] = useState(false)
  const [openSort, setOpenSort] = useState(false)
  const [customerInfoCreate, setCustomerInfoCreate] = useState({})  // 当前新建编辑的customer
  const [customerInfoSort, setCustomerInfoSort] = useState({})  // 当前排序的customer
  useEffect(() => {
    queryCustomerList()
  }, [pageNo, pageSize, keyword])

  // 分页查询customer列表
  const queryCustomerList = async () => {
    setLoading(true)
    const res = await API.customerQuery({
      current: pageNo,
      size: pageSize,
      keyword
    })
    const { records = [], total = 0 } = res.data || {}
    setLoading(false)
    setTableData(records)
    setTotals(total)
    // 处理分页边界情况
    const totalPage = Math.ceil(total / pageSize)
    if (totalPage && pageNo > totalPage) {
      setPageNo(totalPage)
    }
  }
  // 切换状态
  const changeCustomerStatus = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要改变状态?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('客户案例名称')}: ${record.title}/${record.enTitle}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.customerStatus({ id: record.id, status: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryCustomerList()
        }
      }
    })
  }
  // 切换展开
  const changeCustomerExpand = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要切换展开?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('客户案例名称')}: ${record.title}/${record.enTitle}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.customerExpand({ id: record.id, isExpand: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryCustomerList()
        }
      }
    })
  }
  // 点击创建
  const clickCreateCustomer = () => {
    setCustomerInfoCreate({})
    setOpenCreate(true)
  }
  // 点击编辑
  const clickEditCustomer = (record) => {
    setCustomerInfoCreate(record)
    setOpenCreate(true)
  }
  // 点击排序
  const clickSortCustomer = (record) => {
    setCustomerInfoSort(record)
    setOpenSort(true)
  }
  // 点击删除
  const clickDeleteCustomer = (record) => {
    Modal.confirm({
      title: t('确认是否要删除?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('客户案例名称')}: ${record.title}/${record.enTitle}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.customerDel({ id: record.id })
        if (res.code === 0) {
          message.success(t('删除成功'))
          queryCustomerList()
        }
      }
    })

  }
  // 新建编辑回调
  const handleCustomerCreateSubmit = () => {
    setOpenCreate(false)
    if (customerInfoCreate.id) {
      queryCustomerList()
    } else {
      pageNo === 1 ? queryCustomerList() : setPageNo(1)
    }
  }
  // 排序回调
  const handleSortSubmit = () => {
    setOpenSort(false)
    queryCustomerList()
  }
  const columns = [
    {
      title: t('客户名称'),
      render: (_, record) => <LocaleTitle name={record.title} enName={record.enTitle} width={150}/>,
    },
    {
      title: t('客户副标题'),
      render: (_, record) => <LocaleTitle name={record.subTitle} enName={record.subEnTitle} width={150}/>,
    },
    {
      title: t('客户logo'),
      dataIndex: 'logoUrl',
      width: 100,
      render: (_, record) => <Image src={record.logoUrl} />,
    },
    {
      title: t('是否显示'),
      dataIndex: 'status',
      width: 100,
      render: (_, record) => <Switch checked={!!record.status} onChange={(status) => changeCustomerStatus(record, status)} />,
    },
    {
      title: t('排序'),
      dataIndex: 'sort',
      width: 100,
    },
    {
      title: t('是否展开'),
      dataIndex: 'open',
      width: 100,
      render: (_, record) => <Switch checked={!!record.isExpand} onChange={(status) => changeCustomerExpand(record, status)} />,
    },
    {
      title: t('操作'),
      key: 'action',
      width: 200,
      render: (_, record) => (
        <Space size="middle">
          <a onClick={() => clickEditCustomer(record)}>{t('编辑')}</a>
          <a onClick={() => clickSortCustomer(record)}>{t('排序')}</a>
          <a onClick={() => clickDeleteCustomer(record)}>{t('删除')}</a>
        </Space>
      ),
    },
  ]
  return (
    <>
      <div className={styles['customer-list']}>
        <div className={styles['search-content']}>
          <Button
            type='primary'
            className={styles['add-btn']}
            onClick={clickCreateCustomer}
            size='middle'
          >
            {t('新增客户案例')}
          </Button>
          <Input.Search
            placeholder={t('请输入名称')}
            className={styles['search-ipt']}
            onSearch={(val) => {
              setPageNo(1)
              setKeyword(val)
            }}
            enterButton
            allowClear
          />
        </div>
        <div className={styles['table-content']}>
          <Table
            dataSource={tableData}
            columns={columns}
            rowKey='id'
            loading={loading}
            pagination={{
              showQuickJumper: true,
              showSizeChanger: true,
              pageSize,
              current: pageNo,
              total: totals,
              showTotal: total => `${t('共')} ${total} ${t('条')}`
            }}
            onChange={(pagination) => {
              setPageNo(pagination.current)
              setPageSize(pagination.pageSize)
            }}
            size='small'
            responsive
          />
        </div>
      </div>

      {/* 创建/编辑customer */}
      <CreateCustomer
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        customerRecord={customerInfoCreate}
        onSubmit={handleCustomerCreateSubmit}
      />
      {/* 排序修改 */}
      <SortModal
        open={openSort}
        onClose={() => setOpenSort(false)}
        sortRecord={customerInfoSort}
        onSubmit={handleSortSubmit}
        tab='customer'
      />
    </>

  )
}

export default CustomerList
