import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Space, Table, Input, Button, Switch, message, Modal, Card } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/customer'
import CreateCustomer from './createCustomer'
import BindTencent from './bindTencent'
import ContentTitle from '@/components/contentTitle'

function CustomerManage () {
  const { t } = useTranslation()
  const [keyword, setKeyword] = useState('')
  const [tableData, setTableData] = useState([])
  const [pageNo, setPageNo] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [totals, setTotals] = useState(0)
  const [loading, setLoading] = useState(false)
  const [openCreate, setOpenCreate] = useState(false)
  const [openBind, setOpenBind] = useState(false)
  const [customerInfoCreate, setCustomerInfoCreate] = useState({})  // 当前新建编辑的customer
  const [customerInfoBind, setCustomerInfoBind] = useState({})  // 当前绑定腾讯云的customer

  useEffect(() => {
    queryCustomerList()
  }, [pageNo, pageSize, keyword])

  // 分页查询customer列表
  const queryCustomerList = async () => {
    setLoading(true)
    const res = await API.customerQuery({
      current: pageNo,
      size: pageSize,
      keyword
    })
    const { records = [], total = 0 } = res.data || {}
    setLoading(false)
    setTableData(records)
    setTotals(total)
  }
  // 切换状态
  const changeCustomerStatus = async (record, status) => {
    Modal.confirm({
      title: t('确认是否要改变状态?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('客户名称')}: ${record.accountName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.customerStatus({ id: record.id, status: +status })
        if (res.code === 0) {
          message.success(t('切换成功'))
          queryCustomerList()
        }
      }
    })
  }
  // 点击创建
  const clickCreateCustomer = () => {
    setCustomerInfoCreate({})
    setOpenCreate(true)
  }
  // 点击编辑
  const clickEditCustomer = (record) => {
    setCustomerInfoCreate(record)
    setOpenCreate(true)
  }
  // 点击绑定腾讯云
  const clickBindTencentCloud = (record) => {
    setCustomerInfoBind(record)
    setOpenBind(true)
  }
  // 点击下载协议
  const clickDownloadFile = (record) => {
    Modal.confirm({
      title: t('确认是否要下载协议?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('客户名称')}: ${record.accountName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.fileDownload({ id: record.id })
        const blob = new Blob([res], {type: 'application/octet-stream'})
        const fileName = `${record.id}.metadata.xml`
        downLoadFile(blob, fileName)
      }
    })
  }
  // 下载文件流
  const downLoadFile = (blob, fileName) => {
    if (window.navigator.msSaveOrOpenBlob) { // IE10
      navigator.msSaveBlob(blob, fileName)
    } else {
      let link = document.createElement('a')
      link.style.display = 'none'
      link.href = URL.createObjectURL(blob)
      link.download = fileName
      link.click()
      URL.revokeObjectURL(link.href)
    }
  }
  // 点击删除
  const clickDeleteCustomer = (record) => {
    Modal.confirm({
      title: t('确认是否要删除?'),
      icon: <ExclamationCircleFilled />,
      content: `${t('客户名称')}: ${record.accountName}`,
      okText: t('是'),
      okType: 'danger',
      cancelText: t('否'),
      async onOk () {
        const res = await API.customerDelete({ id: record.id })
        if (res.code === 0) {
          message.success(t('删除成功'))
          queryCustomerList()
        }
      }
    })
  }
  // 提交customer回调
  const handleCustomerSubmit = () => {
    setOpenCreate(false)
    if (customerInfoCreate.id) {
      queryCustomerList()
    } else {
      pageNo === 1 ? queryCustomerList() : setPageNo(1)
    }
  }
  // 绑定腾讯云回调
  const handleBindTencentSubmit = () => {
    setOpenBind(false)
    queryCustomerList()
  }
  const columns = [
    {
      title: t('序号'),
      key: 'index',
      render: (text, record, index) => <span>{(pageNo - 1) * pageSize + index + 1}</span>,
      width: 80
    },
    {
      title: t('客户ID'),
      dataIndex: 'id',
      width: 100,
      ellipsis: true
    },
    {
      title: t('客户名称'),
      dataIndex: 'accountName',
      width: 150,
      ellipsis: true
    },
    {
      title: t('注册时间'),
      dataIndex: 'createTime',
      // render: (text, record, index) => <span>{text}</span>,
    },
    {
      title: t('登录账号'),
      dataIndex: 'loginAccount',
    },
    {
      title: t('是否绑定腾讯云'),
      dataIndex: 'bindStatus',
      render: (_, { bindStatus }) => <span>{bindStatus ? t('是') : t('否')}</span>,
    },
    {
      title: t('开启状态'),
      dataIndex: 'status',
      render: (_, record) => <Switch checked={!!record.status} onChange={(status) => changeCustomerStatus(record, status)} />,
    },
    {
      title: t('操作'),
      key: 'action',
      width: 300,
      render: (_, record) => (
        <Space size="middle">
          <a onClick={() => clickBindTencentCloud(record)}>{t('绑定腾讯云')}</a>
          <a onClick={() => clickDownloadFile(record)}>{t('下载saml协议')}</a>
          <a onClick={() => clickEditCustomer(record)}>{t('编辑')}</a>
          <a onClick={() => clickDeleteCustomer(record)}>{t('删除')}</a>
        </Space>
      ),
    },
  ]

  return (
    <>
      <div className={styles['customer-manage']}>
        <div className={styles['title']}>
          <ContentTitle title={t('客户列表')}/>
        </div>
        <Card bordered={false}>
          <div className={styles['search-content']}>
            <Button
              type='primary'
              className={styles['add-btn']}
              onClick={clickCreateCustomer}
              size='middle'
            >
              {t('新增客户')}
            </Button>
            <Input.Search
              placeholder={t('请输入客户ID/名称/登录账号')}
              className={styles['search-ipt']}
              onSearch={(val) => {
                setPageNo(1)
                setKeyword(val)
              }}
              enterButton
              allowClear
            />
          </div>
          <div className={styles['table-content']}>
            <Table
              dataSource={tableData}
              columns={columns}
              rowKey='id'
              loading={loading}
              pagination={{
                showQuickJumper: true,
                showSizeChanger: true,
                pageSize,
                current: pageNo,
                total: totals,
                showTotal: total => `${t('共')} ${total} ${t('条')}`
              }}
              onChange={(pagination) => {
                setPageNo(pagination.current)
                setPageSize(pagination.pageSize)
              }}
              size='small'
              responsive
            />
          </div>
        </Card>
      </div>

      <CreateCustomer
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        customerRecord={customerInfoCreate}
        onSubmit={handleCustomerSubmit}
      />
      <BindTencent
        open={openBind}
        onClose={() => setOpenBind(false)}
        customerRecord={customerInfoBind}
        onSubmit={handleBindTencentSubmit}
      />
    </>

  )
}

export default CustomerManage
