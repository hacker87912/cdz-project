import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Input, Select, Row, message } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import * as API from '@/services/customer'

function CreateCustomer ({ open, onClose, customerRecord = {}, onSubmit }) {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [customerInfo, setCustomerInfo] = useState({})
  const [initCustomerInfo, setInitCustomerInfo] = useState({})
  const [mainIndustryOptions, setMainIndustryOptions] = useState([])
  const [secondMainIndustryOptions, setSecondMainIndustryOptions] = useState([])
  const [confirmLoading, setConfirmLoading] = useState(false)

  useEffect(() => {
    if (open) {
      queryCustomerInfo()
    }
  }, [open])
  useEffect(() => {
    getMainIndustryOptions()
  }, [])

  // 获取一级行业
  const getMainIndustryOptions = async () => {
    const res = await API.getDicData({ key: 'main_industry' })
    const industryData = res.data?.map(({ dictResponse, children }) => {
      const secondOptions = children.map(item => ({ label: item.label, value: `${item.id}` }))
      return ({ label: dictResponse.description, value: `${dictResponse.id}`, children: secondOptions })
    })
    setMainIndustryOptions(industryData || [])
  }
  // 获取二级行业
  const handleChangeSelectMainIndustry = (val) => {
    const secondOptions = mainIndustryOptions.find(item => item.value === val)?.children || []
    setSecondMainIndustryOptions(secondOptions)
    form.setFieldValue('secondMainIndustry', '')
  }
  // 初始化
  const queryCustomerInfo = async () => {
    const initData = {
      accountName: '',
      mainIndustry: '',
      secondMainIndustry: '',
      mainBusiness: '',
      url: '',
      loginAccount: '',
      loginPwd: '',
      contactName: '',
      contactEmail: '',
      contactPhone: '',
      contactAddress: ''
    }
    setCustomerInfo(initData)
    setInitCustomerInfo(initData)
    form.setFieldsValue(initData)
    if (customerRecord.id) {
      const res = await API.customerDetail({ id: customerRecord.id })
      const resData = res?.data || {}
      const customerData = {
        ...resData
      }
      handleChangeSelectMainIndustry(resData.mainIndustry)
      setCustomerInfo(customerData)
      setInitCustomerInfo(customerData)
      form.setFieldsValue(customerData)
    }
  }

  // 提交数据
  const submitCustomer = async () => {
    const postData = {
      ...customerInfo
    }
    let customerApi = API.customerAdd
    let msg = t('创建成功')

    if (customerRecord.id) {
      postData.id = customerRecord.id
      customerApi = API.customerUpdate
      msg = t('编辑成功')
    }
    setConfirmLoading(true)
    const res = await customerApi(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(msg)
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitCustomer()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(customerInfo) === JSON.stringify(initCustomerInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setCustomerInfo({
      ...customerInfo,
      ...changedValues
    })
  }

  return (
    <Modal
      className={styles['create-customer']}
      title={customerRecord.id ? t('编辑') : t('新增')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Form
        form={form}
        name='customerForm'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <div className={styles['form-title']}>{t('基本信息')}</div>
        <Form.Item
          label={t('客户名称')}
          name="accountName"
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入内容'),
            },
            {
              type: 'string',
              min: 1,
              max: 100,
              message: t('长度最多100位'),
            },
          ]}
        >
          <Input placeholder={t('请输入内容')} />
        </Form.Item>
        <Row>
          <Form.Item
            label={t('主要行业应用')}
            name='mainIndustry'
            style={{ width: '549px', paddingLeft: '54px' }}
          >
            <Select
              style={{
                width: 240,
              }}
              placeholder={t('请选择')}
              options={mainIndustryOptions}
              onChange={handleChangeSelectMainIndustry}
            />
          </Form.Item>
          <Form.Item
            name='secondMainIndustry'
            style={{ marginLeft: '-146px' }}
          >
            <Select
              style={{
                width: 240,
                marginLeft: 15
              }}
              placeholder={t('请选择')}
              options={secondMainIndustryOptions}
            />
          </Form.Item>
        </Row>
        <Form.Item
          label={t('主营业务')}
          name='mainBusiness'
          rules={[
            {
              type: 'string',
              min: 1,
              max: 200,
              message: t('长度最多200位'),
            },
          ]}
        >
          <Input  placeholder={t('请输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('网址')}
          name='url'
          rules={[
            {
              type: 'url',
              message: t('url不合法'),
            },
          ]}
        >
          <Input placeholder={t('请输入内容')} />
        </Form.Item>
        <div className={styles['form-line']}></div>
        <div className={styles['form-title']}>{t('登录信息')}</div>
        <Form.Item
          label={t('登录账号')}
          name='loginAccount'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('请输入登录账号'),
            },
            {
              type: 'string',
              max: 50,
              message: t('长度最多50位'),
            },
            {
              type: 'email',
              message: t('登录账号必须是邮箱格式'),
            },
          ]}
        >
          <Input placeholder={t('请输入登录账号')} />
        </Form.Item>
        {
          !customerRecord.id && <Form.Item
            label={t('登录密码')}
            name='loginPwd'
            rules={[
              {
                required: true,
                whitespace: true,
                message: t('请输入登录密码'),
              },
              {
                pattern: /^([0-9a-zA-Z]){8,50}$/,
                message: t('密码为字母+数字组合，长度8到50位'),
              },
            ]}
          >
            <Input.Password placeholder={t('请输入登录密码')} />
          </Form.Item>
        }
        <div className={styles['form-line']}></div>
        <div className={styles['form-title']}>{t('联系方式')}</div>
        <Form.Item
          label={t('联系人')}
          name='contactName'
          rules={[{
            type: 'string',
            max: 100,
            message: t('长度最多100位'),
          }]}
        >
          <Input placeholder={t('请输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('联系人电话')}
          name='contactPhone'
          rules={[{
            type: 'string',
            max: 50,
            message: t('长度最多50位'),
          },
          {
            pattern: /^[0-9,.+_\- /\\()]+$/,
            message: t('电话只能是数字和_ - + / \\ ().字符组成'),
          },
          ]}
        >
          <Input placeholder={t('请输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('联系人邮箱')}
          name='contactEmail'
          rules={[
            {
              type: 'email',
              message: t('邮箱格式不正确'),
            },
            {
              type: 'string',
              max: 100,
              message: t('长度最多100位'),
            }
          ]}
        >
          <Input placeholder={t('请输入内容')} />
        </Form.Item>
        <Form.Item
          label={t('联系人地址')}
          name='contactAddress'
          rules={[{
            type: 'string',
            max: 200,
            message: t('长度最多200位'),
          }]}
        >
          <Input placeholder={t('请输入内容')} />
        </Form.Item>
      </Form>
    </Modal>
  )
}

export default CreateCustomer
