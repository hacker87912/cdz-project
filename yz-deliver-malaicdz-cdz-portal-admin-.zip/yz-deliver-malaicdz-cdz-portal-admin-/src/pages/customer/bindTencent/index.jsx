import React, { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import styles from './index.module.scss'
import { Modal, Form, Input, Alert, Button, message } from 'antd'
import { ExclamationCircleFilled } from '@ant-design/icons'
import { useStore } from '@/store'
import * as API from '@/services/customer'

function BindTencent ({ open, onClose, customerRecord = {}, onSubmit }) {
  const { t } = useTranslation()
  const [form] = Form.useForm()
  const [bindInfo, setBindInfo] = useState({})
  const [initBindInfo, setInitBindInfo] = useState({})
  const [changeSecret, setChangeSecret] = useState(false)
  const [secretId, setSecretId] = useState('')
  const [secretKey, setSecretKey] = useState('')
  const [confirmLoading, setConfirmLoading] = useState(false)
  const { global } = useStore()

  useEffect(() => {
    if (open) {
      queryBindInfo()
    }
  }, [open])

  // 初始化
  const queryBindInfo = async () => {
    const initData = {
      uid: '',
      roleName: '',
      providerName: '',
      secretId: '',
      secretKey: '',
    }
    setBindInfo(initData)
    setInitBindInfo(initData)
    form.setFieldsValue(initData)
    if (customerRecord.bindStatus) {
      const res = await API.customerDetail({ id: customerRecord.id })
      const cloudInfo = res?.data?.cloudInfo || {}
      setSecretId(cloudInfo.secretId)
      setSecretKey(cloudInfo.secretKey)
      const cloudData = {
        ...cloudInfo,
        uid: `${cloudInfo.uid}`,
        secretId: '',
        secretKey: ''
      }
      setBindInfo(cloudData)
      setInitBindInfo(cloudData)
      form.setFieldsValue(cloudData)
      setChangeSecret(false)
    }
  }

  // 提交数据
  const submitCustomer = async () => {
    const postData = {
      ...bindInfo,
      id: customerRecord.id,
      secretId: bindInfo.secretId || secretId,
      secretKey: bindInfo.secretKey || secretKey
    }
    setConfirmLoading(true)
    const res = await API.qcloudBind(postData)
    setConfirmLoading(false)
    if (res.code === 0) {
      message.success(t('绑定成功'))
      onSubmit()
    }
  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitCustomer()
    })
  }
  // 点击取消弹框
  const handleCancel = () => {
    if (JSON.stringify(bindInfo) === JSON.stringify(initBindInfo)) {
      onClose()
    } else {
      Modal.confirm({
        title: t('当前有修改的内容, 确认是否要保存?'),
        icon: <ExclamationCircleFilled />,
        okText: t('是'),
        okType: 'danger',
        cancelText: t('否'),
        async onOk () {
          handleOk()
        },
        onCancel () {
          onClose()
        }
      })

    }
  }
  // 表单字段回调
  const handleFormValuesChange = (changedValues) => {
    setBindInfo({
      ...bindInfo,
      ...changedValues
    })
  }
  const bindMessage = (
    <>
      <span>{t('云账户绑定需提供以下信息：1、uid 账户ID  2、provider-name 身份提供商名称 3、 role-name 角色名称 4、SecretId SecretKey 5、saml协议文件说明：腾讯云主帐户 ID，可前往 账号信息 - 控制台 查看；SAML 身份提供商名称，可前往 身份提供商 - 控制台 查看；角色名称可前往 角色 - 控制台 查看；SecretId和SecretKey，可前往 访问密钥 - 控制台 查看。可如需帮助，可查看 ')}</span>
      <a href={global.locale === 'zh' ? 'https://docs.qq.com/doc/DY1NHQkdQWmdFeXRt' : 'https://docs.qq.com/doc/DY21DcmZjRUFMcVpC'} target='_'>{t('云账号绑定指南')}</a>
    </>
  )
  return (
    <Modal
      className={styles['create-customer']}
      title={t('绑定腾讯云')}
      open={open}
      onOk={handleOk}
      onCancel={handleCancel}
      width={800}
      forceRender
      maskClosable={false}
      confirmLoading={confirmLoading}
    >
      <Alert
        message={bindMessage}
        type='info'
        showIcon
      />
      <Form
        form={form}
        name='bindForm'
        onValuesChange={handleFormValuesChange}
        labelCol={{
          span: 5,
        }}
        wrapperCol={{
          span: 16,
        }}
      >
        <div className={styles['form-title']}>{t('基本信息')}</div>
        <Form.Item
          label={t('账号ID')}
          name='uid'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('输入腾讯云uid 账号ID'),
            },
          ]}
        >
          <Input type='number' placeholder={t('输入腾讯云uid 账号ID')} />
        </Form.Item>
        <Form.Item
          label={t('身份提供商名称')}
          name='providerName'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('输入腾讯云provider-name 身份提供商名称'),
            },
          ]}
        >
          <Input  placeholder={t('输入腾讯云provider-name 身份提供商名称')} />
        </Form.Item>
        <Form.Item
          label={t('角色名称')}
          name='roleName'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('输入腾讯云role-name 角色名称'),
            },
          ]}
        >
          <Input placeholder={t('输入腾讯云role-name 角色名称')} />
        </Form.Item>
        <div className={styles['form-title']}>
          <span>{t('访问密钥')}</span>
          { !!customerRecord.bindStatus && <Button type='link' onClick={() => setChangeSecret(!changeSecret)}>{changeSecret ? t('取消') : t('变更密钥')}</Button> }
        </div>
        {
          (!customerRecord.bindStatus || changeSecret) &&
        <Form.Item
          label={t('SecretId')}
          name='secretId'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('输入腾讯云SecretId'),
            },
          ]}
        >
          <Input placeholder={t('输入腾讯云SecretId')} />
        </Form.Item>
        }
        {
          (!customerRecord.bindStatus || changeSecret) &&
        <Form.Item
          label={t('SecretKey')}
          name='secretKey'
          rules={[
            {
              required: true,
              whitespace: true,
              message: t('输入腾讯云SecretKey'),
            },
          ]}
        >
          <Input placeholder={t('输入腾讯云SecretKey')} />
        </Form.Item>
        }
      </Form>
    </Modal>
  )
}

export default BindTencent
