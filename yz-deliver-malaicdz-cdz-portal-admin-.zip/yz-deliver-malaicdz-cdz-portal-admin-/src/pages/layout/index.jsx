import React, { useState, useEffect } from 'react'
import {
  TeamOutlined,
  DollarCircleOutlined,
  BellOutlined,
  UserOutlined,
  AppstoreOutlined,
  CodeOutlined,
  MailOutlined,
  DownOutlined,
  DesktopOutlined
} from '@ant-design/icons'
import { Layout, Menu, Avatar, Watermark } from 'antd'
import { useLocation, Navigate, Outlet, useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import * as API from '@/services/auth'
import { removeItem, setItem } from '@/utils/storage'
import { useStore } from '@/store'
import styles from './index.module.scss'

const PageLayout =  () => {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const { t, i18n } = useTranslation()
  const { global } = useStore()
  const [menuData, setMenuData] = useState([])
  const [firstPath, setFirstPath] = useState('')
  const [openKeys, setOpenKeys] = useState([])
  const [selectedKeys, setSelectedKeys] = useState([])
  const [collapsed, setCollapsed] = useState(false)
  const menusIconMap = {
    'ACCOUNT_MANAGEMENT': TeamOutlined,
    'EXPENSE_CENTER': DollarCircleOutlined,
    'PORTAL_CMS': AppstoreOutlined,
    'MESSAGE_CENTER': BellOutlined,
    'ADMIN_MANAGEMENT': UserOutlined,
    'LOG_MANAGEMENT': CodeOutlined,
    'PORTAL_CONTACT_RECORD': MailOutlined
  }
  useEffect(() => {
    getUserMenu()
  }, [])
  useEffect(() => {
    setOpenKeys([pathname.split('/')[1]])
    setSelectedKeys([getSelectedKey()])
  }, [pathname, menuData])

  // 获取菜单数据
  const getUserMenu = async () => {
    let menuAccess = []
    const res = await API.getMenu()
    if (res.code === 0) {
      const menus = res.data || []
      const loopMenu = (arr) => {
        return arr.map(menuItem => {
          let itemData = {
            key: menuItem.url,
            icon: menusIconMap[menuItem.code]? React.createElement(menusIconMap[menuItem.code]) : <></>,
            label: <span className='ant-menu-title-content' title={menuItem.name}>{menuItem.name}</span>
          }
          if (menuItem.children) {
            itemData.children = loopMenu(menuItem.children)
          } else {
            itemData.path = menuItem.url
          }
          menuAccess.push(menuItem.code)
          return itemData
        })
      }
      const menusData = loopMenu(menus)
      setMenuData(menusData)
      getFirstMenuPath(menusData)
      setItem('menuAccess', menuAccess)
    }

  }
  // 获取第一个菜单页面
  const getFirstMenuPath = (menusData) => {
    let path = ''
    const loopMenu = (arr) => {
      arr.forEach(menuItem => {
        if (menuItem.path) {
          path = path || menuItem.path
        } else {
          loopMenu(menuItem.children)
        }
      })
    }
    loopMenu(menusData)
    setFirstPath(path)
  }
  // 获取当前菜单高亮key
  const getSelectedKey = () => {
    const loop = (data) => {
      return data.reduce((pre, cur) => {
        const { children, path } = cur
        if (pre) return pre
        if (pathname.startsWith(path)) {
          return path
        }
        if (children && children.length) {
          return loop(children)
        }
      }, '')
    }
    return loop(menuData)
  }
  // 打开菜单
  const handleOpenChangeMenu = (keys) => {
    setOpenKeys([keys[keys.length - 1]])
  }
  // 点击菜单
  const handleClickMenuItem = ({ key }) => {
    setSelectedKeys([key])
    navigate(key)
  }
  // 收起展开菜单
  const handleOnCollapse = (val) => {
    setCollapsed(val)
    if (!val) {
      setTimeout(() => {
        setOpenKeys([pathname.split('/')[1]])
      }, 100)
    }
  }
  // 退出登录
  const handleLogout = async () => {
    const res = await API.logout()
    if (res.code === 0) {
      removeItem('Authorization')
      navigate('/login')
    }
  }
  // 切换语言
  const handleChangeLang = () => {
    const lang = global.locale === 'zh' ? 'en' : 'zh'
    global.setLocale(lang)
    // i18n.changeLanguage(lang)
    window.location.reload()
  }
  const { Header, Content, Sider } = Layout

  return pathname === '/' && firstPath ? <Navigate to={firstPath} replace /> : (
    <div className={styles['page-layout']}>
      <Layout>
        <Header className={styles['page-header']}>
          <div className={styles['left']}>
            <a href='/' className={styles['logo']}>
              <img src='https://gw.alipayobjects.com/zos/rmsportal/KDpgvguMpGfqaHPjicRK.svg' alt='logo' />
              <span>CDZ Cloud</span>
            </a>
          </div>
          <div className={styles['right']}>
            <a href={`${import.meta.env.VITE_PORTAL_URL}`} target='_blank' className={styles['portal']} rel="noreferrer">
              <span className={styles['icon']}><DesktopOutlined /></span>
              <span className={styles['name']}>{t('官网')}</span>
            </a>
            <div className={styles['user']}>
              <Avatar
                size={28}
                style={{
                  backgroundColor: '#87d068',
                }}
                icon={<UserOutlined />}
              />
              <span className={styles['name']}>{global.userInfo?.accountName}</span>
              <DownOutlined />
              <ul className={styles['logout']}>
                <li className={styles['item']} onClick={handleLogout}>{t('退出登录')}</li>
                <li className={styles['item']} onClick={handleChangeLang}>{global.locale === 'zh' ? 'English' : '简体中文'}</li>
              </ul>
            </div>

          </div>
        </Header>
        <Layout>
          <Sider
            className={styles['page-menu']}
            collapsible
            collapsed={collapsed}
            onCollapse={handleOnCollapse}
          >
            <Menu
              mode='inline'
              items={menuData}
              theme='dark'
              openKeys={openKeys}
              onOpenChange={handleOpenChangeMenu}
              selectedKeys={selectedKeys}
              onClick={handleClickMenuItem}
            />
          </Sider>
          <Layout>
            <Content className={styles['page-content']}>
              <Watermark
                content={['CDZ Cloud', global.userInfo?.accountName]}
                font={{color: 'rgba(0,0,0,0.07)'}}
                style={{minHeight: '100%'}}
              >
                <Outlet/>
              </Watermark>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </div>
  )
}

export default PageLayout
