import axios from 'axios'
import { message } from 'antd'
import { getItem, clearAll } from '@/utils/storage'
import { throttle } from '@/utils/utils'
import { router } from '@/router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

// 创建axios实例
const instance = axios.create({
  baseURL: '/api',
  // timeout: 3000,
  headers: {
    'X-Access-Source': 'cdz-admin'
  }
})
// 拦截请求头
instance.interceptors.request.use(
  config => {
    config.headers['Authorization'] = config.headers['Authorization'] || getItem('Authorization')
    config.headers['Content-Language'] = getItem('locale')
    return config
  },
  error => {
    return Promise.reject(error)
  }
)
// 拦截响应头
instance.interceptors.response.use(
  response => {
    if (response.status === 200) {
      return Promise.resolve(response.data || response)
    } else {
      return Promise.reject()
    }
  },
  error => {
    return Promise.reject(error)
  }
)
const messageError = throttle(message.error, 300)
// 请求回调处理函数
const sucFun = resData => {
  NProgress.done()
  const resOkCodes = [0, '0', 200, '200', 'ok']
  if (resData.hasOwnProperty('code')) {
    if (!resOkCodes.includes(resData.code)) {
      messageError({
        content: resData.msg || resData.message || 'data error',
      })
    }
  }
  return resData
}
const errFun = axiosError => {
  NProgress.done()
  const err = axiosError.response
  if (err) {
    if (err.status === 401) {
      // messageError({ content: 'Login invalidation' })
      clearAll()
      router.navigate('/login', { replace: true })
    } else {
      messageError({
        content: err.data?.msg || `request failed, status is ${err.status || err.statusText}`
      })
    }
  } else {
    messageError({
      content: axiosError.message || 'server error, no response'
    })
  }
  return err

}
// 普通POST请求
export const $post = (url = '', data = {}, config = {}) => {
  NProgress.start()
  return instance.post(url, data, config).then(sucFun).catch(errFun)
}
// 普通PUT请求
export const $put = (url = '', data = {}, config = {}) => {
  NProgress.start()
  return instance.put(url, data, config).then(sucFun).catch(errFun)
}
// 普通Get请求
export const $get = (url = '', data = {}, config = {}) => {
  NProgress.start()
  return instance.get(url, { ...config, params: data }).then(sucFun).catch(errFun)
}
// 普通DELETE请求
export const $delete = (url = '', data = {}, config = {}) => {
  NProgress.start()
  return instance.delete(url, { ...config, data }).then(sucFun).catch(errFun)
}
// 文件流请求
export const $postBlob = (url = '', data = {}) => {
  NProgress.start()
  return instance.post(url, data, { responseType: 'blob' }).then(sucFun).catch(errFun)
}
// 文件流请求
export const $getBlob = (url = '', data = {}, config = {}) => {
  NProgress.start()
  return instance.get(url, { ...config, params: data, responseType: 'blob' }).then(sucFun).catch(errFun)
}
