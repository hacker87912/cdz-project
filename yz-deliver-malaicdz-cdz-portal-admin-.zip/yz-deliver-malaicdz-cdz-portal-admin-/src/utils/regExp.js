// 身份证正则
export const isCardNo = function (str) {
  var pattern = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
  return pattern.test(str)
}

// 检测手机号码
export const isPhone = function (str) {
  var pattern = /^(0|86|17951)?(13[0-9]|15[012356789]|17[0-9]|18[0-9]|14[57]|17[678])[0-9]{8}$/
  return pattern.test(str)
}

// 检测邮箱
export const isEmail = function (str) {
  var pattern = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/
  return pattern.test(str)
}

// 检测密码
export const isPassword = function (str) {
  let pattern = /^(?![\d]+$)(?![a-zA-Z]+$)(?![^\da-zA-Z]+$).{8,20}$/
  return pattern.test(str)
}


// 检测QQ
export const isQQ = function (str) {
  var pattern = /^[1-9][0-9]{4,9}$/
  return pattern.test(str)
}

// 检测html标签
export const filterHTMLTag = function (str) {
  // var src = msg.replace(/<\/?[^>]*>/g, '') // 去除HTML Tag
  str.replace(/[|]*\n/, '') // 去除行尾空格
  str.replace(/&npsp;/ig, '') // 去掉npsp
  let pattern = /<\/?[^>]*>/g
  return pattern.test(str)
}
