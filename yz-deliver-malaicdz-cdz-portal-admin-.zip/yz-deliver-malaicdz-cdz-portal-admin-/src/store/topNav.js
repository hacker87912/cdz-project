import { makeAutoObservable } from 'mobx'
import { navEntranceList, navClassifyList } from '@/services/topNav'

class TopNavStore {
  constructor () {
    makeAutoObservable(this)
  }

  navEntranceData = []
  navClassifyData = []

  getNavEntrance = async () => {
    const res = await navEntranceList()
    this.navEntranceData = res.data || []
    return res
  }
  getNavClassify = async () => {
    const res = await navClassifyList()
    this.navClassifyData = res.data || []
    return res
  }
}
const topNavStore = new TopNavStore()
export default topNavStore
