import React, { createContext, useContext } from 'react'
// import { observer } from 'mobx-react-lite'
import global from './global'
import topNav from './topNav'

const comboStore = {
  global,
  topNav
}
const StoreContext = createContext()
export function useStore () {
  const context = useContext(StoreContext)
  // if (context === undefined) {
  //   throw new Error('useStore must be used within StoreProvider')
  // }
  return context || comboStore
}
export function StoreProvider ({ children, store }) {
  return <StoreContext.Provider value={store}>{children}</StoreContext.Provider>
}
export default comboStore
