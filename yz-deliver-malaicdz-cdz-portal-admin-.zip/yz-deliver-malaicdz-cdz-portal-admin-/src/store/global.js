import { makeAutoObservable } from 'mobx'
import { getItem, setItem } from '@/utils/storage'

class GlobalStore {
  constructor () {
    makeAutoObservable(this)
  }
  // 用户信息
  userInfo = getItem('userInfo') || {}
  setUserInfo = (data) => {
    this.userInfo = data
    setItem('userInfo', data)
  }
  // 当前语言
  locale = getItem('locale') || 'zh'
  setLocale = (lang) => {
    this.locale = lang
    setItem('locale', lang)
  }

}
const globalStore = new GlobalStore()
export default globalStore
