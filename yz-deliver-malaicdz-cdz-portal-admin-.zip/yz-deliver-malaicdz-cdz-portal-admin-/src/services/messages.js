import { $get, $post, $delete } from '@/utils/request'

// 通知公告
export const getNotification = (data = {}) => $get('/cdz-cms/admin/notification/getPageList', data)

export const addNotification = (data = {}) => $post('/cdz-cms/admin/notification/add', data)

export const editNotification = (data = {}) => $post('/cdz-cms/admin/notification/edit', data)

export const deleteNotification = (id) => $delete(`/cdz-cms/admin/notification/delete?id=${id}`)

export const updateReleaseStatus = (data = {}) => $post('/cdz-cms/admin/notification/updateReleaseStatus', data)

export const getDetailById = (id) => $get(`/cdz-cms/admin/notification/getDetailById?id=${id}`)
