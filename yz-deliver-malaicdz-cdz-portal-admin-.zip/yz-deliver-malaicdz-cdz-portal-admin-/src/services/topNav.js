import { $get, $post, $delete } from '@/utils/request'

// 顶部导航分页查询
export const navBarQuery = (data = {}) => $get('/cdz-cms/admin/navigation/top/query', data)
export const navBarDetail = (id) => $get(`/cdz-cms/admin/navigation/top/detail/${id}`)
// 新增导航菜单入口
export const addNavMenu = (data = {}) => $post('/cdz-cms/admin/navigation/top/add', data)
// 编辑导航菜单入口
export const editNavMenu = (data = {}) => $post('/cdz-cms/admin/navigation/top/update', data)
// 删除导航菜单入口
export const deleteNavMenu = (id) => $delete(`/cdz-cms/admin/navigation/top/del/${id}`)

// 顶部导航入口查询
export const navEntranceQuery = (data = {}) => $get('/cdz-cms/admin/navigation/top/entrance/query', data)
export const navEntranceList = (data = {}) => $get('/cdz-cms/admin/navigation/top/entrance/list', data)
export const navEntranceDetail = (id) => $get(`/cdz-cms/admin/navigation/top/entrance/detail/${id}`)
// 新增导航入口
export const addNavEntrance = (data = {}) => $post('/cdz-cms/admin/navigation/top/entrance/add', data)
// 修改导航入口
export const editNavEntrance = (data = {}) => $post('/cdz-cms/admin/navigation/top/entrance/update', data)
export const editEntranceSort = (data = {}) => $post('/cdz-cms/admin/navigation/top/entrance/updateSort', data)
// 删除导航入口
export const deleteNavEntrance = (id) => $delete(`/cdz-cms/admin/navigation/top/entrance/del/${id}`)

// 顶部菜单分类查询
export const navClassifyQuery = (data = {}) => $get('/cdz-cms/admin/navigation/top/classify/query', data)
export const navClassifyList = (data = {}) => $get('/cdz-cms/admin/navigation/top/classify/list', data)
export const navClassifyDetail = (id) => $get(`/cdz-cms/admin/navigation/top/classify/detail/${id}`)
// 新增菜单分类
export const addNavClassify = (data = {}) => $post('/cdz-cms/admin/navigation/top/classify/add', data)
// 修改菜单分类
export const editNavClassify = (data = {}) => $post('/cdz-cms/admin/navigation/top/classify/update', data)
export const editClassifySort = (data = {}) => $post('/cdz-cms/admin/navigation/top/classify/updateSort', data)
// 删除菜单分类
export const deleteNavClassify = (id) => $delete(`/cdz-cms/admin/navigation/top/classify/del/${id}`)

export const editNavStatus = (data = {}) => $post('/cdz-cms/admin/navigation/top/update/status', data)
export const editNavSort = (data = {}) => $post('/cdz-cms/admin/navigation/top/update/sort', data)
