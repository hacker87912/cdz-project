import { $get, $post } from '@/utils/request'

export const getMenu = (data = {}) => $get('/cdz-auth/admin/menus', data)

export const login = (data = {}) => $post('/cdz-auth/admin/login', data)

export const logout = (data = {}) => $post('/cdz-auth/admin/logout', data)

