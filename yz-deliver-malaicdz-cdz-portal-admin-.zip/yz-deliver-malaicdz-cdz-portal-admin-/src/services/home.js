import { $get, $post, $delete } from '@/utils/request'

// 图片上传密钥
export const uploadImgSecret = (data = {}) => $get('/cdz-cms/admin/resource/getUploadCredentials', data)

// 分页查询banner
export const bannerQuery = (data = {}) => $get('/cdz-cms/admin/release/slideshow/query', data)
// 查询banner
export const bannerDetail = (data = {}) => $get(`/cdz-cms/admin/release/slideshow/detail/${data.id}`)
// 新增banner
export const bannerAdd = (data = {}) => $post('/cdz-cms/admin/release/slideshow/add', data)
// 更新banner
export const bannerUpdate = (data = {}) => $post('/cdz-cms/admin/release/slideshow/update', data)
// 删除banner
export const bannerDel = (data = {}) => $delete(`/cdz-cms/admin/release/slideshow/del/${data.id}`)
// banner状态更新
export const bannerStatus = (data = {}) => $post('/cdz-cms/admin/release//slideshow/update/status', data)
// banner排序更新
export const bannerSort = (data = {}) => $post('/cdz-cms/admin/release//slideshow/update/sort', data)


// 分页查询优势产品
export const productQuery = (data = {}) => $get('/cdz-cms/admin/release/superior/query', data)
// 查询优势产品
export const productDetail = (data = {}) => $get(`/cdz-cms/admin/release/superior/detail/${data.id}`)
// 新增优势产品
export const productAdd = (data = {}) => $post('/cdz-cms/admin/release/superior/add', data)
// 更新优势产品
export const productUpdate = (data = {}) => $post('/cdz-cms/admin/release/superior/update', data)
// 删除优势产品
export const productDel = (data = {}) => $delete(`/cdz-cms/admin/release/superior/del/${data.id}`)
// 优势产品状态更新
export const productStatus = (data = {}) => $post('/cdz-cms/admin/release//superior/update/status', data)
// 优势产品排序更新
export const productSort = (data = {}) => $post('/cdz-cms/admin/release//superior/update/sort', data)

// 分页查询客户案例
export const customerQuery = (data = {}) => $get('/cdz-cms/admin/release/customer/query', data)
// 查询客户案例
export const customerDetail = (data = {}) => $get(`/cdz-cms/admin/release/customer/detail/${data.id}`)
// 新增客户案例
export const customerAdd = (data = {}) => $post('/cdz-cms/admin/release/customer/add', data)
// 更新客户案例
export const customerUpdate = (data = {}) => $post('/cdz-cms/admin/release/customer/update', data)
// 删除客户案例
export const customerDel = (data = {}) => $delete(`/cdz-cms/admin/release/customer/del/${data.id}`)
// 客户案例状态更新
export const customerStatus = (data = {}) => $post('/cdz-cms/admin/release//customer/update/status', data)
// 客户案例展开更新
export const customerExpand = (data = {}) => $post('/cdz-cms/admin/release//customer/update/expand', data)
// 客户案例排序更新
export const customerSort = (data = {}) => $post('/cdz-cms/admin/release//customer/update/sort', data)
