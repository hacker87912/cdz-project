import { $get, $post, $delete } from '@/utils/request'


// 分页查询account
export const accountQuery = (data = {}) => $get('/cdz-auth/admin/user/getPageList', data)
// id查询account
export const accountCheck = (data = {}) => $get('/cdz-auth/admin/user/getAdminUserDetailById', data)
// 新增account
export const accountAdd = (data = {}) => $post('/cdz-auth/admin/user/add', data)
// 编辑account
export const accountEdit = (data = {}) => $post('/cdz-auth/admin/user/edit', data)
// 删除account
export const accountDelete = (data = {}) => $delete('/cdz-auth/admin/user/delete', data)
// 重置密码
export const accountReset = (data = {}) => $post('/cdz-auth/admin/user/resetPassword', data)
// 切换状态
export const accountStatus = (data = {}) => $post('/cdz-auth/admin/user/updateStatus', data)
// 查询角色
export const roleCheck = (data = {}) => $get('/cdz-auth/admin/user/getNormalAdminRoleListByKey', data)
