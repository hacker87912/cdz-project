import { $get, $post, $delete } from '@/utils/request'


// 分页查询role
export const roleQuery = (data = {}) => $get('/cdz-auth/admin/role/getPageList', data)
// id查询role
export const roleCheck = (data = {}) => $get('/cdz-auth/admin/role/getAdminRoleDetailById', data)
// 新增role
export const roleAdd = (data = {}) => $post('/cdz-auth/admin/role/add', data)
// 编辑role
export const roleEdit = (data = {}) => $post('/cdz-auth/admin/role/edit', data)
// 删除role
export const roleDelete = (data = {}) => $delete('/cdz-auth/admin/role/delete', data)
// 设置权限
export const roleReset = (data = {}) => $post('/cdz-auth/admin/role/updateRoleMenu', data)
// 切换状态
export const roleStatus = (data = {}) => $post('/cdz-auth/admin/role/updateStatus', data)
// 获取角色权限
export const roleAccess = (data = {}) => $get('/cdz-auth/admin/role/getAdminRoleAuthorityById', data)
