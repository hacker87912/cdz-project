import { $get, $post, $delete } from '@/utils/request'

// 底部导航分页查询
export const bottomNavBarQuery = (data = {}) => $get('/cdz-cms/admin/navigation/bottom/query', data)
export const bottomNavBarDetail = (id) => $get(`/cdz-cms/admin/navigation/bottom/detail/${id}`)
// 新增导航菜单入口
export const addBottomNavMenu = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/add', data)
// 编辑导航菜单入口
export const editBottomNavMenu = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/update', data)
// 删除导航菜单入口
export const deleteBottomNavMenu = (id) => $delete(`/cdz-cms/admin/navigation/bottom/del/${id}`)

// 底部菜单分类查询
export const bottomNavClassifyQuery = (data = {}) => $get('/cdz-cms/admin/navigation/bottom/classify/query', data)
export const bottomNavClassifyList = (data = {}) => $get('/cdz-cms/admin/navigation/bottom/classify/list', data)
export const bottomNavClassifyDetail = (id) => $get(`/cdz-cms/admin/navigation/bottom/classify/detail/${id}`)
// 新增菜单分类
export const addBottomNavClassify = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/classify/add', data)
// 修改菜单分类
export const editBottomNavClassify = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/classify/update', data)
export const editBottomNavClassifySort = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/classify/updateSort', data)
// 删除菜单分类
export const deleteBottomNavClassify = (id) => $delete(`/cdz-cms/admin/navigation/bottom/classify/del/${id}`)

export const editBottomNavStatus = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/update/status', data)
export const editBottomNavSort = (data = {}) => $post('/cdz-cms/admin/navigation/bottom/update/sort', data)
