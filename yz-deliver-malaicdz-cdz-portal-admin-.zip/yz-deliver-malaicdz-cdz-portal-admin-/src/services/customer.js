import { $get, $post, $delete, $put } from '@/utils/request'

// 分页查询
export const customerQuery = (data = {}) => $post('/cdz-auth/admin/account/getList', data)
// IDP元数据信息下载
export const fileDownload = (data = {}) => $get(`/cdz-auth/admin/account/metadata/download/${data.id}`, data)
// 绑定腾讯云
export const qcloudBind = (data = {}) => $post('/cdz-auth/admin/account/qCloud/binding', data)
// 新增
export const customerAdd = (data = {}) => $post('/cdz-auth/admin/account/add', data)
// 删除
export const customerDelete = (data = {}) => $delete(`/cdz-auth/admin/account/delete/${data.id}`)
// 修改
export const customerUpdate = (data = {}) => $put('/cdz-auth/admin/account/edit', data)
// 查询
export const customerDetail= (data = {}) => $get(`/cdz-auth/admin/account/info/${data.id}`, data)
// 设置状态
export const customerStatus = (data = {}) => $post('/cdz-auth/admin/account/setStatus', data)
// 重置密码
export const resetPassword = (data = {}) => $post('/cdz-auth/admin/account/resetPassword', data)
// 获取字典
export const getDicData = (data = {}) => $post('/cdz-auth/common/dict/key/getList', data)
