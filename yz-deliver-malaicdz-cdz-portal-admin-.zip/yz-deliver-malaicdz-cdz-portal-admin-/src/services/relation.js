import { $get, $getBlob } from '@/utils/request'

export const getRecordList = (data = {}) => $get('/cdz-auth/admin/contact-record/getPageList', data)
export const getRecordListExport = ({ startTime, endTime }) => $getBlob(`/cdz-auth/admin/contact-record/export?startTime=${startTime}&endTime=${endTime}`)
