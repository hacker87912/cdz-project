import { $get, $post, $delete } from '@/utils/request'

// 查询定价发布
export const getPrice = (data = {}) => $get('/cdz-cms/admin/product/pricing/query', data)
// 新增定价发布
export const addPrice = (data = {}) => $post('/cdz-cms/admin/product/pricing/add', data)
// 编辑定价发布
export const editPrice = (data = {}) => $post('/cdz-cms/admin/product/pricing/update', data)
// 删除定价发布
export const deletePrice = (id) => $delete(`/cdz-cms/admin/product/pricing/del/${id}`)

export const editPriceStatus = (data = {}) => $post('/cdz-cms/admin/product/pricing/update/status', data)
export const editPriceSort = (data = {}) => $post('/cdz-cms/admin/product/pricing/update/sort', data)
export const priceDetail = (id) => $get(`/cdz-cms/admin/product/pricing/detail/${id}`)
