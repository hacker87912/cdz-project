import { $get, $post } from '@/utils/request'

// 服务条款查询
export const serviceQuery = (data = {}) => $get('/cdz-cms/admin/terms/service/query', data)
export const serviceDetail = (id) => $get(`/cdz-cms/admin/terms/service/detail/${id}`)
// 新增服务条款
export const addService = (data = {}) => $post('/cdz-cms/admin/terms/service/update', data)
// 隐私政策查询
export const policyQuery = (data = {}) => $get('/cdz-cms/admin/terms/policy/query', data)
export const policyDetail = (id) => $get(`/cdz-cms/admin/terms/policy/detail/${id}`)
// 新增隐私政策
export const addPolicy = (data = {}) => $post('/cdz-cms/admin/terms/policy/update', data)
// 版本说明查询
export const versionQuery = (data = {}) => $get('/cdz-cms/admin/terms/version/query', data)
export const versionDetail = (id) => $get(`/cdz-cms/admin/terms/version/detail/${id}`)
// 新增版本说明
export const addVersion = (data = {}) => $post('/cdz-cms/admin/terms/version/update', data)
