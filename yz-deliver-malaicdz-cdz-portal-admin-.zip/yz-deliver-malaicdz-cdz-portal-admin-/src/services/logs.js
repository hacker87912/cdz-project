import { $get } from '@/utils/request'

export const getOperationLogPageList = (data = {}) => $get('/cdz-auth/admin/log/getOperationLogPageList', data)

export const getLoginLogPageList = (data = {}) => $get('/cdz-auth/admin/log/getLoginLogPageList', data)
