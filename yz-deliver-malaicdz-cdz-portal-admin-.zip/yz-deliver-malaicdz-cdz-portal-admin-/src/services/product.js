import { $get, $post, $delete } from '@/utils/request'

// 查询产品发布
export const getProduct = (data = {}) => $get('/cdz-cms/admin/product/query', data)
export const productDetail = (id) => $get(`/cdz-cms/admin/product/detail/${id}`)
// 新增产品发布
export const addProduct = (data = {}) => $post('/cdz-cms/admin/product/add', data)
// 编辑产品发布
export const editProduct = (data = {}) => $post('/cdz-cms/admin/product/update', data)
// 删除产品发布
export const deleteProduct = (id) => $delete(`/cdz-cms/admin/product/del/${id}`)

// 查询产品分类
export const getProductClassify = (data = {}) => $get('/cdz-cms/admin/product/classify/query', data)
export const getProductClassifyList = (data = {}) => $get('/cdz-cms/admin/product/classify/list', data)
export const productClassifyDetail = (id) => $get(`/cdz-cms/admin/product/classify/detail/${id}`)
// 新增产品分类
export const addProductClassify = (data = {}) => $post('/cdz-cms/admin/product/classify/add', data)
// 修改产品分类
export const editProductClassify = (data = {}) => $post('/cdz-cms/admin/product/classify/update', data)
export const editProductClassifySort = (data = {}) => $post('/cdz-cms/admin/product/classify/update/sort', data)
// 删除产品分类
export const deleteProductClassify = (id) => $delete(`/cdz-cms/admin/product/classify/delete/${id}`)

export const editProductStatus = (data = {}) => $post('/cdz-cms/admin/product/update/status', data)
export const editProductSort = (data = {}) => $post('/cdz-cms/admin/product/update/sort', data)
export const getClassifyProduct = (id) => $get(`/cdz-cms/admin/product/list?classify=${id}`)
