import React from 'react'
import { Typography } from 'antd'

const { Text } = Typography

export default function LocaleTitle ({ name, enName, width }) {
  return (
    <>
      <Text style={{ width: `${width}px` }} ellipsis={{ tooltip: true }}>{name}</Text>
      {enName && (
        <>
          <br/>
          <Text style={{ width: `${width}px` }} type="secondary" ellipsis={{ tooltip: true }}>{enName}</Text>
        </>
      )}
    </>
  )
}
