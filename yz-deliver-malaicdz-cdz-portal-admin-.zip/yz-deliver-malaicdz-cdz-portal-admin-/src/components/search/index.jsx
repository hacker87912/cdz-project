import React, { useRef, useState } from 'react'
import './index.scss'

const Search = (props) => {
  const [key, setKey] = useState('')
  const textInput = useRef()
  const handleInput = (e) => {
    const val = e.target.value
    setKey(val)
  }
  return (
    <div className='search'>
      <form>
        <input ref={textInput} className='search-input' placeholder='' value={key} onInput={handleInput} />
      </form>
    </div>
  )
}

export default Search
