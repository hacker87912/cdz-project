import '@wangeditor/editor/dist/css/style.css'

import React, { useState, useEffect } from 'react'
import { Editor, Toolbar } from '@wangeditor/editor-for-react'
import { useTranslation } from 'react-i18next'
import { i18nChangeLanguage } from '@wangeditor/editor'
import { useStore } from '@/store'
import * as API from '@/services/home'
import { $put } from '@/utils/request'
import { message } from 'antd'

function MyEditor ({ value, onChange }) {
  const { global } = useStore()
  const { t } = useTranslation()
  // editor 实例
  const [editor, setEditor] = useState(null)

  useEffect(() => {
    i18nChangeLanguage(global.locale === 'zh' ? 'zh-CN' : 'en')
  }, [global.locale])

  // 工具栏配置
  const toolbarConfig = { }

  // 编辑器配置
  const editorConfig = {
    placeholder: t('请输入内容...'),
    MENU_CONF: {}
  }

  const customRequest = async (file) => {
    // 获取密钥
    const res = await API.uploadImgSecret({ filenameExtension: `.${file.name.split('.').pop()}` })
    const { credentials, fileInformation } = res.data || {}
    // 计算签名
    const signature = window.CosAuth({
      SecretId: credentials.tmpSecretId,
      SecretKey: credentials.tmpSecretKey,
      Method: 'PUT',
      Pathname: fileInformation.filePath,
    })
    // url encode
    var camSafeUrlEncode = function (str) {
      return encodeURIComponent(str)
        .replace(/!/g, '%21')
        .replace(/'/g, '%27')
        .replace(/\(/g, '%28')
        .replace(/\)/g, '%29')
        .replace(/\*/g, '%2A')
    }
    // 上传文件到腾讯云
    var prefix = 'https://' + fileInformation.bucket + '.cos.' + fileInformation.region + '.myqcloud.com'
    var url = prefix + camSafeUrlEncode(fileInformation.filePath).replace(/%2F/g, '/')
    const uploadRes = await $put(url, file, { headers: { 'Authorization': signature, 'x-cos-security-token': credentials.sessionToken } })
    if (uploadRes.status === 200 && uploadRes.headers?.etag) {
      return url
    } else {
      message.error(uploadRes.msg || t('上传失败'))
      return ''
    }
  }

  //上传图片
  editorConfig.MENU_CONF['uploadImage'] = {
    // 自定义上传
    async customUpload (file, insertFn) {
      const url = await customRequest(file)
      insertFn(url)
    },
  }

  // 及时销毁 editor ，重要！
  useEffect(() => {
    return () => {
      if (editor == null) return
      editor.destroy()
      setEditor(null)
    }
  }, [editor])

  return (
    <>
      <div style={{ border: '1px solid #ccc', zIndex: 100}}>
        <Toolbar
          editor={editor}
          defaultConfig={toolbarConfig}
          mode="default"
          style={{ borderBottom: '1px solid #ccc' }}
        />
        <Editor
          defaultConfig={editorConfig}
          value={value}
          onCreated={setEditor}
          onChange={editor => onChange(editor.getHtml())}
          mode="default"
          style={{ height: '500px', overflowY: 'hidden' }}
        />
      </div>
    </>
  )
}

export default MyEditor
