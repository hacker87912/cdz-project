import React, { useEffect } from 'react'
import html2canvas from 'html2canvas'
import { jsPDF } from 'jspdf'

export default function PDFBox ({ open = false , name = '', children, id = 'pdf' }) {
  useEffect(() => {
    open && html2canvas(document.getElementById(id), {
      background: '#fff',
      dpi: 192, //导出pdf清晰度
      allowTaint: true,
      scale: 2
    }).then((canvas) => {
      const pageData = canvas.toDataURL('image/jpeg', 1.0)
      const contentWidth = canvas.width
      const contentHeight = canvas.height
      //一页pdf显示html页面生成的canvas高度
      const pageHeight = contentWidth / 592.28 * 841.89
      //未生成pdf的html页面高度
      let leftHeight = contentHeight
      //pdf页面偏移
      let position = 0
      //html页面生成的canvas在pdf中图片的宽高（a4纸的尺寸[595.28,841.89]）
      const imgWidth = 595.28
      const imgHeight = 592.28 / contentWidth * contentHeight
      const PDF = new jsPDF('', 'pt', 'a4')
      //有两个高度需要区分，一个是html页面的实际高度，和生成pdf的页面高度(841.89)
      //当内容未超过pdf一页显示的范围，无需分页
      if (leftHeight < pageHeight) {
        PDF.addImage(pageData, 'JPEG', 0, 0, imgWidth, imgHeight)
      } else {
        while (leftHeight > 0) {
          PDF.addImage(pageData, 'JPEG', 0, position, imgWidth, imgHeight)
          leftHeight -= pageHeight
          position -= 841.89
          //避免添加空白页
          if (leftHeight > 0) {
            PDF.addPage()
          }
        }
      }
      PDF.save(`${name}.pdf`)
    })
  }, [open, name])
  return (
    <div id={id} style={{ padding: '24px' }}>
      {children}
    </div>
  )
}
