import React from 'react'
import { Space, Typography, Row, Descriptions } from 'antd'
import PDFBox from '.'

const { Title, Text } = Typography

export default function BillTemplate ({ ...rest }) {
  return (
    <PDFBox {...rest}>
      <Space
        direction="vertical"
        size="middle"
        style={{
          display: 'flex',
        }}
      >
        <Row justify='end'><Text>2023年1月</Text></Row>
        <Row justify='center'><Title>电子账单 2023</Title></Row>
        <Text>感谢您选用XXXX，本信函是您使用XXXX服务的电子账单通知。有关您的账单明细，请登录官网 费用中心查看明细:</Text>
        <Space
          direction="vertical"
          size="small"
          style={{
            display: 'flex',
          }}
        >
          <Text strong>客户信息</Text>
          <Descriptions column={1} labelStyle={{ color: 'rgba(0, 0, 0, 0.88)', minWidth: '100px' }}>
            <Descriptions.Item label="客户名称">客户名称</Descriptions.Item>
          </Descriptions>
        </Space>
      </Space>
    </PDFBox>
  )
}
