import React from 'react'
import { ArrowLeftOutlined } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import styles from './index.module.scss'

export default function ContentTitle ({ children, showBack = false, title = '', path }) {
  const navigate = useNavigate()
  return (
    <div className={styles['title']}>
      {showBack ? <ArrowLeftOutlined className={styles['back-icon']} onClick={() => (path ? navigate(path) : navigate(-1))} /> : <i></i>}
      <span>{title}</span>
      {children}
    </div>
  )
}
