// import { createBrowserRouter, createRoutesFromElements, RouterProvider, Route } from 'react-router-dom'

export default [
  {
    path: '/',
    title: 'cdz运营管理系统',
    element: () => import('@/pages/layout'),
    meta: {
      requiresAuth: false,
      menuCode: ''
    },
    children: [
      {
        path: 'customer/list',
        title: '客户列表',
        element: () => import('@/pages/customer'),
        meta: {
          requiresAuth: true,
          menuCode: 'ACCOUNT_LIST'
        },
        children: []
      },
      {
        path: 'cms/home',
        title: '首页发布',
        element: () => import('@/pages/home'),
        meta: {
          requiresAuth: true,
          menuCode: 'FIRST_RELEASE'
        },
        children: []
      },
      {
        path: 'cms/topNav',
        title: '顶部导航',
        element: () => import('@/pages/topNav'),
        meta: {
          requiresAuth: true,
          menuCode: 'TOP_NAVIGATION'
        },
        children: []
      },
      {
        path: 'cms/topNav/classify',
        title: '菜单分类',
        element: () => import('@/pages/topNav/classify'),
        meta: {
          requiresAuth: true,
          menuCode: 'TOP_NAVIGATION'
        },
        children: []
      },
      {
        path: 'cms/topNav/entry',
        title: '导航入口',
        element: () => import('@/pages/topNav/entry'),
        meta: {
          requiresAuth: true,
          menuCode: 'TOP_NAVIGATION'
        },
        children: []
      },
      {
        path: 'expense/dashboard',
        title: '费用概览',
        element: () => import('@/pages/expense/dashboard'),
        meta: {
          requiresAuth: true,
          menuCode: 'HOME_OVERVIEW'
        },
        children: []
      },
      {
        path: 'expense/dashboard/detail',
        title: '月度汇总账单详情',
        element: () => import('@/pages/expense/dashboard/detail'),
        meta: {
          requiresAuth: true,
          menuCode: 'HOME_OVERVIEW'
        },
        children: []
      },
      {
        path: 'expense/bill',
        title: '账单列表',
        element: () => import('@/pages/expense/bill'),
        meta: {
          requiresAuth: true,
          menuCode: 'BILL_LIST'
        },
        children: []
      },
      {
        path: 'expense/bill/billDetail',
        title: '账单详情',
        element: () => import('@/pages/expense/bill/billDetail'),
        meta: {
          requiresAuth: true,
          menuCode: 'BILL_LIST'
        },
        children: []
      },
      {
        path: 'expense/bill/resourceBillDetail',
        title: '资源账单详情',
        element: () => import('@/pages/expense/bill/resourceBillDetail'),
        meta: {
          requiresAuth: true,
          menuCode: 'BILL_LIST'
        },
        children: []
      },
      {
        path: 'expense/order',
        title: '订单列表',
        element: () => import('@/pages/expense/order'),
        meta: {
          requiresAuth: true,
          menuCode: 'ORDER_LIST'
        },
        children: []
      },
      {
        path: 'expense/order/detail',
        title: '订单详情',
        element: () => import('@/pages/expense/order/detail'),
        meta: {
          requiresAuth: true,
          menuCode: 'ORDER_LIST'
        },
        children: []
      },
      {
        path: 'expense/tariff',
        title: '资费包设置',
        element: () => import('@/pages/expense/tariff'),
        meta: {
          requiresAuth: true,
          menuCode: 'EXPENSE_SETTING'
        },
        children: []
      },
      {
        path: 'cms/bottomnav',
        title: '底部导航',
        element: () => import('@/pages/bottomNav'),
        meta: {
          requiresAuth: true,
          menuCode: 'BOTTOM_NAVIGATION'
        },
        children: []
      },
      {
        path: 'cms/bottomnav/classify',
        title: '底部菜单分类',
        element: () => import('@/pages/bottomNav/classify'),
        meta: {
          requiresAuth: true,
          menuCode: 'BOTTOM_NAVIGATION'
        },
        children: []
      },
      {
        path: 'cms/document',
        title: '条款政策版本维护',
        element: () => import('@/pages/documents'),
        meta: {
          requiresAuth: true,
          menuCode: 'TERMS'
        },
        children: []
      },
      {
        path: 'logs/list',
        title: '日志列表',
        element: () => import('@/pages/record'),
        meta: {
          requiresAuth: true,
          menuCode: 'LOG_LIST'
        },
        children: []
      },
      {
        path: 'cms/product',
        title: '产品发布',
        element: () => import('@/pages/product'),
        meta: {
          requiresAuth: true,
          menuCode: 'PRODUCT_RELEASE'
        },
        children: []
      },
      {
        path: 'cms/product/classify',
        title: '产品分类',
        element: () => import('@/pages/product/classify'),
        meta: {
          requiresAuth: true,
          menuCode: 'PRODUCT_RELEASE'
        },
        children: []
      },
      {
        path: 'cms/price',
        title: '定价发布',
        element: () => import('@/pages/price'),
        meta: {
          requiresAuth: true,
          menuCode: 'PRICING_RELEASE'
        },
        children: []
      },
      {
        path: 'account/manage',
        title: '账号管理',
        element: () => import('@/pages/account'),
        meta: {
          requiresAuth: true,
          menuCode: 'ADMIN_USER'
        },
        children: []
      },
      {
        path: 'account/role',
        title: '角色管理',
        element: () => import('@/pages/role'),
        meta: {
          requiresAuth: true,
          menuCode: 'ADMIN_ROLE'
        },
        children: []
      },
      {
        path: 'message/mail',
        title: '站内信',
        element: () => import('@/pages/messages/mail'),
        meta: {
          requiresAuth: true,
          menuCode: 'STATION_MSG'
        },
        children: []
      },
      {
        path: 'message/notify',
        title: '通知公告',
        element: () => import('@/pages/messages/notify'),
        meta: {
          requiresAuth: true,
          menuCode: 'NOTIFICATION'
        },
        children: []
      },
      {
        path: 'message/notify/detail/:id',
        title: '通知公告详情',
        element: () => import('@/pages/messages/notify/detail'),
        meta: {
          requiresAuth: true,
          menuCode: 'NOTIFICATION'
        },
        children: []
      },
      {
        path: 'record/list',
        title: '联系记录',
        element: () => import('@/pages/relation'),
        meta: {
          requiresAuth: true,
          menuCode: 'CONTACT_RECORD'
        },
        children: []
      }
    ]
  },
  {
    path: 'login',
    title: '登录',
    element: () => import('@/pages/login'),
    meta: {
      requiresAuth: false,
      menuCode: ''
    },
    children: []
  }
]
