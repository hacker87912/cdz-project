import React from 'react'
import {
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
  Route,
  useRouteError,
  redirect,
  isRouteErrorResponse
} from 'react-router-dom'
import routeData from './config'
import { Spin, Result } from 'antd'
import loadable from '@loadable/component'
import { getItem, clearAll } from '@/utils/storage'
import i18next from 'i18next'

const routesRender = (routesConfig = []) => {
  return routesConfig.map(({ path = '', title = '', children = [], element = null, meta = {} }) => {
    const LoadableComponent = loadable(element, {
      fallback: <Spin style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }} color='primary' />
    })
    const loader = () => {
      document.title = i18next.t(title) || 'cdz-portal-admin'
      // 登录验证
      if (path !== 'login' && !getItem('Authorization')) {
        clearAll()
        return redirect('/login')
      }
      // 权限验证
      const { requiresAuth, menuCode } = meta
      const menuAccess = getItem('menuAccess') || []
      if (requiresAuth && !menuAccess.includes(menuCode)) {
        throw new Response('not authorized', { status: 403 })
      }
      return null
    }
    return (
      <Route
        key={path}
        path={path}
        element={<LoadableComponent />}
        errorElement={<ErrorBoundary />}
        loader={loader}
      >
        {children.length > 0 && routesRender(children)}
      </Route>
    )
  })
}
const ErrorBoundary = () => {
  const error = useRouteError()
  if (isRouteErrorResponse(error)) {
    if (error.status === 404) {
      return (
        <Result
          status='404'
          title='404'
          subTitle='Sorry, the page you visited does not exist.'
        />
      )
    }
    if (error.status === 403) {
      return (
        <Result
          status='403'
          title='403'
          subTitle='Sorry, you are not authorized to access this page.'
        />
      )
    }
  }
  return (
    <Result
      status='error'
      title='Something went wrong'
    />
  )
}
export const router = createBrowserRouter(
  createRoutesFromElements(routesRender(routeData)),
  { basename: import.meta.env.VITE_PUBLIC_PATH }
)
const AppRoute = () => <RouterProvider router={router} />

export default AppRoute
