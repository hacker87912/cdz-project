import React from 'react'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/store'
import AppRoute from '@/router'
import './App.css'
import { ConfigProvider } from 'antd'
import enUS from 'antd/locale/en_US'
import zhCN from 'antd/locale/zh_CN'
import 'dayjs/locale/zh-cn'

export default observer(() => {
  const { global } = useStore()
  const locale = global.locale === 'zh' ? zhCN : enUS
  return (
    <ConfigProvider locale={locale}>
      <AppRoute />
    </ConfigProvider>
  )
})
