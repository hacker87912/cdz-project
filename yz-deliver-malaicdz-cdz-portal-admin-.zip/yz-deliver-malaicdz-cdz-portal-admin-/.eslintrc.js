module.exports = {
  "env": {
    "browser": true,
    "es2021": true
  },
  "extends": [
    "eslint:recommended",
    "plugin:react/recommended"
  ],
  "overrides": [
  ],
  "parserOptions": {
    "ecmaVersion": "latest",
    "sourceType": "module"
  },
  "settings": {
    "react": {
      "version": "detect"
    }
  },
  "plugins": [
    "react"
  ],
  "rules": {
    "no-debugger": 2,
    "no-unused-vars": ["warn"],
    "react/prop-types": 0,
    "react/self-closing-comp": ["error", {
      "component": true,
      "html": false
    }],
    "indent": ["warn", 2],
    "semi": ["warn", "never"],
    "space-before-function-paren": ["warn", "always"],
    "key-spacing": ["warn", { "beforeColon": false, "afterColon": true }],
    "quotes": ["error", "single"]
  }
}
