// 自定义server启动
const dotenv = require('dotenv')
dotenv.config()
dotenv.config({ path: `.env.local`, override: true })
const express = require('express')
const next = require('next')
const { createProxyMiddleware } = require('http-proxy-middleware')
const csrProxy = {
  '/api': {
    target: `${process.env.API_HOST}/`,
    pathRewrite: {
      '^/api': ''
    },
    changeOrigin: true
  }
}
const hostname = process.env.HOST || 'localhost'
const port = parseInt(process.env.PORT, 10) || 3000
const dev = process.env.NODE_ENV !== 'production'
const app = next({ dev, hostname, port })
const handle = app.getRequestHandler()

app.prepare()
  .then(() => {
    const server = express()

    if (csrProxy) {
      Object.keys(csrProxy).forEach(function(context) {
        server.use(createProxyMiddleware(context, csrProxy[context]))
      })
    }
    server.get('/', (req, res) => {
      res.redirect('/home')
    })
    server.all('*', (req, res) => {
      handle(req, res)
    })

    server.listen(port, err => {
      if (err) {
        throw err
      }
      console.log(`> Ready on http://localhost:${port}`)
    })
  })
  .catch(err => {
    console.log('An error occurred, unable to start the server')
    console.log(err)
  })
