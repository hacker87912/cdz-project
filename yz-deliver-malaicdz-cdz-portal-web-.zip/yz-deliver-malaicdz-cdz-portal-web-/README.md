# 项目名称

cdz-portal-web  马来西亚腾讯云门户平台

# 基本功能

页面通过SSR服务端渲染,支持站点SEO
适配移动端, 一套代码全响应
采用国际化路由，支持中文、英文、马来语
# 开发环境

Node.js 14.6.0或更新版本

# 安装依赖
npm install

# 运行项目
npm run dev

# 构建项目（打包）
npm run build

# 项目运行
npm run start

# 项目结构说明

public: 静态服务目录

src: 开发资源目录

server.js： 自定义express服务

next.config.js： next自定义配置

package.json： 项目依赖

README.md：项目说明文档


# src目录详解

* services: 请求接口定义

* assets: 需打包静态资源(图片及文档等)

* components: 公共组件

* store：状态管理配置

* styles: 全局样式及字体

* utils: 自定义工具类

* pages: 页面组件

* pages/_app.js: 自定义应用入口

* pages/_document.js: 自定义文档配置


# 注意事项

1. 页面所有图片请用next/image组件代替原生img标签。

2. 本地开发先配置好next.config.js中env环境变量API_HOST。

3、请按照文件路由规则增加文件目录或子目录，保持项目结构统一简洁。


# 相关文档

react官方文档: https://zh-hans.reactjs.org/

next官方文档: https://nextjs.org/docs/getting-started

mobx官方文档: https://mobx.js.org/README.html

国际化i18n: https://react.i18next.com/

next-i18n: https://github.com/i18next/next-i18next

expressjs: https://github.com/expressjs/express
