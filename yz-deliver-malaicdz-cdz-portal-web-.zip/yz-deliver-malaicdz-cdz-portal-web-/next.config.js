const { i18n } = require('./next-i18next.config.js')
const ESLintPlugin = require('eslint-webpack-plugin')

module.exports = {
  basePath: process.env.NEXT_PUBLIC_PATH,
  i18n,
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'cdz-1259271518.cos.ap-nanjing.myqcloud.com',
        port: '',
        pathname: '/png/**',
      },
      {
        protocol: 'https',
        hostname: 'cdz-1259271518.cos.ap-nanjing.myqcloud.com',
        port: '',
        pathname: '/jpeg/**',
      },
      {
        protocol: 'https',
        hostname: 'cdz-1259271518.cos.ap-nanjing.myqcloud.com',
        port: '',
        pathname: '/jpg/**',
      },
      {
        protocol: 'https',
        hostname: 'cdz-1259271518.cos.ap-nanjing.myqcloud.com',
        port: '',
        pathname: '/bmp/**',
      },
      {
        protocol: 'https',
        hostname: 'staticintl.cloudcachetci.com',
        port: '',
        pathname: '/cms/backend-cms/**',
      },
      {
        protocol: 'https',
        hostname: 'staticintl.cloudcachetci.com',
        port: '',
        pathname: '/yehe/backend-news/**',
      },
    ],
  },

  webpack: (
    config,
    { buildId, dev, isServer, defaultLoaders, nextRuntime, webpack }
  ) => {
    if (dev) {
      config.plugins.push(new ESLintPlugin({
        files: 'src/**/*.{js,jsx}',
        extensions: ['js', 'jsx'],
        exclude: ['/node_modules/', '/\.next/'],
        formatter: require('eslint-friendly-formatter')
      }))
    }
    if (!isServer) {
      config.resolve.fallback = {
        fs: false
      }
    }
    return config
  },
}
