module.exports = {
  i18n: {
    defaultLocale: 'zh',
    locales: ['zh', 'en', 'ms', 'zh-CN', 'en-US', 'ms-MY'],
  },
  fallbackLng: {
    default: ['zh'],
    'zh-CN': ['zh'],
    'en-US': ['en'],
    'ms-MY': ['ms'],
  },
  // localePath:
  //   typeof window === 'undefined'
  //     ? require('path').resolve('./my-custom/path')
  //     : '/public/my-custom/path',
}
