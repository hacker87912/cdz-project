import React, { Fragment, useRef, useEffect, useState } from "react"
import { BasicPie } from "tea-chart/lib/basicpie"
import { Annotation } from "tea-chart/lib/annotation"

export default function BasicPieBox ({ ...rest }) {
  const chartRef = useRef(null)
  const [label, setLabel] = useState({
    title: "公网IP",
    valueText: "291",
  })
  const data = [
    { type: "公网IP", value: 291 },
    { type: "云服务器CVM", value: 302 },
    { type: "云硬盘CBS", value: 82 },
  ]

  useEffect(() => {
    chartRef.current.on("interaction.hover", meta => {
      const [{ title, valueText }] = meta
      setLabel({ title, valueText })
    })
  }, [])

  const formatter = (label, index, e, values) => {
    console.log(label, index, e, values)
    return label + '\xa0\xa0\xa0\xa0\xa0' + '0.49美元（58.80%）'
  }

  return (
    <Fragment>
      <BasicPie
        circle
        legend={{ align: 'right', formatter }}
        interaction={["element-hover"]}
        height={350}
        dataSource={data}
        position="value"
        color="type"
        chartRef={ref => {
          chartRef.current = ref
        }}
        {...rest}
      >
        {label && (
          <Annotation>
            <Annotation.Label
              content={label.title}
              position={["50%", "50%"]}
              offsetY={-10}
              textStyle="font-size:16px;font-weight:600;"
            />
            <Annotation.Label
              content={label.valueText}
              position={["50%", "50%"]}
              offsetX={-10}
              offsetY={35}
              textStyle="font-size:16px;color:red;"
            />
            <Annotation.Label
              content="台"
              position={["50%", "50%"]}
              offsetX={20}
              offsetY={35}
              textStyle="font-size:16px;"
            />
          </Annotation>
        )}
      </BasicPie>
    </Fragment>
  )
}
