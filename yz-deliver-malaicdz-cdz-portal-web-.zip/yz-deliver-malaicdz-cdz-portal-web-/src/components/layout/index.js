import Header from '@/components/header'
import Footer from '@/components/footer'
import styles from './index.module.scss'
import Head from 'next/head'

const PageLayout = function (props) {

  return (
    <div className={styles['page-layout']}>
      <Head>
        <title>{props.title}</title>
      </Head>
      <div className={styles['page-header']}>
        <Header />
      </div>
      <div className={styles['page-content']}>
        {props.children}
      </div>
      <div className={styles['page-footer']}>
        <Footer />
      </div>
    </div>
  )
}

export default PageLayout
