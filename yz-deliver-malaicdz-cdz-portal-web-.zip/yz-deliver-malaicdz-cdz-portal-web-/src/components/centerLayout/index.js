import { Menu, Layout, NavMenu, Icon, Badge, Avatar, List, Row, Col, Select, Button, Text } from "tea-component"
import { GlobalOutlined } from '@ant-design/icons'
import Head from 'next/head'
import Link from 'next/link'
import Image from 'next/image'
import Logo from '@/assets/img/logo.svg'
import { useRouter } from 'next/router'
import styles from './index.module.scss'
import { useMemo, useEffect, useState } from "react"
import * as API from '@/services'
import { getCookie, clearAllCookie } from '@/utils/storage'
import { useTranslation } from 'next-i18next'
import Drawer from '@/components/drawer'

const { Header, Body, Sider, Content: LayoutContent } = Layout

const globalNames = [{ name: 'English', lang: 'en' }, { name: '简体中文', lang: 'zh'}]

function LoginBox ({ href, t, close, username, loginAccount }) {
  const router = useRouter()
  const exitClick = async () => {
    const res = await API.logout()
    if (res.code === 0) {
      clearAllCookie()
      const localePath = router.locale === 'en' ? 'en' : ''
      window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/home`
    }
    close()
  }
  const userClick = async () => {
    router.push('/account/user')
    close()
  }
  const expenseClick = async () => {
    router.push('/expense/bill/overview')
    close()
  }
  const messageClick = async () => {
    router.push('/messagecenter/stationmessage')
    close()
  }
  return (
    <>
      <h1 style={{ color: '#fff', padding: '0 20px' }}>{username}</h1>
      <h4 style={{ color: '#fff', whiteSpace: 'nowrap', marginBottom: '10px', padding: '0 20px' }}>{loginAccount}</h4>
      <List type="option">
        <List.Item onClick={userClick}>{t('账号信息')}</List.Item>
        <List.Item onClick={expenseClick}>{t('费用中心')}</List.Item>
        <List.Item className="tea-nav__list-line" onClick={messageClick}>{t('未读消息')}</List.Item>
        <List.Item onClick={exitClick}>{t('退出登录')}</List.Item>
      </List>
    </>
  )
}

function HeaderNav () {
  const { t } = useTranslation('common')
  const { asPath, locale = 'zh', push } = useRouter()
  const [href, setHref] = useState('')
  const [username, setUsername] = useState('')
  const [loginAccount, setLoginAccount] = useState('')
  const [visible, setVisible] = useState(false)
  const [msgState, setMsgState] = useState('0')
  const [msg, setMsg] = useState('0')
  const [msgData, setMsgData] = useState([])

  const localePath = locale === 'zh' ? '' : `/${locale}`
  const globalClick = (lang = 'zh', close) => {
    const langPath = lang === 'zh' ? '' : `/${lang}`
    window.location.href = window.location.href.replace(`${localePath}${asPath}`, `${langPath}${asPath}`)
    close()
  }

  const gotoHome = () => {
    const localePath = locale === 'en' ? 'en/' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}home`
  }

  useEffect(() => {
    setHref(window.location.href)
    const username = decodeURIComponent(getCookie('accountName'))
    const loginAccount = decodeURIComponent(getCookie('loginAccount'))
    setUsername(username)
    setLoginAccount(loginAccount)
  }, [])

  const msgClick = async () => {
    const res = await API.getNotificationList({ current: 1, size: 20, key: '' })
    const { data: { records = [] } = {} } = res
    setMsgData(records)
    setVisible(true)
  }

  const consoleClick = async () => {
    const res = await API.getConsole()
    if (res.code === 0) {
      window.open(res.data || '', '_blank')
    }
  }

  const documentClick = () => {
    if (locale === 'zh') {
      window.open('https://www.tencentcloud.com/zh/document/product', '_blank')
    } else if (locale === 'en') {
      window.open('https://www.tencentcloud.com/document/product?lang=en', '_blank')
    }
  }

  return (
    <NavMenu
      className={styles['nav-menu']}
      left={
        <>
          <NavMenu.Item type="logo" onClick={gotoHome}>
            <div className={styles['logo']}><Image src={Logo} fill alt="logo" /></div>
            <span style={{ paddingLeft: '5px' }}>CDZ Cloud</span>
          </NavMenu.Item>
        </>
      }
      right={
        <>
          <NavMenu.Item
            type="dropdown"
            overlay={close => (
              <Menu theme="dark"  style={{ backgroundColor: '#191919', width: '140px' }}>
                {globalNames.map(e => <Menu.Item key={e.lang} title={e.name} onClick={() => globalClick(e.lang, close)} />)}
              </Menu>
            )}
            className='nav-dropdown-fiy'
          >
            <GlobalOutlined />
          </NavMenu.Item>
          <NavMenu.Item type='icon' className='nav-info' onClick={msgClick}>
            <Icon type="email" />
            <Badge dark theme="danger">
              7
            </Badge>
          </NavMenu.Item>
          <NavMenu.Item><Link href='/expense/bill/overview'>{t('费用')}</Link></NavMenu.Item>
          <NavMenu.Item><a onClick={consoleClick}>{t('控制台')}</a></NavMenu.Item>
          <NavMenu.Item><a onClick={documentClick}>{t('文档')}</a></NavMenu.Item>
          <NavMenu.Item
            type="dropdown"
            className='nav-dropdown-fiy nav-user'
            overlay={close => (
              <LoginBox username={username} loginAccount={loginAccount} href={href} t={t} close={close} />
            )}
          >
            <Avatar color={Avatar.Color.Blue} text={username.slice(0, 1)} />
          </NavMenu.Item>
          <Drawer
            title={t('消息通知')}
            visible={visible}
            setVisible={setVisible}
            extraPath="/messagecenter/stationmessage"
            extraText={t('查看更多')}
          >
            <Row>
              <Col span={7}>
                <Select
                  appearance="button"
                  options={[
                    // { value: "0", text: "全部" },
                    // { value: "1", text: "已读" },
                    // { value: "2", text: "未读" },
                  ]}
                  value={msgState}
                  onChange={value => setMsgState(value)}
                  style={{ width: '80px' }}
                />
              </Col>
              <Col span={7}>
                <Select
                  appearance="button"
                  options={[
                    // { value: "0", text: "全部" },
                    // { value: "1", text: "站内信" },
                    // { value: "2", text: "通知公告" },
                  ]}
                  value={msg}
                  onChange={value => setMsg(value)}
                  style={{ width: '80px' }}
                />
              </Col>
              <Col span={10}>
                {/* <Button type="weak">
                  全部设为已读
                </Button> */}
              </Col>
            </Row>
            <List split="divide" style={{ marginTop: '10px' }}>
              {msgData.map(e => (
                <List.Item key={e.id} style={{ paddingBottom: '20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Text theme="text" style={{ fontSize: '12px' }}>{e.title}</Text>
                    <Link href={`/messagecenter/notice/detail/${e.id}`}><Text theme="primary" style={{ fontSize: '12px' }}>{t('通知公告')}</Text></Link>
                  </div>
                  <div><Text theme="label" style={{ fontSize: '12px' }}>{e.releaseTime}</Text></div>
                </List.Item>
              ))}
            </List>
          </Drawer>
        </>
      }
    />
  )
}

function CenterLayout ({ children, title = '', headTitle = '', menus = [], subtitle = <></>, isContentHeader = true}) {
  const { pathname, back } = useRouter()
  const menu = (data) => {
    return data.map(e => {
      if (e.children && e.children.length) {
        return <Menu.SubMenu key={e.key} title={e.label}>{menu(e.children)}</Menu.SubMenu>
      }
      return <Menu.Item
        key={e.key}
        title={e.label}
        selected={pathname === e.key || (pathname.startsWith(e.key) && /]$/.test(pathname))}
        render={children => <Link href={e.key}>{children}</Link>}
      />
    })
  }
  const menusArr = useMemo(() => {
    const _menusArr = []
    const loop = (data, arr) => {
      data.forEach(item => {
        arr.push(item.key)
        if (item.children && item.children.length) loop(item.children, arr)
      })
    }
    loop(menus, _menusArr)
    return _menusArr
  }, [menus])
  return (
    <>
      <Head>
        <title>{headTitle}</title>
      </Head>
      <Layout>
        <Header>
          <HeaderNav />
        </Header>
        <Body>
          <Sider>
            <Menu theme="dark" title={title}>
              {menu(menus)}
            </Menu>
          </Sider>
          <LayoutContent>
            {isContentHeader && (
              <LayoutContent.Header
                title={headTitle}
                showBackButton={!menusArr.includes(pathname)}
                onBackButtonClick={() => back()}
                subtitle={subtitle}
              />
            )}
            <div>
              {children}
            </div>
          </LayoutContent>
        </Body>
      </Layout>
    </>
  )
}
export default CenterLayout
