import { Col, Row, Text } from 'tea-component'

export function Line ({ marginTop = '24px', marginBottom = '24px'}) {
  return (
    <div style={{ borderTop: '1px solid #cfd5de', marginTop, marginBottom }}></div>
  )
}

export function ShowInfo ({ info }) {
  const data = Object.entries(info)
  return (
    <Row >
      {data.map(e => {
        const [key, value] = e
        return (
          <Col span={12} key={key}>
            <Text theme="label" style={{ minWidth: '70px', display: 'inline-block' }}>{key}</Text>
            <Text theme="strong" style={{ marginLeft: '10px' }}>{value}</Text>
          </Col>
        )
      })}
    </Row>
  )
}

export function SpaceBetweenBox ({ children, boxTop = 0, marginRight = '10px', marginTop = '10px', vertical, boxBottom = 0 }) {
  if (!children) return <></>
  return (
    <>
      <div className='space-between-box'>
        {children.length > 0 ? children.map((e, i) => (
          <div key={`box-${i}`} className='node-box'>{e}</div>
        )) : <div>{children}</div>}
      </div>
      <style jsx>{`
        .space-between-box {
          display: flex;
          flex-direction: ${vertical ? 'column': 'initial'};
          margin-top: ${boxTop};
          margin-bottom: ${boxBottom};
        }
        .node-box {
          display: ${vertical ? 'initial' : 'flex'};
          align-items: ${vertical ? 'initial' : 'center'};
        }
        .space-between-box > .node-box:not(:last-child) {
          margin-right: ${vertical ? 'initial' : marginRight};
        }
        .space-between-box > .node-box:not(:first-child) {
          margin-top: ${vertical ? marginTop : 'initial'};
        }
      `}</style>
      <style jsx>
        {`
          .space-between-box :global(.tea-search) {
            width: 100%;
          }
        `}
      </style>
    </>
  )
}
