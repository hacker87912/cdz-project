import Link from "next/link"
import React from "react"
import { Drawer, Text } from "tea-component"

export default function DrawerBox ({ title, visible, setVisible, extraPath, extraText, footer = <></>, children }) {
  return (
    <>
      <Drawer
        size='m'
        placement='right'
        disableAnimation={false}
        outerClickClosable={true}
        showMask={false}
        visible={visible}
        title={title}
        extra={<Link href={extraPath} style={{ fontSize: '14px', marginRight: '5px' }}><Text theme="primary">{extraText}</Text></Link>}
        footer={footer}
        onClose={() => setVisible(false)}
      >
        {children}
      </Drawer>
    </>
  )
}
