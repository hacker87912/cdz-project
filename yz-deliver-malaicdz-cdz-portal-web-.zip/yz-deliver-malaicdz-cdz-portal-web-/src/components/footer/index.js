import React from 'react'
import styles from './index.module.scss'
import { useTranslation } from 'next-i18next'
import { Space, Row, Col } from 'antd'
import { useStore } from '@/store'
import { useRouter } from 'next/router'
import MobileList from '../header/components/mobileList'
import { isURL } from '@/utils/regExp'

const PageFooter = function () {
  const { t } = useTranslation('common')
  const { global: { version } } = useStore()
  const { pathname, locale } = useRouter()

  const link = (pathname) => {
    if (isURL(pathname)) {
      window.location.href = pathname
      return
    }
    const localePath = locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}${pathname}`
  }

  return (
    <footer className={styles['footer']}>
      {!(pathname === '/login' || pathname === '/password' || pathname === '/reset') && (
        <>
          <MobileNavigation />
          <PcNavigation link={link} />
        </>
      )}
      <Space size='large' className={styles['link']}>
        <a onClick={() => link('/clause/service')}>{t("服务条款")}</a>
        <a onClick={() => link('/clause/policy')}>{t("隐私政策")}</a>
      </Space>
      <p className={styles['copyright']}>{version}</p>
    </footer>
  )
}

const MobileNavigation = () => {
  const { global } = useStore()
  return (
    <MobileList className="footer-nav-m" open={true} list={global.footNavData} />
  )
}

const PcNavigation = ({ link }) => {
  const { global } = useStore()
  return <Row className={styles['pc-navigation']} justify="center" align="top">{
    <div>
      {
        global.footNavData.map((item, i) => {
          return <Col className={styles['col']} key={i}>
            <div className={styles['title']}>{item.name}</div>
            {
              item.children.map((subItem, j) => {
                return <a key={j} onClick={() => link(subItem.url)}>{subItem.name}</a>
              })
            }
          </Col>
        })
      }
    </div>
  }</Row>
}

export default PageFooter
