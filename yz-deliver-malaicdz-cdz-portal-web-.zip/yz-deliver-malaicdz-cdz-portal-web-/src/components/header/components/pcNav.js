import { useState, useEffect, useRef } from 'react'
import { DownOutlined, UpOutlined } from '@ant-design/icons'
import Panel from './panel'
import Image from 'next/image'
import Logo from '@/assets/img/logo.svg'
import NavRight from '@/components/header/components/navRight'
import { useStore } from '@/store'
import { useRouter } from 'next/router'
import styles from '../index.module.scss'
import { observer } from 'mobx-react-lite'

function PCNav () {
  const { pathname, locale } = useRouter()
  const { global: { copyHeaderData, headerData, setCopyHeaderData } } = useStore()
  const [show, setShow] = useState(true)
  const boxRef = useRef(null)
  const valueRef = useRef(null)
  const boxDom = useRef(null)

  useEffect(() => {
    if (pathname === '/login' || pathname === '/password' || pathname === '/reset') {
      setShow(false)
    }
  }, [pathname])

  const strokeStyle = (down, up, color) => {
    down.style.stroke = color
    down.style.strokeWidth = 25
    up.style.stroke = color
    up.style.strokeWidth = 25
  }

  const moveState = (el) => {
    let isMove = false, timer = null
    el.addEventListener("mousemove", () => {
      isMove = true
      clearTimeout(timer)
      timer = setTimeout(() => {
        isMove = false
      }, 180)
    })
    return () => isMove
  }

  useEffect(() => {
    let timerSpan = null
    let timerItem = null
    let flag = false
    const navDom = document.querySelectorAll('.nav-title-delay')
    const box = document.querySelector('#display-box')
    const ul = document.querySelector('#nav-list-box')
    const mouse = moveState(ul)
    navDom.forEach(item => {
      const [span, panel] = item.children
      const [down, up] = span.children
      item.addEventListener("mouseleave", () => {
        clearTimeout(timerItem)
        timerSpan = setTimeout(() => {
          panel.style.display = 'none'
          up.style.display = 'none'
          up.style.color = '#fff'
          down.style.display = 'inline-block'
          down.style.color = '#fff'
          span.style.color = '#fff'
          span.style.borderBottom = 'none'
          if (mouse()) {
            box.style.display = 'block'
          } else {
            box.style.display = 'none'
          }
          strokeStyle(down, up, '#fff')
          flag = false
        }, 200)
      })
      panel.addEventListener("mouseleave", () => {
        setTimeout(() => {
          if (!flag) {
            panel.style.display = 'none'
            box.style.display = 'none'
          }
        }, 200)
      })
      panel.addEventListener("mouseenter", () => {
        clearTimeout(timerSpan)
        panel.style.display = 'block'
      })
      box.addEventListener("mouseenter", () => {
        if (box.style.display !== panel.style.display) {
          box.style.display = 'none'
        }
      })
      item.addEventListener("mouseenter", () => {
        timerItem = setTimeout(() => {
          box.style.display = 'block'
          panel.style.display = 'block'
          up.style.display = 'inline-block'
          up.style.color = '#378EFF'
          down.style.display = 'none'
          down.style.color = '#378EFF'
          span.style.color = '#378EFF'
          span.style.borderBottom = '2px solid #378EFF'
          strokeStyle(down, up, '#378EFF')
          if (boxRef.current) {
            setCopyHeaderData(headerData)
            boxRef.current = false
            valueRef.current = true
          }
          flag = true
        }, 200)
      })
    })
  }, [headerData])

  const gotoHome = () => {
    const localePath = locale === 'en' ? 'en/' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}home`
  }
  return (
    <>
      <div className={styles['logo']}>
        <a onClick={gotoHome}>
          <>
            <div><Image src={Logo} fill alt="logo" /></div>
            <span>CDZ Cloud</span>
          </>
        </a>
      </div>
      {show && (
        <ul className={styles['nav-list']} id='nav-list-box'>
          {copyHeaderData.pcData?.map(e => {
            const { title, panelData } = e
            return (
              <li key={e.id} className="nav-title-delay">
                <span>{title}
                  <DownOutlined className={styles['down-out-lined']} />
                  <UpOutlined className={styles['up-out-lined']} />
                </span>
                {<Panel data={panelData} boxRef={boxRef} valueRef={valueRef} boxDom={boxDom} />}
              </li>
            )
          })}
          <div ref={boxDom} className={styles['display-box']} id="display-box"></div>
        </ul>
      )}
      <div style={{ flex: 'auto' }}></div>
      <div className={styles['header-right']}>
        <NavRight show={show} />
      </div>
    </>
  )
}
export default observer(PCNav)
