import { useState, useEffect } from 'react'
import { SearchOutlined, CloseOutlined } from '@ant-design/icons'
import { useTranslation } from 'next-i18next'
import styles from '../index.module.scss'
import Link from 'next/link'

export function Search ({ setSearchOpen = () => {}, searchOpen, list, value, onChange, onKeyDown }) {
  const { t } = useTranslation('common')
  return (
    <div className={styles['pc-nav-search']}>
      <input placeholder={t('请输入关键字')} value={value} onChange={(e) => onChange(e.target.value)} onKeyDown={onKeyDown} onBlur={() => setSearchOpen(false)} />
      <CloseOutlined className={styles['nav-search-icon']} onClick={() => setSearchOpen(false)} />
      {searchOpen && list?.length > 0 && (
        <div className={styles['pc-nav-search-ul-box']}>
          <ul>
            {list?.map(e => (<li key={e.id}>
              <Link href={`/product/${e.id}`}>{e.title}</Link>
            </li>))}
          </ul>
        </div>
      )}
    </div>
  )
}

function Input ({ onSearch, onKeyDown, valueRef }) {
  const [value, setValue] = useState('')

  useEffect(() => {
    setValue('')
    valueRef.current = false
  }, [valueRef.current])
  return (
    <div className={styles['pc-input-box']}>
      <input type="text" value={value} onChange={(e) => setValue(e.target.value)} onKeyDown={onKeyDown} />
      <div className={styles['search-icon']}><SearchOutlined onClick={() => onSearch(value)} /></div>
    </div>
  )
}
export default Input
