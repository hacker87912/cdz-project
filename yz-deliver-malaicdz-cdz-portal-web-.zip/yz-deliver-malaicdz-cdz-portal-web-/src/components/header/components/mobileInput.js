import { SearchOutlined } from '@ant-design/icons'
import { useTranslation } from 'next-i18next'
import styles from './mobile.module.scss'
import Link from 'next/link'

function Input (props) {
  const { t } = useTranslation('common')
  console.log(props.searchData)
  const data = props.searchData
  return (
    <div className={styles['mobile-input-box']}>
      <div className={styles['mobile-input']}>
        <input
          type="text"
          value={props.searchValue}
          onChange={(e) => props.setSearchValue(e.target.value)}
          placeholder={t('请输入关键字')}
          onKeyDown={props.onKeyDown}
        />
        <div className={styles['search-icon']}><SearchOutlined /></div>
      </div>
      {data.length > 0 && (
        <ul>
          {data.map(e => (<li key={e.id}>
            <Link href={`/product/${e.id}`}>{e.title}</Link>
          </li>))}
        </ul>
      )}
    </div>
  )
}
export default Input
