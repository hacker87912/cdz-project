import { useState, useEffect } from 'react'
import Image from 'next/image'
import Logo from '@/assets/img/logo.svg'
import { SearchOutlined, UserOutlined, BarsOutlined, CloseOutlined } from '@ant-design/icons'
import MobileList from './mobileList'
import Link from 'next/link'
import MobileInput from './mobileInput'
import { useStore } from '@/store'
import { useTranslation } from 'next-i18next'
import styles from './mobile.module.scss'
import * as API from '@/services'
import { useRouter } from 'next/router'
import { getCookie, clearAllCookie } from '@/utils/storage'

function MobileNav () {
  const { global: { headerData } } = useStore()
  const { t } = useTranslation('common')
  const [menuOpen, setMenuOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchData, setSearchData] = useState([])
  const [searchValue, setSearchValue] = useState('')
  const [loginAccount, setLoginAccount] = useState('')
  const { asPath, locale = 'zh' } = useRouter()
  const localePath = locale === 'zh' ? '' : `/${locale}`

  const globalClick = (lang = 'zh') => {
    const langPath = lang === 'zh' ? '' : `/${lang}`
    window.location.href = window.location.href.replace(`${localePath}${asPath}`, `${langPath}${asPath}`)
  }

  const consoleClick = async () => {
    const res = await API.getConsole()
    if (res.code === 0) {
      window.open(res.data || '', '_blank')
    }
  }

  const documentClick = () => {
    if (locale === 'zh') {
      window.open('https://www.tencentcloud.com/zh/document/product', '_blank')
    } else if (locale === 'en') {
      window.open('https://www.tencentcloud.com/document/product?lang=en', '_blank')
    }
  }

  const initNavData = [
    { id: 'lang', name: t('语言'), children: [{ id: 'en', name: 'English', lang: 'en', globalClick }, { id: 'zh', name: '简体中文', lang: 'zh', globalClick }] },
    { id: 'contactus', name: t('联系我们'), url: '/contactus' },
    { id: 'console', name: t('控制台'), click: consoleClick },
    { id: 'document', name: t('文档'), click: documentClick }
  ]

  const menuClick = () => {
    setMenuOpen(true)
  }
  const closeClick = () => {
    menuOpen && setMenuOpen(false)
    userOpen && setUserOpen(false)
    searchOpen && setSearchOpen(false)
  }
  const userClick = () => {
    setUserOpen(true)
  }
  const searchClick = () => {
    getSearchData()
    setSearchOpen(true)
  }

  const getSearchData = async () => {
    const { data = [] } = await API.getProductList({classify: '', keyword: searchValue})
    setSearchData(data)
  }

  const onKeyDown = async (e) => {
    if (e.keyCode === 13) {
      getSearchData()
    }
  }

  const exitClick = async () => {
    const res = await API.logout()
    if (res.code === 0) {
      clearAllCookie()
      const localePath = locale === 'en' ? 'en' : ''
      window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/home`
    }
  }

  const gotoLogin = () => {
    const localePath = locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/login`
  }

  useEffect(() => {
    const loginAccount = decodeURIComponent(getCookie('loginAccount'))
    setLoginAccount(loginAccount)
  }, [])
  return (
    <>
      <div className={styles['logo']}>
        <Link href='/home'>
          <>
            <div>
              <Image src={Logo} fill alt="logo" />
            </div>
            <span>CDZ Cloud</span>
          </>
        </Link>
      </div>
      <div style={{ flex: 'auto' }}></div>
      <div className={styles['mobile-header-right']}>
        {!menuOpen && !userOpen && !searchOpen && (
          <>
            <SearchOutlined className={styles['nav-right-icon']} onClick={searchClick} />
            <UserOutlined className={styles['nav-right-icon']} onClick={userClick} />
            <BarsOutlined className={styles['nav-right-icon']} onClick={menuClick} />
          </>
        )}
        {(menuOpen || userOpen || searchOpen) && <CloseOutlined className={styles['nav-right-icon']} onClick={closeClick} />}
        {menuOpen && <MobileList open={menuOpen} list={[...headerData.mobileData, ...initNavData]} />}
        {userOpen && (
          <div className={styles['nav-user-m']}>
            <ul>
              <li>{!loginAccount ? <a onClick={gotoLogin}>{t('登录')}</a> : <a onClick={exitClick}>{t('退出登录')}</a>}</li>
            </ul>
          </div>
        )}
        {searchOpen && <MobileInput {...{ searchData, setSearchValue, searchValue, onKeyDown }} />}
      </div>
    </>
  )
}
export default MobileNav
