import { useState, useEffect } from 'react'
import { DownOutlined } from '@ant-design/icons'
import styles from './mobile.module.scss'
import { useRouter } from 'next/router'

const backgroundColor = { 20: '#151C24', 35: 'rgb(33, 40, 45)', 50: 'rgb(44, 51, 55)', 65: 'rgb(58, 67, 71)' }

function menus (data, menuListClick, paddingLeft = 20) {
  return (
    <ul>
      {data.map(e => {
        const { id, name, menuClassName = 'menu-init', children, color, rotate } = e
        return (
          <li
            key={id}
            className={styles[menuClassName]}
            style={{ backgroundColor: backgroundColor[paddingLeft] }}
          >
            <div
              style={{ paddingLeft: `${paddingLeft}px`, color }}
              onClick={(event) => menuListClick(id, event, e)}
            >
              {name}
              {children?.length > 0 && <DownOutlined className={styles['menu-down']} style={{ right: '20px', transform: `rotate(${rotate})` }} />}
            </div>
            {children?.length > 0 && menus(children, menuListClick, paddingLeft + 15)}
          </li>
        )
      })}
    </ul>
  )
}

const resetMenuClass = (data) => {
  return data.map(e => {
    e.menuClassName = 'menu-init'
    e.rotate = '0deg'
    if (e.children?.length) {
      e.children = resetMenuClass(e.children)
    }
    return e
  })
}

const setMenuClass = (id, data) => {
  return data.map(e => {
    const { children = [], menuClassName = 'menu-init' } = e

    if (e.id === id) {
      console.log(e.id, id, e.name, 999)
      let _menuClassName = '', rotate = e.rotate || '0deg'
      if (menuClassName === 'menu-init') {
        _menuClassName = 'menu-open'
      } else {
        _menuClassName = 'menu-init'
      }
      if (rotate === '-180deg') {
        rotate = '0deg'
      } else if (rotate === '0deg') {
        rotate = '-180deg'
      }
      e.children = resetMenuClass(children)
      return {
        ...e,
        menuClassName: _menuClassName,
        rotate
      }
    }
    if (children?.length) {
      e.children = setMenuClass(id, children)
    }
    return e
  })
}

function MobileList ({ open = false, list = [], className = 'nav-menu-m' }) {
  const router = useRouter()
  const [data, setData] = useState([])
  useEffect(() => {
    setData(list)
  }, [list])

  const link = (pathname) => {
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}${pathname}`
  }

  const menuListClick = (id, e, info) => {
    const { url = '', lang = '', click } = info
    e.stopPropagation()
    if (url) {
      link(url)
      return
    }
    if (lang) {
      info.globalClick(lang)
      return
    }
    if (click) {
      click()
      return
    }
    const newMenus = setMenuClass(id, data)
    setData(newMenus.map(e => ({ ...e, color: e.menuClassName === 'menu-open' ? '#378EFF' : '#fff' })))
  }
  return (
    open && <div className={styles[className]}>{menus(data, menuListClick)}</div>
  )
}
export default MobileList
