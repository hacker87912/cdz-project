import { useState, useEffect } from 'react'
import { SearchOutlined, GlobalOutlined, PhoneOutlined } from '@ant-design/icons'
import Link from 'next/link'
import { useTranslation } from 'next-i18next'
import { Search } from './pcInput'
import styles from '../index.module.scss'
import { Avatar } from 'antd'
import { useRouter } from 'next/router'
import * as API from '@/services'
import { getCookie, clearAllCookie } from '@/utils/storage'

const globalNames = [{ name: 'English', lang: 'en' }, { name: '简体中文', lang: 'zh'}]

function GlobalBox ({ show }) {
  const { asPath, locale = 'zh' } = useRouter()
  const localePath = locale === 'zh' ? '' : `/${locale}`

  const globalClick = (lang = 'zh') => {
    const langPath = lang === 'zh' ? '' : `/${lang}`
    window.location.href = window.location.href.replace(`${localePath}${asPath}`, `${langPath}${asPath}`)
  }

  return (
    <div className={styles['global-box']} style={show ? null : { left: 'auto', right: 0 }}>
      <ul>
        {globalNames.map(e => <li key={e.name}><span onClick={() => globalClick(e.lang)}>{e.name}</span></li>)}
      </ul>
    </div>
  )
}

function LoginBox ({ username, href, loginAccount, t }) {
  const router = useRouter()
  const exitClick = async () => {
    const res = await API.logout()
    if (res.code === 0) {
      clearAllCookie()
      const localePath = router.locale === 'en' ? 'en' : ''
      window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/home`
    }
  }
  return (
    <>
      <div className={styles['login-box']}>
        <h1>{username}</h1>
        <h4>{loginAccount}</h4>
        <ul>
          {[{ name: t('账号信息'), pathname: '/account/user' }, { name: t('费用中心'), pathname: '/expense/bill/overview' }, { name: t('未读消息'), pathname: '/messagecenter/stationmessage' }].map(e => <li key={e.name}><Link href={e.pathname}>{e.name}</Link></li>)}
        </ul>
        <div className={styles['exit-box']}><a onClick={exitClick}>{t('退出')}</a></div>
      </div>
    </>
  )
}

function NavRight ({ show }) {
  const { t } = useTranslation('common')
  const [searchOpen, setSearchOpen] = useState(false)
  const [href, setHref] = useState('')
  const [searchData, setSearchData] = useState([])
  const [searchValue, setSearchValue] = useState('')
  const [username, setUsername] = useState('')
  const [loginAccount, setLoginAccount] = useState('')
  const { locale = 'zh', push } = useRouter()

  const getSearchData = async () => {
    const { data = [] } = await API.getProductList({classify: '', keyword: searchValue})
    setSearchData(data)
  }

  const searchClick = async () => {
    if (searchOpen) {
      getSearchData()
    }
    setSearchOpen(true)
  }
  const onKeyDown = async (e) => {
    if (e.keyCode === 13) {
      getSearchData()
    }
  }
  useEffect(() => {
    setHref(window.location.href)
    const username = decodeURIComponent(getCookie('accountName'))
    const loginAccount = decodeURIComponent(getCookie('loginAccount'))
    setUsername(username)
    setLoginAccount(loginAccount)
  }, [])

  const consoleClick = async () => {
    const res = await API.getConsole()
    if (res.code === 0) {
      window.open(res.data || '', '_blank')
    }
  }

  const documentClick = () => {
    if (locale === 'zh') {
      window.open('https://www.tencentcloud.com/zh/document/product', '_blank')
    } else if (locale === 'en') {
      window.open('https://www.tencentcloud.com/document/product?lang=en', '_blank')
    }
  }
  return (
    <>
      {show && (
        <div className={styles['pc-nav-search-box']} style={{ width: `${searchOpen ? '400px' : '0'}` }}>
          {searchOpen && <Search setSearchOpen={setSearchOpen} searchOpen={searchOpen} list={searchData} onChange={setSearchValue} value={searchValue} onKeyDown={onKeyDown} />}
          <SearchOutlined className={styles['nav-right-icon']} style={{ right: `${searchOpen ? '30px' : '0'}` }} onClick={searchClick} />
        </div>
      )}
      <span className={styles['nav-right-global-icon']}>
        <GlobalOutlined className={`${styles['nav-right-icon']} ${styles['nav-global-icon']}`} />
        <GlobalBox show={show} />
      </span>
      {show && (
        <>
          <Link href='/contactus' className={styles['nav-right-icon']}><PhoneOutlined /></Link>
          <a onClick={consoleClick}>{t('控制台')}</a>
          <a onClick={documentClick}>{t('文档')}</a>
          {username && (
            <span className={styles['pc-login-active']}>
              <Avatar
                style={{
                  backgroundColor: 'brown',
                  verticalAlign: 'middle',
                  cursor: 'pointer'
                }}
                gap={1}
              >
                {username}
              </Avatar>
              <LoginBox username={username} loginAccount={loginAccount} href={href} t={t} />
            </span>
          )}
          {!username && <Link href={{ pathname: '/login' }}>{t('登录')}</Link>}
        </>
      )}
    </>
  )
}
export default NavRight
