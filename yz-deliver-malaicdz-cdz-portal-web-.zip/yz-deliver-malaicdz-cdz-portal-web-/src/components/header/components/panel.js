import Input from './pcInput'
import { useRouter } from 'next/router'
import styles from '../index.module.scss'
import { useStore } from '@/store'
import { getHeaderData } from '@/pages/_app'
import { CloseOutlined } from '@ant-design/icons'
import { useRef } from 'react'
import { isURL } from '@/utils/regExp'

// const productData = [
//   { name: '计算和容器' , data: [['计算'], ['容器']] },
//   { name: '存储' , data: [['存储1'], ['存储2']] },
//   { name: '数据库' , data: [] },
//   { name: '安全' , data: [] },
//   { name: '人工智能' , data: [] },
// ]

// function PanelProductBox ({ data = productData }) {
//   const [name, setName] = useState('')
//   const leftData = data.map(e => e.name)
//   const rightData = data.map(e => e.data)
//   const nameMouse = (e) => {
//     setName(e)
//   }
//   return (
//     <div className={styles['product-box']}>
//       <div className={styles['product-left-box']}>
//         <ul>
//           {leftData.map(e => (<li key={e} className={styles['product-item']} onMouseEnter={() => nameMouse(e)}>{e}</li>))}
//         </ul>
//       </div>
//       <div className={styles['product-right-box']}>
//         {rightData.map((e, i) => (
//           name === leftData[i] && <div key={i} className={styles['product-content']}>
//             <PanelList data={e} />
//           </div>
//         ))}
//       </div>
//     </div>
//   )
// }

function PanelList ({ data = [], link }) {
  return (
    <div className={styles['panel-list']}>
      {data.map((e, i) => {
        const [title, ...list] = e
        return (
          <div key={i} className={styles['panel-list-node']}>
            <div className={styles['panel-list-header']} title={title}>{title}</div>
            {list.map(v => (<div key={v.id}><a onClick={() => link(v.url)}>{v.name}</a></div>))}
          </div>
        )
      })}
    </div>
  )
}

function Panel ({ data, boxRef, valueRef, boxDom }) {
  const rightData = data.right
  const { global: { setCopyHeaderData } } = useStore()
  const router = useRouter()
  const panelDom = useRef(null)

  const searchData = async (value) => {
    const data = await getHeaderData(value)
    setCopyHeaderData(data)
    boxRef.current = true
  }

  const onKeyDown = async (e) => {
    if (e.keyCode === 13) {
      searchData(e.target.value)
    }
  }

  const panelCloseClick = () => {
    boxDom.current.style.display = 'none'
    panelDom.current.style.display = 'none'
  }

  const link = (pathname) => {
    if (isURL(pathname)) {
      window.location.href = pathname
      return
    }
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}${pathname}`
  }
  return (
    <div className={styles['nav-panel-box']} ref={panelDom}>
      <div className={styles['nav-panel-flex']}>
        <div className={styles['nav-panel-right']}>
          <Input valueRef={valueRef} onSearch={searchData} onKeyDown={onKeyDown} />
          <CloseOutlined className={styles['nav-panel-close']} onClick={panelCloseClick} />
          <PanelList data={rightData} link={link} />
        </div>
      </div>
      {/* <PanelProductBox /> */}
    </div>
  )
}
export default Panel
