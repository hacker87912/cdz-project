import React from 'react'
import PCNav from "./components/pcNav"
import MobileNav from "./components/mobileNav"
import styles from './index.module.scss'

const PageHeader = function () {

  return (
    <>
      <div className={styles['pc-box']}>
        <div className={styles['nav']}>
          <PCNav />
        </div>
      </div>
      <div className={styles['mobile-box']}>
        <div className={styles['nav']}>
          <MobileNav />
        </div>
      </div>
    </>
  )
}

export default PageHeader
