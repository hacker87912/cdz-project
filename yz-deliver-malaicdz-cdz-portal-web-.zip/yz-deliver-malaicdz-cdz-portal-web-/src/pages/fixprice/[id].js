import React, { useState } from 'react'
import { observer } from 'mobx-react-lite'
import PageLayout from '@/components/layout'
import Image from 'next/image'
import Link from 'next/link'
import styles from './detail.module.scss'
import { useTranslation } from 'next-i18next'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import televisionImg from '@/assets/img/television.png'
import { Divider, Tabs, Segmented, Radio, Row, Col, Descriptions, Select, Space, Table } from 'antd'

// 区域选择数据
const addressList = [
  {
    territoryName: '新加坡',
    content: [
      { areaName: "新加坡一区" }, { areaName: "新加坡二区" }
    ]
  },
  {
    territoryName: '曼谷',
    content: [
      { areaName: "曼谷一区" }, { areaName: "曼谷二区" }
    ]
  }
]

// 费用详情表格标题
const tableColumns = [
  {
    title: '模型',
    dataIndex: 'a',
    key: 'a',
  },
  {
    title: '规格',
    dataIndex: 'b',
    key: 'b',
  },
  {
    title: 'CPU（核心）',
    dataIndex: 'c',
    key: 'c',
  },
  {
    title: 'Mem（G）',
    dataIndex: 'd',
    key: 'd',
  },
  {
    title: '按使用情况（美元/小时）',
    dataIndex: 'e',
    key: 'e',
  }
]

// 费用详情表格内容
const tableDataSource = [
  // {
  //   key: '1',
  //   a: '1',
  //   b: '标准S6',
  //   c: 'S6。 中号2',
  //   d: '2',
  //   e: '0.04',
  // },
  // {
  //   key: '2',
  //   a: '1',
  //   b: '标准S6',
  //   c: 'S6。 中号2',
  //   d: '2',
  //   e: '0.04',
  // },
]

// 当前页面组件
const FixpriceDetail = () => {
  const { t } = useTranslation('common')
  return (
    <PageLayout title={t('定价详情')}>
      <div className={styles['fixpriceDetail-page']}>
        {/* <Mobile /> */}
        <PC />
      </div>
    </PageLayout>
  )
}

// PC端组件
const PC = () => {
  const { t } = useTranslation('common')
  // 地域选项
  const territoryOptions = addressList.map(item => item.territoryName) // ['新加坡', '曼谷']

  // 可用区域选项
  const [areaOptions, setAreaOptions] = useState(addressList[0].content.map(item => item.areaName)) // ['CDZ一区', 'CDZ二区']

  // 当前选中的可用区
  const [curArea, setCurArea] = useState(areaOptions[0])

  // 选择地域
  const territoryChange = (key) => {
    addressList.map(item => {
      if(key === item.territoryName){
        setAreaOptions(item.content.map(item => item.areaName))
        setCurArea(item.content[0].areaName)
      }
    })
  }

  // 选择可用区
  const areaChange = (key) => {
    setCurArea(key)
  }

  // tabPane
  const tabItems = [
    {
      key: '1',
      label: `${t('模型价格')}`,
      children: <PriceTable tableDataSource={tableDataSource} tableColumns={tableColumns} />,
    },
    {
      key: '2',
      label: `${t('RI定价')}`,
      children: <PriceTable tableDataSource={tableDataSource} tableColumns={tableColumns} />,
    },
    {
      key: '3',
      label: `${t('磁盘价格')}`,
      children: <PriceTable tableDataSource={tableDataSource} tableColumns={tableColumns} />,
    },
    {
      key: '4',
      label: `${t('带宽价格')}`,
      children: <PriceTable tableDataSource={tableDataSource} tableColumns={tableColumns} />,
    },
  ]

  return (
    <div className={styles['pc-fixpriceDetail']}>
      <div className={styles['header-banner']}>
        <div className={styles['container']}>
          <div className={styles['container-left']}>
            <div className={styles['title']}>
              <span>{t('定价')}</span>
              <Divider className={styles['divider']} type="vertical" />
              <span>{t('云虚拟主机')}</span>
            </div>
          </div>
          <div className={styles['container-right']}>
            <Image alt='promotion' src={televisionImg} />
          </div>
        </div>
        <div className={styles['tabs']}>
          <Radio.Group className={styles['content']} defaultValue="a" buttonStyle="solid" size="large">
            <Space>
              <Radio.Button value="a">{t('产品定价')}</Radio.Button>
              <Radio.Button value="b">{t('价格计算器')}</Radio.Button>
            </Space>
          </Radio.Group>
        </div>
      </div>
      <div className={styles['middle-content']}>
        <div className={styles['name']}>
          <Row justify="space-between">
            <Col className={styles['left']} span={12}>{t('云虚拟机')}</Col>
            <Col className={styles['right']} span={12}><Link href="/product">{t('查看产品概述')}</Link></Col>
          </Row>
        </div>
        <div className={styles['content']}>
          <div className={styles['address']}>
            <Descriptions className={styles['descriptions']} title={t('地域')} column={1}>
              <div>
                <div className={styles['title']}>{t('地域')}</div>
                <Segmented size="large" options={territoryOptions} onChange={(e) => { territoryChange(e) }} block={true} />
              </div>
              <div>
                <div className={styles['title']}>{t('可用区域')}</div>
                <Segmented size="large" value={curArea} options={areaOptions} onChange={(e) => { areaChange(e) }} block={true} />
              </div>
            </Descriptions>
          </div>
          <div className={styles['price']}>
            <Descriptions className={styles['descriptions']} title={t('费用详情')} column={1}>
              <div>
                <Tabs defaultActiveKey="1" items={tabItems} onChange={(key) => { console.log('onChange', key) }} style={{ width: "100%", textAlign: "left" }} />
              </div>
            </Descriptions>
          </div>
        </div>
      </div>
    </div>
  )
}

// PC端tabItem中的表格
const PriceTable = (props) => {
  return <div>
    <Radio.Group className={styles['system']} defaultValue="a" buttonStyle="solid">
      <Radio.Button value="a">Linux</Radio.Button>
      <Radio.Button value="b">Windows</Radio.Button>
    </Radio.Group>
    <div>
      <Space>
        <Select
          defaultValue="all"
          style={{ width: 120 }}
          onChange={() => { console.log(123) }}
          options={[
            { value: 'all', label: '所有CPU' },
            { value: '1', label: '1核' },
            { value: '2', label: '2核' },
          ]}
        />
        <Select
          defaultValue="all"
          style={{ width: 120 }}
          onChange={() => { console.log(123) }}
          options={[
            { value: 'all', label: '所有Mem' },
            { value: '1', label: '1GB' },
            { value: '2', label: '2GB' },
          ]}
        />
      </Space>
    </div>
    <Radio.Group className={styles['system']} defaultValue="a" buttonStyle="solid">
      <Radio.Button value="a">所有型号</Radio.Button>
      <Radio.Button value="b">标准</Radio.Button>
      <Radio.Button value="c">高IO</Radio.Button>
      <Radio.Button value="d">MEM优化</Radio.Button>
      <Radio.Button value="e">计算</Radio.Button>
      <Radio.Button value="f">基于GPU的</Radio.Button>
      <Radio.Button value="g">基于FPGA的</Radio.Button>
      <Radio.Button value="h">大数据</Radio.Button>
      <Radio.Button value="i">云物理器2.0</Radio.Button>
    </Radio.Group>
    <Table className={styles['table']} pagination={false} dataSource={props.tableDataSource} columns={props.tableColumns} />
    <div className={styles['memo']}>
      <h4>备注</h4>
      <p>1.上述价格仅包括CPU和MEM的费用，不包括图像、系统磁盘、数据磁盘和带宽的费用。</p>
      <p>2.表中的所有价格都适用于新购买的实例。对于续订或配置调整，价格可能会有所不同。</p>
    </div>
  </div>
}


// // 移动端组件
// const Mobile = () => {
//   return (
//     <div className={styles['mobile-fixpriceDetail']}>123</div>
//   )
// }

export default observer(FixpriceDetail)

export async function getServerSideProps (context) {
  const fixPriceData = []
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
      fixPriceData
    }
  }
}
