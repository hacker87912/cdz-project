import React from 'react'
import { observer } from 'mobx-react-lite'
// import Head from 'next/head'
import Image from 'next/image'
import PageLayout from '@/components/layout'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import { Row, Col, Collapse } from 'antd'
import { SmileTwoTone } from '@ant-design/icons'
import promotionImg from '@/assets/img/promotion.png'
import * as API from '@/services'
import { useRouter } from 'next/router'

const { Panel } = Collapse

const FixPrice = ({ data }) => {
  const { t } = useTranslation('common')
  const router = useRouter()

  const link = (pathname) => {
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}${pathname}`
  }
  return (
    <PageLayout title={t('定价')}>
      <div className={styles['fixprice-page']}>
        <Mobile data={data} link={link} />
        <PC data={data} link={link} />
      </div>
    </PageLayout>
  )
}

const Mobile = ({ data, link }) => {
  const { t } = useTranslation('common')
  return <div className={styles['mobile-fixprice']}>
    {/* 头部区域 */}
    <div className={styles['banner']}>
      <div className={styles['container-top']}>
        <Image alt='promotion' src={promotionImg} />
      </div>
      <div className={styles['container-bottom']}>
        <div className={styles['title']}>{t('CDZ定价')}</div>
        <div className={styles['content']}>{t('以最具成本效益的云化方式，为企业带来最大价值')}</div>
      </div>
    </div>
    {/* 中间区域 */}
    <div className={styles['products']}>
      <Collapse expandIconPosition="end" size="large">
        {data.map((item, i) => {
          return <Panel className={styles['row']} header={item.typeName} key={i}>
            {item.content.map((subItem, j) => {
              return <div key={j}>
                <a onClick={() => link(`/fixprice/${subItem.id}`)}>{subItem.productName}</a>
              </div>
            })}
          </Panel>
        })}
      </Collapse>
    </div>
    {/* 底部区域 */}
    <div className={`${styles['foot-banner']} ${styles['banner']}`}>
      <div className={styles['container-bottom']}>
        <div className={styles['title']}>{t('年度和每月订阅')}</div>
        <div className={styles['content']}>{t('预付费后保留足够的资源可以有效地降低风险，更可预测地管理预算，并享受大幅折扣')}</div>
      </div>
      <div className={styles['container-top']}>
        <Image alt='promotion' src={promotionImg} />
      </div>
    </div>
  </div>
}

const PC = ({ data, link }) => {
  const { t } = useTranslation('common')
  return <div className={styles['pc-fixprice']}>
    {/* 头部区域 */}
    <div className={styles['banner']}>
      <div className={styles['container']}>
        <div className={styles['container-left']}>
          <div className={styles['title']}>{t('CDZ定价')}</div>
          <div className={styles['content']}>{t('以最具成本效益的云化方式，为企业带来最大价值')}</div>
          <div>
          </div>
        </div>
        <div className={styles['container-right']}>
          <Image alt='promotion' src={promotionImg} />
        </div>
      </div>
    </div>
    {/* 中间区域 */}
    <Row className={styles['products']}>
      {data.map((item, i) => {
        return (
          <Col className={styles['block']} span={6} key={i}>
            <SmileTwoTone style={{ fontSize: '46px' }} />
            <div className={styles['title']}>{item.typeName}</div>
            {item.content.map((subItem, j) => {
              return <div key={j}>
                <a onClick={() => link(`/fixprice/${subItem.id}`)}>{subItem.productName}</a>
              </div>
            })}
          </Col>
        )
      })}
    </Row>
    {/* 底部区域 */}
    <div className={`${styles['foot-banner']} ${styles['banner']}`}>
      <div className={styles['container']}>
        <div className={styles['container-left']}>
          <div className={styles['title']}>{t('年度和每月订阅')}</div>
          <div className={styles['content']}>{t('预付费后保留足够的资源可以有效地降低风险，更可预测地管理预算，并享受大幅折扣')}</div>
          <div>
          </div>
        </div>
        <div className={styles['container-right']}>
          <Image alt='promotion' src={promotionImg} />
        </div>
      </div>
    </div>
  </div>
}

export default observer(FixPrice)

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  const { data: classifyData = [] } = await API.getPricingClassify({}, context)
  const res = await Promise.all(
    classifyData.map(e => (
      API.getPricingList({classify: e.id}, context)
    ))
  )
  const data = res?.map((e, i) => {
    const { data = [] } = e
    return { typeName: classifyData[i].name, content: data }
  }) || []
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
      data
    }
  }
}
