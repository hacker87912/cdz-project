import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import Link from 'next/link'
import Image from 'next/image'
import { useTranslation } from 'next-i18next'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { LockOutlined, UserOutlined } from '@ant-design/icons'
import PageLayout from '@/components/layout'
import { Button, Form, Input, Alert } from 'antd'
import * as API from '@/services'
import styles from './index.module.scss'
import loginImg from '@/assets/img/tencentcloud.jpg'
import { getCookie, setCookie, clearAllCookie } from '@/utils/storage'
import { encrypt } from '@/utils/utils'

const Login = function () {
  const router = useRouter()
  const { t } = useTranslation('common')
  const [isLogin, setIsLogin] = useState(false)
  const [account, setAccount] = useState('')
  useEffect(() => {
    currentIsLogin()
  }, [])

  // 是否登录
  const currentIsLogin = () => {
    if (router.query?.s_url !== 'unauthorized' && getCookie('Authorization') && getCookie('loginAccount')) {
      setIsLogin(true)
      setAccount(decodeURIComponent(getCookie('loginAccount')))
    }
  }
  // 切换账号
  const loginOther = async () => {
    const res = await API.logout()
    if (res.code === 0) {
      clearAllCookie()
      setIsLogin(false)
    }
  }
  // 登录提交
  const onFinish = async (values) => {
    const { loginAccount, loginPwd } = values
    const res = await API.login({
      loginAccount,
      loginPwd: encrypt(loginPwd)
    })
    if (res.code === 0) {
      setCookie('Authorization', res.data?.token, 24)
      setCookie('accountId', res.data?.id, 24)
      setCookie('accountName', encodeURIComponent(res.data?.accountName), 24)
      setCookie('loginAccount', encodeURIComponent(res.data?.loginAccount), 24)
      setCookie('unReadMessages', res.data?.unReadMessages, 24)
      gotoHome()
    }
  }
  // 跳转首页
  const gotoHome = () => {
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/home`
  }
  return (
    <PageLayout title={t('登录')}>
      <div className={styles['login-body']}>
        <div className={styles['login-form-container']}>
          {
            isLogin ? (
              <Form
                name='normal_login'
                className={styles['login-form']}
                initialValues={{
                  loginAccount: '',
                  loginPwd: ''
                }}
                onFinish={onFinish}
              >
                <Form.Item>
                  <h1 className={styles['login-title']}>{t('已登录账号')}</h1>
                </Form.Item>
                <Form.Item>
                  <Alert
                    description={`${t('账号')}${account}${t('已登录, 可以选择直接登录继续使用, 也可以使用其他账号登录')}`}
                    type='info'
                  />
                </Form.Item>
                <Form.Item>
                  <Button
                    type='primary'
                    block
                    className={styles['login-form-button']}
                    onClick={gotoHome}
                  >
                    {t('快速登录')}
                  </Button>
                </Form.Item>
                <Form.Item>
                  <Button type='link' onClick={loginOther}>{`< ${t('登录其他账号')}`}</Button>
                </Form.Item>
              </Form>
            ): (
              <Form
                name='normal_login'
                className={styles['login-form']}
                initialValues={{
                  loginAccount: '',
                  loginPwd: ''
                }}
                onFinish={onFinish}
              >
                <Form.Item>
                  <h1 className={styles['login-title']}>{t('邮箱登录')}</h1>
                </Form.Item>
                <Form.Item
                  name='loginAccount'
                  rules={[
                    {
                      required: true,
                      message: t('请输入用户名'),
                    },
                  ]}
                >
                  <Input
                    prefix={<UserOutlined className='site-form-item-icon' />}
                    size='large'
                    placeholder={t('请输入用户名')}
                    className={styles['login-form-input']}
                  />
                </Form.Item>
                <Form.Item
                  name='loginPwd'
                  rules={[
                    {
                      required: true,
                      message: t('请输入密码'),
                    },
                  ]}
                >
                  <Input
                    prefix={<LockOutlined className='site-form-item-icon' />}
                    type='password'
                    size='large'
                    placeholder={t('请输入密码')}
                    className={styles['login-form-input']}
                  />
                </Form.Item>
                <Form.Item>
                  <Link href='/reset'>{t('忘记密码')}</Link>
                </Form.Item>
                <Form.Item>
                  <Button
                    type='primary'
                    block
                    style={{height: '48px'}}
                    htmlType='submit'
                    className={styles['login-form-button']}
                  >
                    {t('登录')}
                  </Button>
                </Form.Item>
              </Form>
            )
          }
        </div>
        <div className={styles['login-event-container']}>
          <div className={styles['login-event']}>
            <Image
              src={loginImg}
              alt='Picture of the author'
              fill
              sizes='(min-width: 768px) 800px'
              priority
            />
          </div>
        </div>
      </div>
    </PageLayout>
  )
}

export default Login

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common']))
    }
  }
}
