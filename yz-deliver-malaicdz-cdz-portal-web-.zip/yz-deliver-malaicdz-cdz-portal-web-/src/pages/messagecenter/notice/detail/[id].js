import React, { useEffect, useState } from 'react'
import ExpenseCenter from '@/pages/messagecenter'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import { Text, H3 } from "tea-component"
import { useRouter } from 'next/router'
import * as API from '@/services'

const NoticeDetail = () => {
  const { t } = useTranslation('common')
  const { query } = useRouter()
  const [data, setData] = useState({})

  const getData = async () => {
    const res = await API.getNotificationDetail({ id: query.id })
    setData(res.data)
  }

  useEffect(() => {
    getData()
  }, [])

  return (
    <div className={styles['page-noticedetail']}>
      <H3>{data.title}</H3>
      <p className={styles['time']}><Text>{t('发布时间')}：{data.releaseTime}</Text></p>
      <div className={styles['text-content']}>
        <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.content }}></div>
      </div>
    </div>
  )
}

export default NoticeDetail

NoticeDetail.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('公告详情')}>{page}</ExpenseCenter>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common']))
    }
  }
}
