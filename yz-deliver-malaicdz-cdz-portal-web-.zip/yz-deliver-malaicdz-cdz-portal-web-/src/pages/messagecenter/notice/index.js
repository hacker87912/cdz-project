import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import MessageCenter from '@/pages/messagecenter'
import { SpaceBetweenBox } from '@/components/common'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import { SearchBox, Justify, Table, Card } from "tea-component"
import * as API from '@/services'

const { pageable, autotip } = Table.addons

function Notice () {
  const { t } = useTranslation('common')
  const [data, setData] = useState([])
  const [key, setKey] = useState('')
  const [loading, setLoading] = useState(false)
  const [paging, setPaging] = useState({ current: 1, size: 10, total: 0 })
  const { current, size, total } = paging


  const getData = async () => {
    setLoading(true)
    const res = await API.getNotificationList({ current, size, key })
    const { data: { records = [], total = 0 } = {} } = res
    setData(records)
    setPaging((e => ({ ...e, total })))
    setLoading(false)
  }

  useEffect(() => {
    getData()
  }, [current, size, key])

  const onSearch = (value) => {
    setPaging((e => ({ ...e, current: 1 })))
    setKey(value)
  }


  const tableColumns = [
    {
      header: t('序号'),
      dataIndex: 'id',
      key: 'id',
      width: 50,
      render: (record, key, index) => <span>{(current - 1) * size + index + 1}</span>
    },
    {
      header: t('公告标题'),
      dataIndex: 'title',
      key: 'title',
      render: (record) => <Link href={`/messagecenter/notice/detail/${record.id}`}>{record.title}</Link>
    },
    {
      header: t('发布时间'),
      dataIndex: 'releaseTime',
      key: 'releaseTime',
      width: 200
    },
  ]

  return (
    <Card className={styles['page-notice']}>
      <Card.Body>
        <Justify
          right={
            <SearchBox placeholder={t('请输入公告标题')} size='m' onSearch={onSearch} />
          }
        />
        <SpaceBetweenBox boxTop='10px'>
          <Table
            verticalTop
            bordered
            recordKey="id"
            records={data}
            columns={tableColumns}
            addons={[
              pageable({
                recordCount: total,
                pageIndex: current,
                pageSize: size,
                onPagingChange: ({ pageIndex, pageSize }) => setPaging((e => ({ ...e, current: pageIndex, size: pageSize }))),
              }),
              autotip({
                isLoading: loading,
              }),
            ]}
          />
        </SpaceBetweenBox>
      </Card.Body>
    </Card>
  )
}

export default Notice

Notice.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <MessageCenter headTitle={t('通知公告')}>{page}</MessageCenter>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common']))
    }
  }
}
