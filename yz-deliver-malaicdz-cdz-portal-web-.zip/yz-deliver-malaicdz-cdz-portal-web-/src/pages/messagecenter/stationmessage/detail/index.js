import React from 'react'
import { observer } from 'mobx-react-lite'
// import Link from 'next/link'
import ExpenseCenter from '@/pages/messagecenter'
// import { SpaceBetweenBox } from '@/components/common'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import { Button, Text, H3 } from "tea-component"

const textData = {
  title: "【财务消息】2023-01账单通知",
  time: "2023-01-01 00:00:00",
  content: ["尊敬的用户，您好！", "账号 ID：100019171234，昵称：Elaine Huang，2021-05 账单已出账。", "您 2021-05 的消费概览情况如下："],
  billparam: [{
    name: "账单周期",
    content: '2021/05/01-2021/05/31',
  },
  {
    name: "总费用",
    content: '600.00 美元',
  },
  {
    name: "CDZ费用",
    content: '600.00 美元',
  },
  {
    name: "非CDZ费用",
    content: '0.00 美元',
  },
  {
    name: "账单结算费用",
    content: '600.00 美元',
  }],
  billRule: '账单结算费用 = 总费用 - 非CDZ费用',
  tipText: {
    title: "温馨提示",
    content: [ "1. 此通知并非欠费通知，只作为告知您每个月的消费情况。", "2. 若您对本月账单费用有任何问题或争议，可联系我们，我们将尽快为您解答、核实和处理。" ]
  }
}

const StationMessageDetail = () => {
  const { t } = useTranslation('common')

  return <ExpenseCenter headTitle={t('消息详情')}>
    <div className={styles['page-stationmessagedetail']}>
      <div className={styles['top-right']}>
        <Button className={styles['btn']}>{t('上一封')}</Button>
        <Button className={styles['btn']}>{t('下一封')}</Button>
      </div>
      <H3>{textData.title}</H3>
      <p className={styles['time']}><Text>{textData.time}</Text></p>
      <div className={styles['text-content']}>
        { textData.content.map((item,index)=>{
          return <p key={index}><Text>{item}</Text></p>
        })}
      </div>
      <div className={styles['bill']}>
        { textData.billparam.map((item,index)=>{
          return <div className={styles['row']} key={index}><div className={styles['left']}>{item.name}</div><div className={styles['right']}>{item.content}</div></div>
        })}
      </div>
      <div>{textData.billRule}</div>
      <Button type="primary" className={styles['main-btn']}>{t('查看账单')}</Button>
      <div className={styles['tip']}>
        <div className={styles['title']}>{textData.tipText.title}</div>
        {textData.tipText.content.map((item,index)=>{
          return <p key={index}>{item}</p>
        })}
      </div>
    </div>
  </ ExpenseCenter>
}

export default observer(StationMessageDetail)

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common']))
    }
  }
}
