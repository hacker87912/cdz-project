import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import ExpenseCenter from '@/pages/messagecenter'
import { SpaceBetweenBox } from '@/components/common'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import { SearchBox, Select, Justify, Button, Table, Card, Text } from "tea-component"

const { pageable, selectable } = Table.addons

// 站内信表格内容
const tableDataSource = [

]

const StationMessage = () => {
  const { t } = useTranslation('common')
  const [selectedKeys, setSelectedKeys] = useState([])
  const [btnDisabled, setBtnDisabled] = useState(true)

  useEffect(() => {
    if (selectedKeys.length === 0) {
      setBtnDisabled(true)
    } else {
      setBtnDisabled(false)
    }
  }, [selectedKeys])

  const operation = (record) => {
    return <Link href={`/messagecenter/stationmessage/detail`}><Text theme="primary">{t('详情')}</Text></Link>
  }

  // 站内信表格标题
  const tableColumns = [
    {
      header: '消息标题',
      dataIndex: 'a',
      key: 'a',
    },
    {
      header: '消息类型',
      dataIndex: 'b',
      key: 'b',
    },
    {
      header: '接收时间',
      dataIndex: 'c',
      key: 'c',
    },
    {
      key: "operation",
      header: "操作",
      width: 100,
      align: "center",
      render: operation
    },
  ]

  return (
    <Card>
      <Card.Body>
        <Justify
          left={
            <SpaceBetweenBox>
              <div className={styles['t-h-left']}>
                <Button disabled={btnDisabled}>
                  {t('标记为已读')}
                </Button>
                <Button>
                  {t('全部标记为已读')}
                </Button>
              </div>
            </SpaceBetweenBox>
          }
          right={
            <div>
              <Select
                appearance="button"
                options={[
                  { value: 'all', text: '全部' },
                  { value: '1', text: '已读' },
                  { value: '2', text: '未读' },
                ]}
                defaultValue={'all'}
                onChange={value => () => { console.log(value) }}
                placeholder={t('请选择')}
              />
              <Select
                appearance="button"
                options={[
                  { value: 'all', text: '全部' },
                  { value: '1', text: '账单出账通知' },
                  { value: '2', text: '优惠券相关消息' },
                  { value: '3', text: '其他' },
                ]}
                defaultValue={'all'}
                onChange={value => () => { console.log(value) }}
                placeholder={t('请选择')}
              />
              <SearchBox placeholder={t('请输入消息标题')} size='m' />
            </ div>
          }
        />

        <SpaceBetweenBox boxTop='10px'>
          <Table
            verticalTop
            bordered
            records={tableDataSource}
            columns={tableColumns}
            addons={[
              selectable({
                value: selectedKeys,
                onChange: (keys, context) => {
                  console.log(keys, context)
                  setSelectedKeys(keys)
                },
                rowSelect: true,
              }),
              pageable()
            ]}
          />
        </SpaceBetweenBox>
      </Card.Body>
    </Card>
  )
}

export default StationMessage

StationMessage.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('站内信')}>{page}</ExpenseCenter>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common']))
    }
  }
}
