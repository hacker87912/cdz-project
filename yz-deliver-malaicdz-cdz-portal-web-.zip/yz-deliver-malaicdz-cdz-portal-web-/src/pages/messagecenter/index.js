import { useMemo } from 'react'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import CenterLayout from '@/components/centerLayout'
import { useTranslation } from 'next-i18next'
import { Layout } from 'tea-component'
// import styles from './index.module.scss'

const Body = Layout.Content.Body

export default function MessageCenter ({ children, ...rest }) {
  const { t } = useTranslation('common')
  const menus = useMemo(() => (
    [
      {
        label: t('站内信'),
        key: '/messagecenter/stationmessage'
        // key: '0',
        // children: [
        //   {
        //     label: t('消息列表'),
        //     key: '/messagecenter/stationmessage'
        //   }
        // ]
      },
      {
        label: t('通知公告'),
        key: '/messagecenter/notice',
        // key: '1',
        // children: [
        //   {
        //     label: t('通知列表'),
        //     key: '/messagecenter/notice',
        //   }
        // ]
      }
    ]
  ), [t])
  return (
    <CenterLayout title={t('消息中心')} {...rest} menus={menus}>
      {rest.isContentHeader === false ? children : (
        <Body>
          {children}
        </Body>
      )}
    </CenterLayout>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}
