import { useMemo } from 'react'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import CenterLayout from '@/components/centerLayout'
import { useTranslation } from 'next-i18next'
import { Layout } from 'tea-component'

const Body = Layout.Content.Body

export default function ExpenseCenter ({ children, ...rest }) {
  const { t } = useTranslation('common')
  const menus = useMemo(() => (
    [
      {
        label: t('费用账单'),
        key: '0',
        children: [
          {
            label: t('费用账单概览'),
            key: '/expense/bill/overview'
          },
          {
            label: t('账单列表'),
            key: '/expense/bill'
          },
          {
            label: t('账单下载中心'),
            key: '/expense/bill/downloadCenter'
          }
        ]
      },
      {
        label: t('订单管理'),
        key: '1',
        children: [
          {
            label: t('订单列表'),
            key: '/expense/order',
          }
        ]
      }
    ]
  ), [t])

  return (
    <CenterLayout title={t('费用中心')} {...rest} menus={menus}>
      {rest.isContentHeader === false ? children : (
        <Body>
          {children}
        </Body>
      )}
    </CenterLayout>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}
