import { useState } from 'react'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import ExpenseCenter from '@/pages/expense'
import { useRouter } from 'next/router'
import { Card, Layout, DatePicker, Bubble, Icon, Tabs, Select, Button, Checkbox, Justify, SearchBox, Table, Text, H1, Progress, H3, Alert } from 'tea-component'
import { SpaceBetweenBox } from '@/components/common'
import moment from "moment"
import Link from 'next/link'
import { BasicBar } from 'tea-chart'
import styles from './index.module.scss'

const { Header, Body } = Layout.Content
const { MonthPicker } = DatePicker
const { pageable } = Table.addons

function BillDetails () {
  const { back, asPath } = useRouter()
  const [tabName, setTabName] = useState('资源ID账单')
  const subTitle = () => {
    return (
      <>
        <MonthPicker
          defaultValue={moment("2020-10-01")}
          range={[moment("2019-09"), moment("2020-12")]}
          onChange={value => console.log(value.format("YYYY/MM/DD"))}
        />
        <div style={{ marginLeft: '10px', display: 'inline-block' }}>
          <span>按计费周期（按资源使用时间统计生成月度账单）</span>

          <Bubble
            placement='bottom'
            content={
              <>
                <p>按计费周期：按资源使用时间统计生成月度账单。</p>
                <p style={{ color: '#888', marginTop: '10px' }}>如：您在1月31日23:00~23:59使用的按小时结算的按量计费资源，实际扣费时间发生在2月1日，则按计费周期，该笔费用统计到1月账单。</p>
              </>
            }
          >
            <Icon type="info" />
          </Bubble>
        </div>
      </>
    )
  }
  const tabs = [
    { id: "0", label: "资源ID账单" },
    { id: "1", label: "明细账单" },
  ]
  const expenseAlert = (data = []) => {
    return (
      <Alert>
        {data.map((e, i) => (<p key={i}>{e}</p>))}
      </Alert>
    )
  }
  const operation = (record) => {
    return <Link href={`${asPath}/${record.resourceID}`}><Text theme='primary'>详情</Text></Link>
  }
  return (
    <>
      <Header
        title='账单详情'
        showBackButton
        onBackButtonClick={() => back()}
        subtitle={<>{subTitle()}</>}
      />
      <Tabs tabs={tabs} className={styles['header-tabs']} onActive={(e) => setTabName(e.label)} />
      <Body>
        {tabName === '资源ID账单' && expenseAlert(['次月1号出账，当前展示的是截至2023年3月12日使用的资源费用，部分按量付费资源还未结算，查询结果仅供参考；实时扣费数据请您查看明细账单。', '明细账单费用最多支持8位小数，资源ID账单展示的费用为四舍五入后保留2位小数的费用，实际从账户扣费时按2位小数进行扣费（即扣到分）。如需帮助，可查看 账单使用指南 。'])}
        {tabName === '明细账单' && expenseAlert(['支持页面在线查询近18个月账单数据，超过18个月的历史账单及数据量过大的月份账单可下载文件至本地查看。', '资源ID账单数据可能有延迟，实时数据请您查看明细账单。次月1号出账，当前月份账单出账未完成，以下费用不是最终的本月账单费用，仅供参考。', '明细账单费用最多支持8位小数，资源ID账单展示的费用为四舍五入后保留2位小数的费用，实际从账户扣费时按2位小数进行扣费（即扣到分）。如需帮助，可查看 账单使用指南 。'])}
        <SpaceBetweenBox boxBottom="10px">
          <Select
            size='s'
            matchButtonWidth
            appearance="button"
            options={[{ value: "0", text: "全部产品" }]}
          />
          <Select
            size='s'
            matchButtonWidth
            appearance="button"
            options={[{ value: "0", text: "全部可用地区" }, { value: "1", text: "CDZ区" }, { value: '2', text: '非CDZ区' }]}
          />
          <Button type="text" style={{ color: '#378EFF' }}>重置</Button>
          <Checkbox display="block" className={styles['checkbox']}>不显示0元费用</Checkbox>
        </SpaceBetweenBox>
        <Card>
          <Card.Body>
            <Justify
              left={
                <>
                  <div className={styles['resource-bill-total']}>现金支出（含税）<em>0.84美元</em><span>{`=   优惠后总价（不含税） 0.84 美元 - 代金券支出0.00 美元 + 扣税0.00 美元`}</span></div>
                </>
              }
              right={
                <>
                  <SearchBox size='m' />
                  <Button icon="download" />
                </>
              }
            />
            <div style={{ marginTop: '10px' }}>
              <Table
                verticalTop
                bordered
                records={[{ resourceID: 'ins-ca37c2gq', resourceName: 'ASR' }]}
                recordKey="id"
                columns={[
                  { key: 'resourceID', header: '资源ID' },
                  { key: 'resourceName', header: '资源名称' },
                  {
                    key: "operation",
                    header: "操作",
                    render: operation
                  },]}
                addons={[pageable()]}
              />
            </div>
          </Card.Body>
        </Card>
      </Body>
    </>
  )
}

function ResourceBillDetails () {
  const billRatio = (record) => {
    return (
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <Text>{record.billRatio}</Text>
        <Progress percent={30} theme="default" style={{ marginBottom: 0, flex: '1' }} />
      </div>
    )
  }
  return (
    <>
      <div style={{ padding: '0 10px 20px 10px' }}>2023-03-01 00:00:00 至 2023-03-31 23:59:59</div>
      <Card>
        <Card.Body>
          <Text parent="div" theme="strong" className={styles['center-title']}>总费用
            <Bubble
              placement='top'
              content={
                <>
                  <p>折后总费用</p>
                </>
              }
            >
              <Icon type="info" style={{ marginLeft: '4px' }} />
            </Bubble>
          </Text>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <H1>0.07</H1>
            <div style={{ fontSize: '18px', marginLeft: '5px', height: '72px', lineHeight: '82px' }}>美元</div>
          </div>
          <div style={{ marginTop: '10px' }}>
            <Table
              verticalTop
              records={[{ component: 'memory', dosage: '--', billRatio: '0.07（100%）' }, { component: 'component', dosage: '--', billRatio: '40.65（27.24%）' }]}
              recordKey="component"
              columns={[
                { key: 'component', header: '组件' },
                { key: 'dosage', header: '用量' },
                {
                  key: "billRatio",
                  header: "费用/占比",
                  render: billRatio
                },]}
            />
          </div>
        </Card.Body>
      </Card>
      <Card>
        <Card.Body>
          <H3>近6个月消费走势</H3>
          <BasicBar
            height={250}
            position='week*value'
            dataSource={[
              { week: "2022-03", value: 10 },
              { week: "2022-04", value: 20 },
              { week: "2022-05", value: 50 },
              { week: "2022-06", value: 60 },
              { week: "2022-07", value: 20 },
              { week: "2022-08", value: 72 },
              { week: "2022-09", value: 98 },
            ]}
          />
        </Card.Body>
      </Card>
    </>
  )
}

function Details () {
  const { query } = useRouter()
  if (query.billDetails.length === 1) {
    return <BillDetails />
  }
  if (query.billDetails.length === 2) {
    return <ResourceBillDetails />
  }
  return <></>
}
export default Details

Details.getLayout = function GetLayout (page) {
  const { query: { billDetails } } = useRouter()
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={billDetails.length === 2 ? t('资源账单详情') : t('账单详情') } isContentHeader={billDetails.length === 2 ? true : false }>{page}</ExpenseCenter>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}
