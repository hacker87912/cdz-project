import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import ExpenseCenter from '@/pages/expense'
import { SpaceBetweenBox } from '@/components/common'
import { Justify, DatePicker, Button, Table, Card, Select, Text } from "tea-component"
import moment from "moment"
import Link from 'next/link'

const { RangePicker } = DatePicker
const { pageable } = Table.addons

const cvmList = [
  {
    id: "11111",
    billingMonth: '账单月份1',
    allCost: "总费用1",
    cdzCost: "CDZ费用1",
    cdzCostNo: "非CDZ费用1",
    state: "状态1",
  },
  {
    id: "22222",
    billingMonth: '账单月份2',
    allCost: "总费用2",
    cdzCost: "CDZ费用2",
    cdzCostNo: "非CDZ费用2",
    state: "状态2",
  },
]

function BillList () {
  const { t } = useTranslation('common')
  const operation = (record) => {
    return (
      <SpaceBetweenBox>
        <Link href={`/expense/bill/${record.id}`}><Text theme="primary">{t('账单详情')}</Text></Link>
        <Link href={``}><Text theme="primary">{t('下载账单')}</Text></Link>
      </SpaceBetweenBox>
    )
  }
  return (
    <>
      <Card>
        <Card.Body>
          <Justify
            left={
              <SpaceBetweenBox>
                <RangePicker
                  defaultValue={[moment("2020-10-01"), moment("2020-11-11")]}
                  onChange={value =>
                    console.log(
                      value[0].format("YYYY/MM/DD"),
                      value[1].format("YYYY/MM/DD")
                    )
                  }
                  onOpenChange={open => console.log(open ? "open" : "close")}
                />
                <Select
                  size='s'
                  matchButtonWidth
                  appearance="button"
                  options={[{ value: "0", text: "未结算" }, { value: "1", text: "已结算" }]}
                  placeholder='结算状态'
                  // value={trendSelect}
                  // onChange={value => setTrendSelect(value)}
                />
              </SpaceBetweenBox>
            }
            right={
              <Button icon="download" />
            }
          />

          <SpaceBetweenBox boxTop='10px'>
            <Table
              verticalTop
              bordered
              records={cvmList}
              recordKey="id"
              columns={[
                {
                  key: "billingMonth",
                  header: "账单月份",
                },
                {
                  key: "allCost",
                  header: '总费用',
                },
                {
                  key: "cdzCost",
                  header: "CDZ费用",
                },
                {
                  key: "cdzCostNo",
                  header: "非CDZ费用",
                },
                {
                  key: "state",
                  header: "状态",
                },
                {
                  key: "operation",
                  header: "操作",
                  render: operation
                },
              ]}
              addons={[pageable()]}
            />
          </SpaceBetweenBox>
        </Card.Body>
      </Card>
    </>
  )
}
export default BillList

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}

BillList.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('账单列表')}>{page}</ExpenseCenter>
  )
}

