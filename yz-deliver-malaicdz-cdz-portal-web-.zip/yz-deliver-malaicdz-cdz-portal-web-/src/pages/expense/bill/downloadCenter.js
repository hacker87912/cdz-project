import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import ExpenseCenter from '@/pages/expense'
import { SpaceBetweenBox } from '@/components/common'
import { DatePicker, Button, Card, Tabs, TabPanel, Alert } from "tea-component"
import moment from "moment"

const { MonthPicker } = DatePicker
function DownloadCenter () {
  const downChildren = () => {
    return (
      <>
        <Alert>L0-PDF账单为PDF版电子账单，方便用户财务请款或留档。</Alert>
        <SpaceBetweenBox vertical marginTop='20px'>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <span style={{ marginRight: '20px', color: 'rgba(0,0,0,.4)' }}>账期</span>
            <div>
              <MonthPicker
                defaultValue={moment("2020-10-01")}
                range={[moment("2019-09"), moment("2020-12")]}
                onChange={value => console.log(value.format("YYYY/MM/DD"))}
              />
              <span style={{ margin: '0 5px' }}>至</span>
              <MonthPicker
                defaultValue={moment("2020-10-01")}
                range={[moment("2019-09"), moment("2020-12")]}
                onChange={value => console.log(value.format("YYYY/MM/DD"))}
              />
            </div>
          </div>
          <div>
            <span style={{ marginRight: '20px', color: 'rgba(0,0,0,.4)' }}>账号</span>
            <span>九月(100023126844)</span>
          </div>
          <Button type='primary' style={{ marginLeft: '44px' }}>下载</Button>
        </SpaceBetweenBox>
      </>
    )
  }
  const tabs = [
    { id: "0", label: "L0-PDF账单", children: downChildren() },
    { id: "1", label: "L1-多维度汇总账单", children: downChildren() },
    { id: "2", label: "L2-资源账单", children: downChildren() },
    { id: "3", label: "L3-明细账单", children: () => 3 },
  ]
  return (
    <>
      <Card>
        <Card.Body style={{ padding: '64px 0 64px 48px' }}>
          <div style={{ fontSize: '20px' }}>下载包含L0-PDF账单、L1-多维度汇总账单、L2-资源账单、L3-明细账单</div>
          <Button style={{ marginTop: '33px' }} type='primary'>账单包下载</Button>
        </Card.Body>
      </Card>
      <Card>
        <Card.Body>
          <Tabs tabs={tabs} style={{ marginTop: '10px' }}>
            {tabs.map(e => (
              <TabPanel id={e.id} key={e.id}>{e.children}</TabPanel>
            ))}
          </Tabs>
        </Card.Body>
      </Card>
    </>
  )
}
export default DownloadCenter

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}

DownloadCenter.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('账单下载中心')}>{page}</ExpenseCenter>
  )
}

