import { useState } from 'react'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import ExpenseCenter from '@/pages/expense'
import { SpaceBetweenBox } from '@/components/common'
import { Card, H3, Layout, DatePicker, Icon, Bubble, Segment, Row, Col, Justify, Select, Button, Tabs, TabPanel, Table } from 'tea-component'
import { BasicBar } from 'tea-chart'
import styles from './index.module.scss'
import moment from "moment"
import BasicPieBox from '@/components/chart/basicPie'

const { Header, Body } = Layout.Content
const { MonthPicker } = DatePicker
const { pageable } = Table.addons

const cvmList = [
  {
    id: "11111",
    produceName: '产品名称1',
    totalPrice: "优惠后总价（不含税）1",
    voucher: "代金卷支出1",
    deductTheTax: "扣税1",
    cashOutlay: "现金支出1",
  },
  {
    id: "22222",
    produceName: '产品名称2',
    totalPrice: "优惠后总价（不含税）2",
    voucher: "代金卷支出2",
    deductTheTax: "扣税2",
    cashOutlay: "现金支出2",
  },
]

const trendList = [
  {
    id: "11111",
    billingMonth: '账单月份1',
    allCost: "总费用1",
    cdzCost: "CDZ费用1",
    cdzCostNo: "非CDZ费用1",
    state: "状态1",
  },
  {
    id: "22222",
    billingMonth: '账单月份2',
    allCost: "总费用2",
    cdzCost: "CDZ费用2",
    cdzCostNo: "非CDZ费用2",
    state: "状态2",
  },
]

function Overview () {
  const { t } = useTranslation('common')
  const [trendBtn, setTrendBtn] = useState('1')
  const [trendSelect, setTrendSelect] = useState('0')
  const [trendTableShow, setTrendTableShow] = useState(false)
  const subTitle = () => {
    return (
      <>
        <MonthPicker
          defaultValue={moment("2020-10-01")}
          range={[moment("2019-09"), moment("2020-12")]}
          onChange={value => console.log(value.format("YYYY/MM/DD"))}
        />
        <div style={{ marginLeft: '10px', display: 'inline-block' }}>
          <span>按计费周期（按资源使用时间统计生成月度账单）</span>

          <Bubble
            placement='bottom'
            content={
              <>
                <p>按计费周期：按资源使用时间统计生成月度账单。</p>
                <p style={{ color: '#888', marginTop: '10px' }}>如：您在1月31日23:00~23:59使用的按小时结算的按量计费资源，实际扣费时间发生在2月1日，则按计费周期，该笔费用统计到1月账单。</p>
              </>
            }
          >
            <Icon type="info" />
          </Bubble>
        </div>
      </>
    )
  }
  const tabs = [
    { id: "0", label: "按产品汇总" },
    { id: "1", label: "按可用区汇总" },
  ]
  const TrendTitle = <H3>费用趋势<em className={styles['unit']}>（单位：美元）</em></H3>
  return (
    <>
      <Header
        title={t('费用账单概览')}
        subtitle={<>{subTitle()}</>}
      />
      <Body>
        <Card>
          <Card.Body>
            {!trendTableShow && (
              <Row>
                <Col span={18}>
                  <Justify
                    left={TrendTitle}
                    right={<>
                      <Segment
                        value={trendBtn}
                        onChange={value => setTrendBtn(value)}
                        options={[
                          { text: "近半年", value: "1" },
                          { text: "近一年", value: "2" },
                        ]}
                      />
                      <Select
                        size='s'
                        matchButtonWidth
                        appearance="button"
                        options={[{ value: "0", text: "总费用" }, { value: "1", text: "CDZ费用" }, { value: "2", text: "非CDZ费用" }]}
                        value={trendSelect}
                        onChange={value => setTrendSelect(value)}
                      />
                    </>}
                  />
                  <BasicBar
                    height={250}
                    position='week*value'
                    dataSource={[
                      { week: "2022-03", value: 10 },
                      { week: "2022-04", value: 20 },
                      { week: "2022-05", value: 50 },
                      { week: "2022-06", value: 60 },
                      { week: "2022-07", value: 20 },
                      { week: "2022-08", value: 72 },
                      { week: "2022-09", value: 98 },
                    ]}
                  />

                </Col>
                <Col span={6} style={{ borderLeft: '1px solid #ddd' }}>
                  <div style={{ textAlign: 'end' }}>
                    <Button icon="chart-line" />
                    <Button icon="datasheet" onClick={() => { setTrendTableShow(true) }} />
                  </div>
                  <div style={{ fontSize: '16px', color: '#000', marginBottom: '30px' }}>2023年3月（未出账）<Bubble
                    placement='top'
                    content={
                      <>
                        <p>次月1号出账</p>
                      </>
                    }
                  >
                    <Icon type="info" />
                  </Bubble>
                  </div>
                  <CountShow data={[{ label: '总费用', con: '3', slice: '=', color: '#006EFF' }, { label: 'CDZ费用', con: '2', slice: '+' }, { label: '非CDZ费用', con: '1', slice: '+' }]} />
                </Col>
              </Row>
            )}
            {trendTableShow && (
              <>
                <Justify
                  left={TrendTitle}
                  right={<>
                    <Button icon="chart-line" onClick={() => { setTrendTableShow(false) }} />
                    <Button icon="datasheet" />
                    <Button icon="download" />
                  </>}
                />
                <SpaceBetweenBox boxTop='18px'>
                  <Table
                    verticalTop
                    records={trendList}
                    recordKey="id"
                    columns={[
                      {
                        key: "billingMonth",
                        header: "账单月份",
                      },
                      {
                        key: "allCost",
                        header: '总费用',
                      },
                      {
                        key: "cdzCost",
                        header: "CDZ费用",
                      },
                      {
                        key: "cdzCostNo",
                        header: "非CDZ费用",
                      },
                      {
                        key: "state",
                        header: "状态",
                      },
                    ]}
                  />
                </SpaceBetweenBox>

              </>
            )}
          </Card.Body>
        </Card>
        <Card>
          <Card.Body>
            <H3>2023年2月账单汇总<em className={styles['unit']}>（单位：美元）</em></H3>
            <Tabs tabs={tabs} style={{ marginTop: '10px' }}>
              <TabPanel id="0"><div style={{ width: '700px', margin: '0 auto' }}><BasicPieBox /></div></TabPanel>
              <TabPanel id="1"><div style={{ width: '700px', margin: '0 auto' }}><BasicPieBox dataLabels legend={{ enable: false }} /></div></TabPanel>
            </Tabs>
            <Table
              verticalTop
              records={cvmList}
              recordKey="id"
              columns={[
                {
                  key: "produceName",
                  header: "产品名称",
                },
                {
                  key: "totalPrice",
                  header: '优惠后总价（不含税）',
                },
                {
                  key: "voucher",
                  header: "代金卷支出",
                },
                {
                  key: "deductTheTax",
                  header: "扣税",
                },
                {
                  key: "cashOutlay",
                  header: "现金支出",
                },
              ]}
              addons={[pageable()]}
            />
          </Card.Body>
        </Card>
      </Body>
    </>
  )
}
export default Overview

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}

Overview.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('费用账单概览')} isContentHeader={false}>{page}</ExpenseCenter>
  )
}

function CountShow ({ data }) {
  return (
    <div className={styles['count-list']}>
      <div className={styles['count-item']}>
        <div className={styles['count-label']}>统计周期</div>
        <div className={styles['count-con']}>按计费周期</div>
      </div>
      {data.map((e, i) => (
        <div className={styles['count-item']} key={e.label}>
          <div className={styles['count-label']}>{e.label}</div>
          <div className={styles['count-con']} style={{ color: e.color }}>{e.con}美元</div>
          {i !== data.length - 1 && <div className={styles['count-slice']}>{e.slice}</div>}
        </div>
      ))}
    </div>
  )
}

