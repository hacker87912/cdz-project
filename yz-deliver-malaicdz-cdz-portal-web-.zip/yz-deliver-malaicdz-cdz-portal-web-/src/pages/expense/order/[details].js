import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import ExpenseCenter from '@/pages/expense'
import { Line, ShowInfo, SpaceBetweenBox } from '@/components/common'
import { Icon, Text, H2, Table, Card } from "tea-component"

const { pageable } = Table.addons

const cvmList = [
  {
    id: "11111",
    subOrder: '子订单号1',
    product: "产品1",
    specification: "规格1",
    number: "数量1",
    paymentMethod: "付款方式1",
    orderAmount: "订单金额1",
  },
  {
    id: "2222",
    subOrder: '子订单号2',
    product: "产品2",
    specification: "规格2",
    number: "数量2",
    paymentMethod: "付款方式2",
    orderAmount: "订单金额2",
  },
]
function Details () {
  const { t } = useTranslation('common')
  return (
    <Card>
      <Card.Body>
        <Icon type="success" size="l" />
        <Text theme="success" verticalAlign="middle" style={{ fontSize: '18px', fontWeight: 'bold', marginLeft: '10px' }}>{t('处理成功')}</Text>
        <Line />
        <ShowInfo info={{ 'CZD订单': '20210517281003598415611', '订单类型': '新购', '订单创建人': 'xxx', '创建时间': '2021-05-17 12:33:48' }} />
        <SpaceBetweenBox boxTop='20px' vertical>
          <H2 style={{ fontSize: '16px' }}>{t('订单信息')}</H2>
          <Table
            verticalTop
            bordered
            records={cvmList}
            recordKey="id"
            columns={[
              {
                key: "subOrder",
                header: "子订单号",
              },
              {
                key: "product",
                header: '产品',
                width: 100,
              },
              {
                key: "specification",
                header: "规格",
              },
              {
                key: "number",
                header: "数量",
              },
              {
                key: "paymentMethod",
                header: "付款方式",
              },
              {
                key: "orderAmount",
                header: "订单金额",
              },
            ]}
            addons={[pageable()]}
          />
        </SpaceBetweenBox>
      </Card.Body>
    </Card>
  )
}
export default Details

Details.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('订单详情')}>{page}</ExpenseCenter>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}
