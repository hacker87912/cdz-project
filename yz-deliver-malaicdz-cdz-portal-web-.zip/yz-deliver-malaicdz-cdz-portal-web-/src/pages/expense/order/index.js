import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import ExpenseCenter from '@/pages/expense'
import { SpaceBetweenBox } from '@/components/common'
import { SearchBox, Justify, DatePicker, Button, Table, Card, Text } from "tea-component"
import moment from "moment"
import Link from 'next/link'
// import styles from './index.module.scss'

const { MonthPicker } = DatePicker
const { pageable } = Table.addons

const cvmList = [
  {
    id: "11111",
    number: '1',
    orderNumber: "22223",
    product: "产品1",
    subProduct: "子产品1",
    type: "类型1",
    state: "状态1",
    orderCreationTime: '2023-03-08 15:19:56',
  },
  {
    id: "2222",
    number: '2',
    orderNumber: "33333",
    product: "产品2",
    subProduct: "子产品2",
    type: "类型2",
    state: "状态2",
    orderCreationTime: '2023-03-08 15:19:56',
  },
]

function OrderList () {
  const { t } = useTranslation('common')
  const operation = (record) => {
    return <Link href={`/expense/order/${record.number}`}><Text theme="primary">{t('详情')}</Text></Link>
  }
  return (
    <Card>
      <Card.Body>
        <Justify
          left={
            <SpaceBetweenBox>
              <MonthPicker
                defaultValue={moment("2020-10-01")}
                range={[moment("2019-09"), moment("2020-12")]}
                onChange={value => console.log(value.format("YYYY/MM/DD"))}
              />
              <SearchBox size='m' />
              <Button type="text" style={{ color: '#378EFF' }}>{t('重置')}</Button>
            </SpaceBetweenBox>
          }
          right={
            <Button icon="download" />
          }
        />

        <SpaceBetweenBox boxTop='10px'>
          <Table
            verticalTop
            bordered
            records={cvmList}
            recordKey="id"
            columns={[
              {
                key: "number",
                header: "序号",
              },
              {
                key: "orderNumber",
                header: '订单号',
                width: 100,
              },
              {
                key: "product",
                header: "产品",
              },
              {
                key: "subProduct",
                header: "子产品",
              },
              {
                key: "type",
                header: "类型",
              },
              {
                key: "state",
                header: "状态",
              },
              {
                key: "orderCreationTime",
                header: "订单创建时间",
              },
              {
                key: "operation",
                header: "操作",
                render: operation
              },
            ]}
            addons={[pageable()]}
          />
        </SpaceBetweenBox>
      </Card.Body>
    </Card>
  )
}
export default OrderList
OrderList.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')
  return (
    <ExpenseCenter headTitle={t('订单列表')}>{page}</ExpenseCenter>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}
