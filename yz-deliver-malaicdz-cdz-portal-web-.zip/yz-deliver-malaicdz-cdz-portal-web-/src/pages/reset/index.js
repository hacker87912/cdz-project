import React, { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import PageLayout from '@/components/layout'
import { Button, Form, Input, Modal } from 'antd'
import { CheckCircleOutlined } from '@ant-design/icons'
import * as API from '@/services'
import styles from './index.module.scss'

const Reset = function () {
  const { t } = useTranslation('common')
  const [showCap, setShowCap] = useState(false)
  const [forceRender, setForceRender] = useState(false)
  const [email, setEmail] = useState('')
  useEffect(() => {
    setForceRender(true)
  }, [])

  // 初始化验证码
  const initCap = (mail) => {
    window.jigsaw?.init({
      el: document.getElementById('reset_captcha'),
      async onSuccess () {
        const res = await API.resetPasswordEmail({ resetPasswordEmail: mail })
        if (res.code === 0) {
          setEmail(mail)
        }
        cancelCap()
      },
      onFail: null,
      onRefresh: null
    })
  }
  // 点击下一步
  const handleOnFinish = async (values) => {
    setShowCap(true)
    initCap(values.resetPasswordEmail)
  }
  // 取消验证码弹框
  const cancelCap = () => {
    document.getElementById('reset_captcha').innerHTML = ''
    setShowCap(false)
  }
  // 打开邮箱登录
  // const gotoMail = () => {
  //   const mailHost = email.split('@')[1]
  //   const mailUrl = `https://mail.${mailHost}`
  //   window.open(mailUrl, '-')
  // }
  return (
    <PageLayout title={t('忘记密码')}>
      <div className={styles['reset-body']}>
        <div className={styles['reset-title']}>{t('忘记密码')}</div>
        <div className={styles['reset-form-container']}>
          {
            email ? (
              <Form
                className={styles['reset-form']}
              >
                <Form.Item>
                  <h1 className={styles['reset-title']} style={{color: '#00a4ff', fontSize: '26px'}}>
                    <CheckCircleOutlined />
                    <span>{t('已发送密码重设邮件')}</span>
                  </h1>
                </Form.Item>
                <Form.Item>
                  <h1 className={styles['reset-title']}>{`${t('已发送至您的注册邮箱')}: ${email} ${t('请查看邮件并根据提示进行操作')}`}</h1>
                </Form.Item>
                {/* <Form.Item>
                  <Button
                    type='primary'
                    block
                    style={{ height: '48px' }}
                    className={styles['reset-form-button']}
                    onClick={gotoMail}
                  >
                    {t('前往邮箱')}
                  </Button>
                </Form.Item> */}
              </Form>
            ) : (
              <Form
                className={styles['reset-form']}
                onFinish={handleOnFinish}
              >
                <Form.Item>
                  <p className={styles['reset-tip']}>{t('请输入登录账号的邮箱重设登录密码')}</p>
                </Form.Item>
                <Form.Item
                  name='resetPasswordEmail'
                  rules={[
                    {
                      required: true,
                      message: t('请输入邮箱'),
                    },
                    {
                      type: 'email',
                      message: t('邮箱格式不正确'),
                    },
                  ]}
                >
                  <Input
                    size='large'
                    placeholder={t('邮箱地址')}
                    className={styles['reset-form-input']}
                  />
                </Form.Item>
                <Form.Item>
                  <Button
                    type='primary'
                    block
                    style={{height: '48px'}}
                    htmlType='submit'
                    className={styles['reset-form-button']}
                  >
                    {t('下一步')}
                  </Button>
                </Form.Item>
              </Form>
            )
          }
        </div>
      </div>
      <Modal
        className={styles['sort-modal']}
        footer={null}
        keyboard={false}
        maskClosable={false}
        forceRender={forceRender}
        open={showCap}
        onCancel={cancelCap}
        width={410}
      >
        <div id='reset_captcha'></div>
      </Modal>
    </PageLayout>
  )
}

export default Reset

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common']))
    }
  }
}
