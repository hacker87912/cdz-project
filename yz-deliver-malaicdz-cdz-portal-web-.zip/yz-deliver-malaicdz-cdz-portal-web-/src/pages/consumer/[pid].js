import React from 'react'
import { observer } from 'mobx-react-lite'
import Image from 'next/image'
import PageLayout from '@/components/layout'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import televisionImg from '@/assets/img/television.png'
import * as API from '@/services'

const ConsumerDetail = ({ data = {} })=> {
  const { t } = useTranslation('common')
  return     <PageLayout title={t('客户详情')}>
    <div className={styles['page-consumerdetail']}>
      {/* 头部区域 */}
      <div className={styles['header-banner']}>
        <div className={styles['container']}>
          <div className={styles['container-left']}>
            <div className={styles['title']}>
              <span>{data.title}</span>
            </div>
          </div>
          <div className={styles['container-right']}>
            <Image alt='promotion' src={televisionImg} />
          </div>
        </div>
      </div>
      <div className={styles['content']}>
        {/* <Descriptions className={styles['descriptions']} title={t('客户详情')} column={1}>
          <div>
            {consumerData.detail}
          </div>
        </Descriptions> */}
        <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>{t('内容说明')}</h1>
        <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.detail }}></div>
      </div>
    </div>
  </PageLayout>
}

export default observer(ConsumerDetail)

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  const { pid } = context.query
  const { data = {} } = await API.getCustomerDetail({ id: pid }, context)
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
      data
    }
  }
}
