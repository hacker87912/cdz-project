import React, { useEffect, useState, useRef, useMemo } from 'react'
import { useRouter } from 'next/router'
import { useTranslation } from 'next-i18next'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import PageLayout from '@/components/layout'
import { Button, Form, Input, Modal, Row, message } from 'antd'
import * as API from '@/services'
import styles from './index.module.scss'

const ResetPassword = function () {
  const { t } = useTranslation('common')
  const [open, setOpen] = useState(false)
  const [send, setSend] = useState(false)
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [email, setEmail] = useState('')
  const [accountId, setAccountId] = useState('')
  const downTime = useRef(60)
  const [timeStr, setTimeStr] = useState(60)
  const timer = useRef(null)
  const [form] = Form.useForm()
  const router = useRouter()
  useEffect(() => {
    getValidEmail()
  }, [])

  // 根据code验证账户
  const getValidEmail = async () => {
    const res = await API.checkCode({ code: router.query?.code })
    if (res.code === 0) {
      setEmail(res.data?.loginAccount)
      setAccountId(res.data?.id)
    } else {
      setEmail('error')
    }
  }
  // 填写完密码下一步
  const handleOnFinish = (values) => {
    setNewPassword(values.newPassword)
    setConfirmPassword(values.confirmPassword)
    setOpen(true)
  }
  // 发送验证码
  const sendValidateCode = async () => {
    const res = await API.verificationCode({ id: accountId })
    if (res.code === 0) {
      setSend(true)
      let timerInterval = setInterval(() => {
        if (downTime.current === 0) {
          setSend(false)
          clearInterval(timer.current)
          downTime.current = 60
        } else {
          downTime.current = downTime.current - 1
          setTimeStr(downTime.current)
        }
      }, 1000)
      timer.current = timerInterval
    }
  }
  // 提交数据
  const submitResetPassword = async () => {
    const postData = {
      id: accountId,
      newPassword,
      confirmPassword,
      verificationCode: form.getFieldValue('validCode')
    }
    const res = await API.resetSubmit(postData)
    if (res.code === 0) {
      message.success(t('重置密码成功'))
      router.push('/login')
    }

  }
  // 点击确定弹框
  const handleOk = () => {
    form.validateFields().then(() => {
      submitResetPassword()
    })
  }

  return (
    <PageLayout title={t('设置新密码')}>
      <div className={styles['reset-body']}>
        <div className={styles['reset-form-container']}>
          {
            email !== '' && email !== 'error' && (
              <Form
                className={styles['reset-form']}
                onFinish={handleOnFinish}
              >
                <Form.Item>
                  <h1 className={styles['reset-title']}>{t('请输入新密码，以进行密码重设')}</h1>
                </Form.Item>
                <Form.Item
                  name='newPassword'
                  rules={[
                    {
                      required: true,
                      message: t('请输入新密码'),
                    },
                    {
                      pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])(.{8,30})$/,
                      message: t('密码为字母+数字组合，长度8到30位'),
                    },
                  ]}
                >
                  <Input
                    size='large'
                    type='password'
                    placeholder={t('请输入新密码')}
                    className={styles['reset-form-input']}
                  />
                </Form.Item>
                <Form.Item
                  name='confirmPassword'
                  rules={[
                    {
                      required: true,
                      message: t('请输入确认密码'),
                    },
                    {
                      pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])(.{8,30})$/,
                      message: t('密码为字母+数字组合，长度8到30位'),
                    },
                    ({ getFieldValue }) => ({
                      validator (_, value) {
                        if (!value || getFieldValue('newPassword') === value) {
                          return Promise.resolve()
                        }
                        return Promise.reject(new Error(t('两次输入的密码不一致')))
                      },
                    })
                  ]}
                >
                  <Input
                    size='large'
                    type='password'
                    placeholder={t('请输入确认密码')}
                    className={styles['reset-form-input']}
                  />
                </Form.Item>
                <Form.Item>
                  <Button
                    type='primary'
                    block
                    style={{height: '48px'}}
                    htmlType='submit'
                    className={styles['reset-form-button']}
                  >
                    {t('提交')}
                  </Button>
                </Form.Item>
              </Form>

            )
          }
          {
            email === 'error' && (
              <Form
                className={styles['reset-form']}
                onFinish={handleOnFinish}
              >
                <Form.Item>
                  <h1 className={styles['reset-title']}>{t('该重置密码链接已失效，请重新触发获取最新的密码重置邮件～')}</h1>
                </Form.Item>
              </Form>
            )
          }
          <Modal
            className={styles['valid-modal']}
            title={t('身份验证')}
            open={open}
            onOk={handleOk}
            onCancel={() => setOpen(false)}
            width={500}
          >
            <Form
              form={form}
              name='sortForm'
              labelCol={{
                span: 5,
              }}
              wrapperCol={{
                span: 16,
              }}
            >
              <Form.Item
                label={t('验证方式')}
              >
                <span>{t('邮箱验证')}</span>
              </Form.Item>
              <Form.Item
                label={t('安全邮箱')}
              >
                <span>{email.replace(/(\w{1}).*(\w{1})@(.*)/, "$1***$2@$3")}</span>
              </Form.Item>
              <Row>
                <Form.Item
                  label={t('验证码')}
                  name='validCode'
                  rules={[
                    {
                      required: true,
                      message: t('请输入验证码'),
                    },
                  ]}
                  className={styles['valid-code']}
                >
                  <Input placeholder={t('输入6位数字')} />
                </Form.Item>
                <Button
                  type='primary'
                  style={{ marginLeft: '10px' }}
                  onClick={sendValidateCode}
                  disabled={send}
                >
                  {send ? `${timeStr}s${t('重新发送')}` : t('获取验证码')}
                </Button>
              </Row>

            </Form>
          </Modal>
        </div>
      </div>


    </PageLayout>
  )
}

export default ResetPassword

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common']))
    }
  }
}
