import { useRouter } from 'next/router'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import PageLayout from '@/components/layout'
import { useTranslation } from 'next-i18next'
import Image from 'next/image'
import productBanner from '@/assets/img/product_banner.png'
import styles from './index.module.scss'
import * as API from '@/services'
import { Button } from 'antd'

function ProductDetails ({ data }) {
  const router = useRouter()
  const { t } = useTranslation('common')
  return (
    <PageLayout title={t('产品详情')}>
      <div className={styles['product-banner-container']}>
        <div className={styles['banner-inner']}>
          <div className={styles['banner-detail-inner-box']}>
            <div className={styles['banner-left']}>
              <div className={styles['banner-text']}>
                <h1>{data.title}</h1>
                <h2>{data.description}</h2>
                <div style={{ marginTop: '24px' }}>
                  <ul className={styles['product-detail-ul']}>
                    {data.tipList.map(e => (
                      <li key={e.name}>
                        <Button type={e.type || 'default'} onClick={() => router.push(e.url)}>{t(e.name)}</Button>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
            <div className={styles['banner-right']}>
              <div><Image src={productBanner} alt='' fill /></div>
            </div>
          </div>
        </div>
      </div>
      <div style={{ padding: '24px', backgroundColor: '#fff' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>{t('内容说明')}</h1>
        <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: data.content }}></div>
      </div>
    </PageLayout>
  )
}
export default ProductDetails

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  const { pid } = context.query
  const { data = {} } = await API.getProductDetail({ id: pid }, context)
  console.log(data)
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
      data: {
        title: data.title,
        description: data.subTitle,
        tipList: [{ name: '立即购买', url: data.buyNowUrl || '/', type: 'primary' }, { name: '联系销售', url: '/contactus' }, { name: '文档', url: data.fileUrl }, { name: '了解更多', url: data.moreUrl }],
        content: data.detail
      }
    }
  }
}
