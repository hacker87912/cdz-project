import React, { useEffect, useState, useMemo } from 'react'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import PageLayout from '@/components/layout'
import Image from 'next/image'
import productBanner from '@/assets/img/product_banner.png'
import { SearchOutlined, CaretDownOutlined, CaretUpOutlined } from '@ant-design/icons'
import { Affix } from 'antd'
import styles from './index.module.scss'
import * as API from '@/services'
import { useRouter } from 'next/router'

function Product ({ data }) {
  const { t } = useTranslation('common')
  const router = useRouter()
  const [resize, setResize] = useState(null)
  const [menuMobileOpen, setMenuMobileOpen] = useState('')
  const [searchData, setSearchData] = useState([])
  const [searchValue, setSearchValue] = useState('')
  const [searchBlur, setSearchBlur] = useState(true)

  const menuClick = (index) => {
    const element = document.getElementById(`product-card-${index}`)
    element.scrollIntoView({ behavior: 'smooth' })
  }
  const pcResize = useMemo(() => resize > 768, [resize])
  useEffect(() => {
    let oldIndex = 0
    const cardTopNum = Array(data.length).fill().map((_, i) => document.getElementById(`product-card-${i}`).offsetParent.offsetTop)
    const num = resize > 768 ? 420 : 436
    document.body.onscroll = () => {
      const scrollTop = document.documentElement.scrollTop - num
      const index = cardTopNum.findIndex((e) => (e >= scrollTop))
      if (resize > 768 && index > -1) {
        const element = document.getElementById(`product-item-${index}`)
        const oldDom = document.getElementById(`product-item-${oldIndex}`)
        oldDom?.setAttribute('style', 'color: rgba(0, 0, 0, 0.6); font-weight: initial')
        element?.setAttribute('style', 'color: #006eff; font-weight: 700')
        oldIndex = index
      }
      if (index > -1 && resize <= 768 || scrollTop === -436) {
        const menuItemDom = document.getElementById(`product-menu-${index}`)
        const oldDom = document.getElementById(`product-menu-${oldIndex}`)
        if (scrollTop === -436) {
          const initMenuItemDom = document.getElementById(`product-menu-${0}`)
          initMenuItemDom?.setAttribute('style', 'visibility: hidden;')
          menuMobileOpen && setMenuMobileOpen('')
          oldIndex = 0
        } else {
          oldDom?.setAttribute('style', 'visibility: hidden;')
          menuItemDom?.setAttribute('style', 'visibility: visible;')
          oldIndex = index
        }
      }
    }
  }, [data, resize, menuMobileOpen])
  const debounce = (func, wait) => {
    let timeout
    return function () {
      clearTimeout(timeout)
      timeout = setTimeout(func, wait)
    }
  }
  const getSize = () => {
    setResize(window.innerWidth)
  }
  useEffect(() => {
    window.addEventListener('resize', debounce(getSize, 500), [])
    setResize(window.innerWidth)
  }, [])
  const menuMobileClick = (state, name) => {
    if (state) {
      setMenuMobileOpen('')
    } else {
      setMenuMobileOpen(name)
    }
  }


  const getSearchData = async () => {
    const { data = [] } = await API.getProductList({classify: '', keyword: searchValue})
    setSearchData(data)
  }

  const searchClick = async () => {
    getSearchData()
  }
  const onKeyDown = async (e) => {
    if (e.keyCode === 13) {
      getSearchData()
    }
  }
  const onBlur = () => {
    setTimeout(() => {
      setSearchBlur(false)
      setSearchValue('')
    }, 200)
  }

  const link = (pathname) => {
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}${pathname}`
  }
  return (
    <PageLayout title={t('产品')}>
      <div className={styles['product-banner-container']}>
        <div className={styles['banner-inner']}>
          <div className={styles['banner-left']}>
            <div className={styles['banner-text']}>
              <h1>{t('产品与服务')}</h1>
              <h2>{t('探索不断扩展的CZD产品和服务，并开始在CZD中建立您的业务')}</h2>
              <div className={styles['banner-search']}>
                <div className={styles['banner-search-bar']}>
                  <input placeholder={t('搜索云产品')} onKeyDown={onKeyDown} value={searchValue} onChange={(e) => setSearchValue(e.target.value)} onBlur={onBlur} onFocus={() => setSearchBlur(true)} />
                  <div className={styles['banner-search-icon']}><SearchOutlined onClick={searchClick} /></div>
                  {searchData?.length > 0 && searchBlur && (
                    <div className={styles['banner-search-bar-box']}>
                      <ul>
                        {searchData?.map(e => (<li key={e.id}>
                          <a onClick={() => link(`/product/${e.id}`)}>{e.title}</a>
                        </li>))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
              {/* <div className={styles['search-tip']}>
                <ul className={styles['tip-list']}>
                  {data.tipList.map(e => (
                    <li className={styles['tip-item']} key={e.id}>
                      <Link className={styles['tip-link']} href={`/product/${e.id}`}>{e.name}</Link>
                    </li>
                  ))}
                </ul>
              </div> */}
            </div>
          </div>
          <div className={styles['banner-right']}>
            <div><Image src={productBanner} alt='' fill /></div>
          </div>
        </div>
      </div>
      <div className={styles['product-list']}>
        <Affix offsetTop={60}>
          <div className={styles['list-left']}>
            <ul>
              {data.map((e, i) => (<li key={e.name} className={styles['list-left-item']}><span onClick={() => menuClick(i)} id={`product-item-${i}`} title={e.name}>{e.name}</span></li>))}
            </ul>
          </div>
        </Affix>
        <div className={styles['list-right']}>
          {data.map((e, index) => (
            <React.Fragment key={e.name}>
              {!pcResize && <div
                id={`product-menu-${index}`}
                className={styles['list-left-mobile']}
              >
                <span
                  className={styles['menu-box-mobile']}
                  onClick={() => menuMobileClick(menuMobileOpen, e.name)}
                >
                  <h3>{e.name}</h3>
                  {menuMobileOpen ? <CaretUpOutlined /> : <CaretDownOutlined />}
                </span>
              </div>}
              <div className={styles['card-container']}>
                <div className={styles['empty-box']} id={`product-card-${index}`}></div>
                {e.data.map((v) => (
                  <div key={v.id} className={styles['card-item']}>
                    <a onClick={() => link(`/product/${v.id}`)}>
                      <>
                        <h1 style={{ display: 'inline-block' }}>{v.title}</h1>
                        <br/>
                        <span>{v.subTitle}</span>
                      </>
                    </a>
                  </div>
                ))}
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
      {menuMobileOpen && <MobileMenuHeader open={menuMobileOpen} data={data} menuClick={menuClick} setOpen={setMenuMobileOpen} />}
    </PageLayout>
  )
}
export default Product

function MobileMenuHeader ({ open, data, menuClick, setOpen }) {
  return (
    <>
      {open && <div className={styles['product-menu-m']}>
        <ul>
          {data.map((e, i) => (
            <li key={e.name}><span style={{ color: open === e.name ? '#006eff' : 'hsla(0,0%,100%,.8)'}} onClick={() => {menuClick(i); setOpen('')}}>{e.name}</span></li>
          ))}
        </ul>
      </div>}
    </>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  const { data: classifyData = [] } = await API.getProductClassify({}, context)
  const res = await Promise.all(
    classifyData.map(e => (
      API.getProductList({classify: e.id, keyword: ''}, context)
    ))
  )
  const data = res?.map((e, i) => {
    const { data = [] } = e
    return { name: classifyData[i].name, data }
  }) || []
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
      data: data
    }
  }
}
