import React, { useState, useEffect } from "react"
import { useTranslation } from 'next-i18next'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import AccountCenter from '@/pages/account'
import { getAccountInfo, getDicData, editAccountInfo } from '@/services'
import {
  Form,
  Input,
  Card,
  Select,
  Button,
  message,
  Row,
  Col
} from 'tea-component'
import styles from './index.module.scss'
import { isPhone, isEmail, isURL } from '@/utils/regExp'
import { getCookie } from '@/utils/storage'

function UserInfo () {
  const { t } = useTranslation('common')
  const [isEdit, setIsEdit] = useState(false)
  const [formData, setFormData] = useState({})
  const [formDataCopy, setFormDataCopy] = useState({})
  const [mainIndustryOptions, setMainIndustryOptions] = useState([])
  const [secondMainIndustryOptions, setSecondMainIndustryOptions] = useState([])
  useEffect(() => {
    getMainIndustryOptions()
    getAccountData()
  }, [])
  useEffect(() => {
    handleChangeSelectMainIndustry(formData.mainIndustry)
  }, [formData.mainIndustry])

  // 获取一级行业
  const getMainIndustryOptions = async () => {
    const res = await getDicData({ key: 'main_industry' })
    const industryData = res.data?.map(({ dictResponse, children }) => {
      const secondOptions = children.map(item => ({ text: item.label, value: `${item.id}` }))
      return ({ text: dictResponse.description, value: `${dictResponse.id}`, children: secondOptions })
    })
    setMainIndustryOptions(industryData || [])
  }
  // 获取二级行业
  const handleChangeSelectMainIndustry = (val) => {
    const secondOptions = mainIndustryOptions.find(item => item.value === val)?.children || []
    setSecondMainIndustryOptions(secondOptions)
  }
  // 获取用户信息
  const getAccountData = async () => {
    const res = await getAccountInfo({id: getCookie('accountId')})
    const accountInfo = res.data || {}
    setFormData(accountInfo)
    setFormDataCopy(accountInfo)
  }
  const handleChangeInput = (val, field) => {
    setFormData((e) => ({...e, [field]: val}))
  }
  // 提交编辑
  const submitForm = async () => {
    if (!formData.id ||
       !formData.accountName ||
       (formData.url && !isURL(formData.url)) ||
       (formData.contactEmail && !isEmail(formData.contactEmail)) ||
       (formData.contactPhone && !isPhone(formData.contactPhone))) return
    const res = await editAccountInfo(formData)
    if (res.code === 0) {
      message.success({ type: 'success', content: res.msg })
      setIsEdit(false)
      getAccountData()
    }
  }
  const cancel = () => {
    setFormData(formDataCopy)
    setIsEdit(false)
  }
  return (
    <>
      {
        isEdit || <div className={styles['user-info']}>
          <Card className={styles['card-user-box']}>
            <Card.Body>
              <Form.Title>{t('基本信息')}</Form.Title>
              <Form layout='inline'>
                <Row>
                  <Col span={12}>
                    <Form.Item label={t('账号ID')}>
                      <Form.Text>{formData.id}</Form.Text>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item label={t('主要行业应用')}>
                      <Form.Text>{formData.mainIndustryName}/{formData.secondMainIndustryName}</Form.Text>
                    </Form.Item>
                  </Col>
                </Row>
                <Row>
                  <Col span={12}>
                    <Form.Item label={t('账号名称')}>
                      <Form.Text>{formData.accountName}</Form.Text>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item label={t('主营业务')}>
                      <Form.Text>{formData.mainBusiness}</Form.Text>
                    </Form.Item>
                  </Col>
                </Row>
                <Form.Item label={t('网址')}>
                  <Form.Text>{formData.url}</Form.Text>
                </Form.Item>
              </Form>
              <hr />
              <Form.Title>{t('登录信息')}</Form.Title>
              <Form>
                <Form.Item label={t('账号电子邮件')}>
                  <Form.Text>{formData.loginAccount}</Form.Text>
                </Form.Item>
              </Form>
              <hr />
              <Form.Title>{t('联系信息')}</Form.Title>
              <Form layout='inline'>
                <Row>
                  <Col span={12}>
                    <Form.Item label={t('联系人')}>
                      <Form.Text>{formData.contactName}</Form.Text>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item label={t('联系人邮箱')}>
                      <Form.Text>{formData.contactEmail}</Form.Text>
                    </Form.Item>
                  </Col>
                </Row>
                <Row>
                  <Col span={12}>
                    <Form.Item label={t('联系人电话')}>
                      <Form.Text>{formData.contactPhone}</Form.Text>
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item label={t('联系人地址')}>
                      <Form.Text>{formData.contactAddress}</Form.Text>
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
              <Form.Action>
                <Button type="primary" onClick={() => setIsEdit(true)}>{t('编辑')}</Button>
              </Form.Action>
            </Card.Body>
          </Card>
        </div>
      }
      {
        isEdit && <div className={styles['user-form']}>
          <Card>
            <Card.Body>
              <Form.Title>{t('基本信息')}</Form.Title>
              <Form>
                <Form.Item
                  label={t('账号ID')}
                  required
                  status={formData.id ? '' : 'error'}
                  message={formData.id ? '' : t('账号ID不能为空')}
                >
                  <Input
                    disabled
                    placeholder={t('请输入账号ID')}
                    type='text'
                    value={formData.id}
                    onChange={(val) => handleChangeInput(val, 'id')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('账号名称')}
                  required
                  status={formData.accountName ? '' : 'error'}
                  message={formData.accountName ? '' : t('账号名称不能为空')}
                >
                  <Input
                    disabled
                    placeholder={t('请输入账号名称')}
                    type='text'
                    value={formData.accountName}
                    onChange={(val) => handleChangeInput(val, 'accountName')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('主要行业应用')}
                  // required
                  // status={formData.mainIndustry && formData.secondMainIndustry ? '' : 'error'}
                  // message={formData.mainIndustry && formData.secondMainIndustry ? '' : t('行业类型和应用类型不能为空')}
                >
                  <Select
                    clearable
                    appearance="button"
                    virtual={false}
                    options={mainIndustryOptions}
                    placeholder={t('请选择你的行业类型')}
                    style={{marginRight: 12, width: '144px'}}
                    value={formData.mainIndustry}
                    onChange={(e) => { handleChangeInput(e, 'mainIndustry'); handleChangeSelectMainIndustry(e); handleChangeInput('', 'secondMainIndustry') }}
                  />
                  <Select
                    clearable
                    appearance="button"
                    virtual={false}
                    options={secondMainIndustryOptions}
                    placeholder={t('请选择你的应用类型')}
                    value={formData.secondMainIndustry}
                    onChange={(val) => handleChangeInput(val, 'secondMainIndustry')}
                    style={{ width: '144px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('主营业务')}
                >
                  <Input
                    placeholder={t('请输入主营业务内容')}
                    type='text'
                    value={formData.mainBusiness}
                    onChange={(val) => handleChangeInput(val, 'mainBusiness')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('网址')}
                  status={formData.url ? isURL(formData.url) ? '' : 'error' : ''}
                  message={formData.url ? isURL(formData.url) ? '' : t('网址格式不正确') : ''}
                >
                  <Input
                    placeholder={t('请填写你的网站')}
                    type='text'
                    value={formData.url}
                    onChange={(val) => handleChangeInput(val, 'url')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
              </Form>
              <hr />
              <Form.Title>{t('登录信息')}</Form.Title>
              <Form>
                <Form.Item
                  label={t('账号')}
                  required
                  status={formData.loginAccount ? '' : 'error'}
                  message={formData.loginAccount ? '' : t('账号不能为空')}
                >
                  <Input
                    disabled
                    placeholder={t('请输入账号')}
                    type='text'
                    value={formData.loginAccount}
                    onChange={(val) => handleChangeInput(val, 'loginAccount')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
              </Form>
              <hr />
              <Form.Title>{t('联系信息')}</Form.Title>
              <Form>
                <Form.Item
                  label={t('联系人')}
                >
                  <Input
                    placeholder={t('联系人')}
                    type='text'
                    value={formData.contactName}
                    onChange={(val) => handleChangeInput(val, 'contactName')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('联系人电话')}
                  status={formData.contactPhone ? isPhone(formData.contactPhone) ? '' : 'error' : ''}
                  message={formData.contactPhone ? isPhone(formData.contactPhone) ? '' : t('电话格式不正确') : ''}
                >
                  <Input
                    placeholder={t('联系人电话')}
                    type='tel'
                    value={formData.contactPhone}
                    onChange={(val) => handleChangeInput(val, 'contactPhone')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('联系人邮箱')}
                  status={formData.contactEmail ? isEmail(formData.contactEmail) ? '' : 'error' : ''}
                  message={formData.contactEmail ? isEmail(formData.contactEmail) ? '' : t('邮箱格式不正确') : ''}
                >
                  <Input
                    placeholder={t('联系人邮箱')}
                    type='email'
                    value={formData.contactEmail}
                    onChange={(val) => handleChangeInput(val, 'contactEmail')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
                <Form.Item
                  label={t('联系地址')}
                >
                  <Input
                    placeholder={t('联系地址')}
                    type='text'
                    value={formData.contactAddress}
                    onChange={(val) => handleChangeInput(val, 'contactAddress')}
                    style={{ width: '300px' }}
                  />
                </Form.Item>
              </Form>
              <Form.Action>
                <Button type="primary" onClick={submitForm}>{t('保存')}</Button>
                <Button onClick={cancel}>{t('取消')}</Button>
              </Form.Action>
            </Card.Body>
          </Card>
        </div>
      }
    </>

  )
}
export default UserInfo

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common']))
    }
  }
}

UserInfo.getLayout = function GetLayout (page) {
  const { t } = useTranslation('common')

  return (
    <AccountCenter headTitle={t('用户信息')}>{page}</AccountCenter>
  )
}

