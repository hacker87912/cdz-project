import { useMemo } from 'react'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import CenterLayout from '@/components/centerLayout'
import { useTranslation } from 'next-i18next'
import { Layout } from 'tea-component'
import styles from './index.module.scss'

const Body = Layout.Content.Body

export default function AccountCenter ({ children, ...rest }) {
  const { t } = useTranslation('common')
  const menus = useMemo(() => (
    [
      {
        label: t('用户信息'),
        key: '/account/user'
      }
    ]
  ), [t])

  return (
    <CenterLayout title={t('账号信息')} menus={menus} {...rest}>
      <div className={styles['account-center']}>
        {rest.isContentHeader === false ? children : (
          <Body>
            {children}
          </Body>
        )}
      </div>
    </CenterLayout>
  )
}

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
    }
  }
}
