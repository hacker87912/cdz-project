import React from 'react'
import { observer } from 'mobx-react-lite'
import Image from 'next/image'
import PageLayout from '@/components/layout'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import televisionImg from '@/assets/img/television.png'
import earphoneSvg from '@/assets/img/earphone.svg'
import positioningSvg from '@/assets/img/positioning.svg'
import { Button, Form, Input, List, message } from 'antd'
import { PhoneFilled, HomeFilled, MailFilled, CustomerServiceFilled, FlagFilled } from '@ant-design/icons'
import * as API from '@/services'

const validateMessages = {
  required: '${label}是必须填的',
  types: {
    email: '${label}不是有效的邮箱',
    string: '${label}不是有效的文字',
    number: '${label}不是有效的电话'
  },
}

const onFinish = async (values) => {
  const res = await API.addContactRecord(values)
  if (res.code === 0) {
    message.success(res.msg)
    window.location.reload()
  }
}

const ConsumerDetail = ()=> {
  const { t } = useTranslation('common')

  const data = [
    {
      key: '1',
      icon: <HomeFilled />,
      title: 'CDZ，B-20-1，20级，Menara UOA Bangsar，5号，Jalan Bangsar Utama，59000吉隆坡',
    },
    {
      key: '2',
      icon: <PhoneFilled />,
      title: '+603-2299 1234/2287 1234',
    },
    {
      key: '3',
      icon: <MailFilled />,
      title: 'suggest@cdz.com',
    },
    {
      key: '4',
      icon: <CustomerServiceFilled />,
      title: '+603-2299 4567',
    },
    {
      key: '5',
      icon: <FlagFilled />,
      title: <iframe src={t('谷歌地图链接')} className={styles['map']} loading="lazy"></iframe>,
    },
  ]

  return (
    <PageLayout title={t('联系我们')}>
      <div className={styles['page-consumerdetail']}>
        {/* 头部区域 */}
        <div className={styles['header-banner']}>
          <div className={styles['container']}>
            <div className={styles['container-left']}>
              <div className={styles['title']}>
                <span>{t('联系我们')}</span>
              </div>
              <div className={styles['description']}>{t('请随时直接使用以下表格向我们发送消息，或通过我们提供的联系方式与我们联系')}</div>
            </div>
            <div className={styles['container-right']}>
              <Image alt='promotion' src={televisionImg} />
            </div>
          </div>
        </div>
        <div className={styles['content']}>
          <div className={styles['title']}>
            <Image alt='promotion' src={earphoneSvg} />
            <span>{t('联系我们')}</span>
          </div>
          <Form
            size="large"
            labelCol={{
              span: 8,
            }}
            wrapperCol={{
              span: 16,
            }}
            name="nest-messages"
            onFinish={onFinish}
            style={{
              maxWidth: 600,
              marginTop: '20px'
            }}
            validateMessages={validateMessages}
          >
            <Form.Item
              name="fullName"
              label={t('姓名')}
              rules={[
                {
                  required: true,
                  type: 'string',
                  whitespace: true,
                  message: t('姓名是必填的')
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="mail"
              label={t('电子邮箱')}
              rules={[
                {
                  required: true,
                  type: 'string',
                  message: t('电子邮箱是必填的')
                },
                {
                  type: 'email',
                  message: t('电子邮箱填写格式不正确')
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="phone"
              label={t('联系电话')}
              rules={[
                {
                  required: true,
                  type: 'string',
                  message: t('联系电话是必填的')
                },
                {
                  message: t('联系电话填写格式不正确'),
                  pattern: new RegExp(/^[0-9,.+_\- /\\()]{4,30}$/, "g")
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="company"
              label={t('公司')}
              rules={[
                {
                  required: true,
                  type: 'string',
                  whitespace: true,
                  message: t('公司是必填的')
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="remark"
              label={t('您的信息')}
              rules={[
                {
                  required: true,
                  type: 'string',
                  whitespace: true,
                  message: t('您的信息是必填的')
                },
              ]}
            >
              <Input.TextArea />
            </Form.Item>
            <Form.Item
              wrapperCol={{
                offset: 8,
              }}
            >
              <Button type="primary" htmlType="submit">
                {t('提交')}
              </Button>
            </Form.Item>
          </Form>
          <div className={styles['title']}>
            <Image alt='promotion' src={positioningSvg} />
            <span>{t('公司地址和号码')}</span>
          </div>
          <List
            style={{ marginLeft: '77px' }}
            dataSource={data}
            renderItem={(item) => (
              <List.Item>
                <List.Item.Meta
                  avatar={item.icon}
                  title={item.title}
                />
              </List.Item>
            )}
          />
        </div>
      </div>
    </PageLayout>
  )
}

export default observer(ConsumerDetail)

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common']))
    }
  }
}
