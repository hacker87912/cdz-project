import Document, { Html, Head, Main, NextScript } from 'next/document'
import Script from 'next/script'

class MyDocument extends Document {
  static async getInitialProps (ctx) {
    const initialProps = await Document.getInitialProps(ctx)
    return { ...initialProps, locale: ctx.locale || 'zh' }
  }

  render () {
    return (
      <Html lang={this.props.locale}>
        <Head />
        <body>
          <Main />
          <NextScript />
          <Script
            src='/jigsaw.min.js'
            strategy='beforeInteractive'
          />
        </body>
      </Html>
    )
  }
}

export default MyDocument
