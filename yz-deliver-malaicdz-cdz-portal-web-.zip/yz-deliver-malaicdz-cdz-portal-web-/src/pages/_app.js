import React from 'react'
import App from 'next/app'
import Head from 'next/head'
import { StoreProvider } from '@/store'
import '@/utils/request'
import '@/styles/iconfont/iconfont.css'
import { getNavEntrance, getNavList, getBottomNav, getTermsVersion } from '@/services'
import { appWithTranslation } from 'next-i18next'
import 'tea-component/dist/tea.css'
import '@/styles/global.scss'
import 'moment/locale/zh-cn'
import { ConfigProvider } from 'antd'
import { ConfigProvider as TeaConfigProvider } from "tea-component"
import enUS from 'antd/locale/en_US'
import zhCN from 'antd/locale/zh_CN'
import tea_enUS from 'tea-component/lib/i18n/locale/en_US'
import tea_zhCN from 'tea-component/lib/i18n/locale/zh_CN'
import { useRouter } from 'next/router'

function MyApp ({ Component, pageProps, initialState }) {
  const router = useRouter()
  const getLayout = Component.getLayout || ((page) => page)
  const locale = router.locale === 'zh' ? zhCN : enUS
  const tea_locale = router.locale === 'zh' ? tea_zhCN : tea_enUS

  return (
    <>
      <Head>
        <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no' />
        <meta name='theme-color' content='#000000' />
      </Head>
      <StoreProvider initialState={initialState}>
        <ConfigProvider locale={locale}>
          <TeaConfigProvider locale={tea_locale}>
            {getLayout(<Component {...pageProps} />)}
          </TeaConfigProvider>
        </ConfigProvider>
      </StoreProvider>
    </>
  )
}
MyApp.getInitialProps = async (appContext) => {
  const appProps = await App.getInitialProps(appContext)
  // const cookies = appContext.ctx.req.cookies
  const footNavData = await getFooterData(appContext.ctx)
  const headerData = await getHeaderData('', appContext.ctx)
  const { data: { detail: version = '' }  } = await getTermsVersion({}, appContext.ctx)
  appProps.initialState = { footNavData, headerData, version }
  return appProps
}
export default appWithTranslation(MyApp)

async function getFooterData (appContext) {
  const res = await getBottomNav({}, appContext)
  return res.data?.map(e => {
    const { name, bottomNavigationList, id } = e
    return {
      id,
      name,
      children: bottomNavigationList.map(v => ({ name: v.name, url: v.url, id: v.id }))
    }
  }) || []
}

export async function getHeaderData (keyword = '', appContext) {
  const entranceData = await getNavEntrance({}, appContext)
  const res = await Promise.all(entranceData.data?.map(e => getNavList({ id: e.id, keyword }, appContext)) || [])
  const data = entranceData.data?.map((e, i) => ({ name: e.name, data: res[i].data, id: e.id })) || []
  const pcData = data.map(e => {
    return {
      id: e.id,
      title: e.name,
      panelData: {
        left: [e.name, '查看更多'],
        right: e.data?.map(v => [v.name, ...v.topNavigationList])
      },
    }
  })
  const mobileData = data.map(e => {
    return {
      id: e.id,
      name: e.name,
      children: e.data.map((v) => ({ id: `${v.id}${Math.random()}`, name: v.name, children: v.topNavigationList }))
    }
  })
  return { pcData, mobileData }
}
