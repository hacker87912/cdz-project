import React, { useState } from 'react'
import { observer } from 'mobx-react-lite'
// import Image from 'next/image'
import PageLayout from '@/components/layout'
import styles from './index.module.scss'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import { useTranslation } from 'next-i18next'
import { Layout, Menu, Typography } from 'antd'
import { useRouter } from 'next/router'
import * as API from '@/services'

const { Title, Paragraph } = Typography
const { Sider, Content, Header } = Layout

const Clause = ({ serviceData, policyData })=> {
  const router = useRouter()
  const { t } = useTranslation('common')
  const { index } = router.query
  const [curIndex, setCurIndex] = useState(index)
  // 电脑端布局
  const pc = () => {
    return <Layout className={styles['pc-clause']}>
      <Sider theme="light">
        <Menu
          style={{position: "sticky", top: "60px"}}
          selectedKeys={[curIndex]}
          onClick={({key})=>{setCurIndex(key),router.push(`/clause/${key}`)}}
          items={[
            {label: t('服务条款'), key: 'service'},
            {label: t('隐私政策'), key: 'policy'}
          ]}
        />
      </Sider>
      <Content className={styles['content']}>
        {curIndex ==='service' && <TermService data={serviceData} t={t} />}
        {curIndex ==='policy' && <PrivacyPolicy data={policyData} t={t} />}
      </Content>
    </Layout>
  }

  // 移动端布局
  const mobile = () => {
    return <Layout hasSider={false} className={styles['mobile-clause']}>
      <Header theme="light">
        <Menu
          mode="horizontal"
          style={{position: "sticky", top: "60px"}}
          selectedKeys={[curIndex]}
          onClick={({key})=>{setCurIndex(key),router.push(`/clause/${key}`)}}
          items={[
            {label: t('服务条款'), key: 'service'},
            {label: t('隐私政策'), key: 'policy'}
          ]}
        />
      </Header>
      <Content className={styles['content']}>
        {curIndex ==='service' && <TermService data={serviceData} t={t} />}
        {curIndex ==='policy' && <PrivacyPolicy data={policyData} t={t} />}
      </Content>
    </Layout>
  }

  return <PageLayout title={t('条款政策')}>
    <div className={styles['page-clause']}>
      {pc()}
      {mobile()}
    </div>
  </PageLayout>
}

// 服务条款
const TermService = ({ data, t }) => {
  const { updateTime = '', detail = '' } = data
  return (
    <Typography>
      <Title>{t('服务条款')}</Title>
      <Paragraph>
        {t('最近一次更新')}：{updateTime}
      </Paragraph>
      <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: detail }}></div>
    </Typography>
  )
}

// 隐私政策
const PrivacyPolicy = ({ data, t }) => {
  const { updateTime = '', detail = '' } = data
  return (
    <Typography>
      <Title>{t('隐私政策')}</Title>
      <Paragraph>
        {t('最近一次更新')}：{updateTime}
      </Paragraph>
      <div className='editor-content-view' dangerouslySetInnerHTML={{ __html: detail }}></div>
    </Typography>
  )
}



export default observer(Clause)

export async function getServerSideProps (context) {
  const locale = context.locale || 'zh'
  const { data: serviceData = {} } = await API.getTermsService({}, context)
  const { data: policyData = {} } = await API.getTermsPolicy({}, context)
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
      serviceData,
      policyData
    }
  }
}
