// pages/404.js
export default function Custom404 () {
  return <h1>404 - The page cannot be found, please check the access address</h1>
}
