import React, { useEffect, useState } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import Image from 'next/image'
import Link from 'next/link'
import PageLayout from '@/components/layout'
import styles from './index.module.scss'
import { useTranslation } from 'next-i18next'
import { serverSideTranslations } from 'next-i18next/serverSideTranslations'
import * as API from '@/services'
import { Swiper, SwiperSlide } from "swiper/react"
import 'swiper/css'
import 'swiper/css/pagination'
import { Autoplay, Pagination } from "swiper"

function Home ({ homeData }) {
  const router = useRouter()
  const { t } = useTranslation('common')
  const [slidesPerView, setSlidesPerView] = useState(4)
  const [spaceBetween, setSpaceBetween] = useState(30)
  useEffect(() => {
    if (document.body.clientWidth < 768) {
      setSlidesPerView(1.5)
      setSpaceBetween(20)
    }
  }, [])
  const autoplay={
    delay: 2500,
    disableOnInteraction: false,
  }
  const pagination = {
    clickable: true,
    renderBullet: function (index, className) {
      return '<span class="' + className + '"></span>'
    },
  }
  // banner跳转
  const bannerGoto = (url) => {
    if (url) {
      window.open(url.includes('http') ? url : `http://${url}`, '_')
    }
  }
  // 跳转产品详情
  const gotoProductDetail = (id) => {
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/product/${id}`
  }
  // 跳转客户详情
  const gotoConsumerDetail = (id) => {
    const localePath = router.locale === 'en' ? 'en' : ''
    window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/consumer/${id}`
  }
  return (
    <PageLayout>
      <Head>
        <title>{t('门户')}</title>
      </Head>
      <div className={styles['home-page']}>
        <div className={styles['banner-container']}>
          <Swiper
            autoplay={autoplay}
            pagination={pagination}
            modules={[Autoplay, Pagination]}
            effect="fade"
            className={styles['banner-list']}
          >
            {
              homeData.bannerData.map(bannerItem => (
                <SwiperSlide key={bannerItem.id}>
                  <div className={styles['banner-item']}>
                    <a className={styles['item-img']} onClick={() => bannerGoto(bannerItem.url)}>
                      <Image
                        src={bannerItem.cosUrl}
                        alt="Picture of the author"
                        fill
                        sizes='100%'
                        priority
                      />
                    </a>
                    {/* <div className={styles['item-desc']}>
                      <h1>{bannerItem.title}</h1>
                      <p>{bannerItem.desc}</p>
                      <Button type='primary' className={styles['buy-btn']} onClick={gotoBuy}>立即购买</Button>
                    </div> */}
                  </div>
                </SwiperSlide>
              ))
            }
          </Swiper>
        </div>
        <div className={styles['product-container']}>
          <div className={styles['product']}>
            <div className={styles['title']}>{t('优势产品')}</div>
            <div className={styles['content']}>
              <ul className={styles['product-list']}>
                {
                  homeData.productData.map(productItem => (
                    <li className={styles['product-item']} key={productItem.classify}>
                      <div className={styles['img-name']}>
                        {/* <div className={styles['img']}>
                          <Image
                            src={productItem.img}
                            alt='Picture of the author'
                            fill
                            priority
                          />
                        </div> */}
                        <div className={styles['name']}>{productItem.classifyName}</div>
                      </div>
                      <div className={styles['txt-list']}>
                        {
                          productItem.productList?.map(listItem => (
                            <p key={listItem.productId}><a onClick={() => gotoProductDetail(listItem.productId)}>{listItem.productName}</a></p>
                          ))
                        }
                      </div>
                    </li>
                  ))
                }

              </ul>
            </div>
          </div>
        </div>
        <div className={styles['product-container']}>
          <div className={styles['consumer']}>
            <div className={styles['title']}>{t('客户案例')}</div>
            <div className={styles['content']}>
              <div className="swiper-content">
                <Swiper
                  slidesPerView={slidesPerView}
                  spaceBetween={spaceBetween}
                  className={styles['consumer-list']}
                >
                  {
                    homeData.customerExpandData.map(customerItem => (
                      <SwiperSlide key={customerItem.id}>
                        <li className={styles['consumer-item']} key={customerItem.id}>
                          <div className={styles['consumer-img']}>
                            <Image
                              src={customerItem.cosUrl}
                              alt='Picture of the author'
                              fill
                              priority
                              sizes='100%'
                            />
                          </div>
                          <div className={styles['consumer-content']}>
                            <div className={styles['logo']}>
                              <Image
                                src={customerItem.logoUrl}
                                alt='Picture of the author'
                                fill
                                priority
                                sizes='100%'

                              />
                            </div>
                            <div className={styles['title']}>{customerItem.title}</div>
                            <div className={styles['desc']}>{customerItem.subTitle}</div>
                            <div className={styles['more']}>
                              <a onClick={() => gotoConsumerDetail(customerItem.id)}>{t('了解更多')}&gt;</a>
                            </div>
                          </div>

                        </li>
                      </SwiperSlide>
                    ))
                  }

                </Swiper>
              </div>
              <div className={styles['logo-content']}>
                <ul className={styles['logo-list']}>
                  {
                    homeData.customerNoExpandData.map(customerItem => (
                      <li className={styles['logo-item']} key={customerItem.id}>
                        <a onClick={() => gotoConsumerDetail(customerItem.id)}>
                          <Image
                            src={customerItem.logoUrl}
                            alt='Picture of the author'
                            fill
                            priority
                            sizes='100%'
                          />
                        </a>
                      </li>
                    ))
                  }
                </ul>
              </div>
            </div>
          </div>

        </div>
        <div className={styles['more-active']}>
          <div className={styles['left']}>
            <p>
              <Link href='/home' className={styles['more']}>
                <span>{t('更多优惠活动')}</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="12" viewBox="0 0 15 12" fill="none">
                  <path
                    d="M7 1.48679L8.58871 0L15 6L8.58871 12L7 10.5132L10.8921 7H0V5H10.8921L7 1.48679Z"
                    fill="#ffffff">
                  </path>
                </svg>
              </Link>
            </p>
            <p>{t('海量优惠套餐，为您提供全方位的上云实践服务')}</p>
          </div>
          <div className={styles['right']}>
            <Image
              src='https://staticintl.cloudcachetci.com/cms/backend-cms/EZ67358_FASh583_wecom-temp-a412b18fc807dceef4b726c836ed898b.png'
              alt='Picture of the author'
              fill
              priority
              sizes='100%'
            />
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
export default Home

export async function getServerSideProps (context) {
  // banner
  const resBanner = await API.getBanner({}, context)
  const bannerData = resBanner.data || []
  // product
  const resProduct = await API.getProduct({}, context)
  const productData = resProduct.data || []
  // customer expand
  const resCustomerExpand = await API.getCustomerExpand({}, context)
  const customerExpandData = resCustomerExpand.data || []
  // customer noexpand
  const resCustomerNoExpand = await API.getCustomerNoExpand({}, context)
  const customerNoExpandData = resCustomerNoExpand.data || []
  const locale = context.locale || 'zh'
  const homeData = {
    bannerData,
    productData,
    customerExpandData,
    customerNoExpandData
  }
  return {
    props: {
      ...(await serverSideTranslations(locale , ['common'])),
      homeData
    }
  }
}
