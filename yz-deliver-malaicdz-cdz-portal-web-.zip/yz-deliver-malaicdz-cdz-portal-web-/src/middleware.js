import { NextResponse } from 'next/server'

export const config = {
  matcher: ['/account/:path*', '/expense/:path*', '/messagecenter/:path*']
}
export function middleware (req) {
  const Authorization = req.cookies.get('Authorization')?.value
  if (!Authorization) {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    return NextResponse.redirect(url, req.url)
  }
}
