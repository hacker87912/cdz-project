import { makeAutoObservable } from 'mobx'
import { enableStaticRendering } from 'mobx-react-lite'

enableStaticRendering(typeof window === 'undefined')

class GlobalStore {
  constructor () {
    makeAutoObservable(this)
  }
  // 顶部导航数据
  headerData = {}
  copyHeaderData = {}
  // 底部导航数据
  footNavData = []
  version = ''
  setFootNavData = (data) => {
    this.footNavData = data
  }
  setHeaderData = (data) => {
    this.headerData = data
  }
  setCopyHeaderData = (data) => {
    this.copyHeaderData = data
  }
  setVersion = (data) => {
    this.version = data
  }
  // ssr后初始化数据
  hydrate = (initialState = {}) => {
    const { footNavData, headerData, version } = initialState
    this.setFootNavData(footNavData)
    this.setHeaderData(headerData)
    this.setCopyHeaderData(headerData)
    this.setVersion(version)
  }
}
const globalStore = new GlobalStore()
export default globalStore
