import { createContext, useContext } from 'react'
import global from './global'

const comboStore = {
  global
}
const StoreContext = createContext()
let store

export function useStore () {
  const context = useContext(StoreContext)

  if (!context) {
    throw new Error('useStore error')
  }

  return context
}

export function StoreProvider ({ children, initialState }) {
  const store = initializeStore(initialState)

  return <StoreContext.Provider value={store}>{children}</StoreContext.Provider>
}

function initializeStore (initialState = null) {
  const _store = store ?? comboStore
  // 水合每个store数据
  if (initialState) {
    for (const item in _store) {
      _store[item]?.hydrate(initialState)
    }
  }
  // ssr返回一个新的store
  if (typeof window === 'undefined') return _store
  // 客户端只创建一次
  if (!store) store = _store

  return _store
}
