import { $get, $post } from '@/utils/request'

// 登录
export const login = (data = {}, context = null) => $post('/cdz-auth/portal/login', data, context)
export const logout = (data = {}, context = null) => $post('/cdz-auth/portal/logout', data, context)

// 账户中心
export const getAccountInfo = (data = {}, context = null) => $get(`/cdz-auth/portal/account/info/${data.id}`, {}, context)
export const editAccountInfo = (data = {}, context = null) => $post('/cdz-auth/portal/account/update', data, context)
export const getDicData = (data = {}) => $post('/cdz-auth/common/dict/key/getList', data)

//控制台
export const getConsole = (data = {}, context = null) => $get('/cdz-auth/portal/console', data, context)


// 重置密码
export const resetPasswordEmail = (data = {}, context = null) => $post('/cdz-auth/reset-password/sendResetPasswordEmail', data, context)
export const checkCode = (data = {}, context = null) => $get('/cdz-auth/reset-password/checkCode', data, context)
export const verificationCode = (data = {}, context = null) => $get('/cdz-auth/reset-password/verificationCode', data, context)
export const resetSubmit = (data = {}, context = null) => $post('/cdz-auth/reset-password/submit', data, context)


// 首页
export const getBanner = (data = {}, context = null) => $get('/cdz-cms/portal/query/release/slideshow', data, context)
export const getProduct = (data = {}, context = null) => $get('/cdz-cms/portal/query/release/superior', data, context)
export const getCustomerExpand = (data = {}, context = null) => $get('/cdz-cms/portal/query/release/expand/customer', data, context)
export const getCustomerNoExpand = (data = {}, context = null) => $get('/cdz-cms/portal/query/release/unexpanded/customer', data, context)
export const getCustomerDetail = (data = {}, context = null) => $get(`/cdz-cms/portal/query/release/customer/${data.id}`, {}, context)


export const getNavEntrance = (data = {}, context = null) => $get('/cdz-cms/portal/navigation/top/entrance/list', data, context)
export const getNavList = (data = {}, context = null) => $get(`/cdz-cms/portal/navigation/top/list?id=${data.id}&keyword=${data.keyword}`, {}, context)
export const getBottomNav = (data = {}, context = null) => $get('/cdz-cms/portal/navigation/bottom/list', data, context)

export const getProductList = (data = {}, context = null) => $get(`/cdz-cms/portal/product/list?keyword=${data.keyword}&classify=${data.classify}`, {}, context)
export const getProductClassify = (data = {}, context = null) => $get('/cdz-cms/portal/product/classify/list', data, context)
export const getProductDetail = (data = {}, context = null) => $get(`/cdz-cms/portal/product/detail/${data.id}`, {}, context)

export const getPricingList = (data = {}, context = null) => $get(`/cdz-cms/portal/product/pricing/list?classify=${data.classify}`, {}, context)
export const getPricingClassify = (data = {}, context = null) => $get('/cdz-cms/portal/product/pricing/classify/list', data, context)
export const getPricingDetail = (data = {}, context = null) => $get(`/cdz-cms/portal/product/pricing/detail/${data.id}`, {}, context)

export const addContactRecord = (data = {}, context = null) => $post('/cdz-auth/portal/contact-record/add', data, context)

export const getTermsService = (data = {}, context = null) => $get('/cdz-cms/portal/terms/query/service', data, context)
export const getTermsPolicy = (data = {}, context = null) => $get('/cdz-cms/portal/terms/query/policy', data, context)
export const getTermsVersion = (data = {}, context = null) => $get('/cdz-cms/portal/terms/query/version', data, context)

export const getNotificationList = (data = {}, context = null) => $get(`/cdz-cms/portal/notification/getPageList?current=${data.current}&size=${data.size}&key=${data.key}`, {}, context)
export const getNotificationDetail = (data = {}, context = null) => $get(`/cdz-cms/portal/notification/getDetailById?id=${data.id}`, {}, context)



