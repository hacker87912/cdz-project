import axios from 'axios'
import { getCookie } from '@/utils/storage'
import { message } from 'antd'

const __isBrowser__ = typeof window === 'object'
let nextContext = null

// 创建axios实例
const instance = axios.create({
  baseURL: __isBrowser__ ? '/api' : `${process.env.API_HOST}`,
  headers: {
    'CDZ-VERSION': 'v1.0.0'
  }
})
// 拦截请求头
instance.interceptors.request.use(
  config => {
    let Authorization = '', locale = ''
    if (__isBrowser__) {
      Authorization = getCookie('Authorization')
      locale = location.pathname.includes('en/') ? 'en' : 'zh'
    } else {
      Authorization = nextContext.req.cookies['Authorization']
      locale = nextContext.locale
    }
    config.headers['Authorization'] = Authorization
    config.headers['Content-Language'] = locale
    return config
  },
  error => {
    console.error('axios request error!!!')
    return error
  }
)
// 拦截响应头
instance.interceptors.response.use(
  response => {
    if (response.status === 200) {
      return Promise.resolve(response)
    } else {
      return Promise.reject(response)
    }
  },
  error => {
    console.error('axios response error!!!')
    return Promise.reject(error.response)
  }
)
// 请求成功处理
const sucFun = res => {
  if (res.data?.code !== 0) {
    if (__isBrowser__) {
      message.error(res.data?.msg || 'data error')
    } else {
      nextContext?.res.status(500).send('<h1>Failed to request page data<h1>')
    }
  }
  console.log(res.data)
  return res.data || {}
}
// 请求失败处理
const errFun = (err = {}) => {
  console.log(err.data)
  if (__isBrowser__) {
    if (err.status === 401) {
      // message.error('Expired authentication or no permissions')
      const localePath = location.pathname.includes('en/') ? 'en' : ''
      window.location.href = `${window.location.origin}${process.env.NEXT_PUBLIC_PATH}/${localePath}/login?s_url=unauthorized`
    } else {
      message.error(`Request error, http status code ${err.status}`)
    }
  } else {
    if (err.status === 401) {
      const localePath = nextContext.locale === 'en' ? 'en' : ''
      nextContext?.res.redirect(`${process.env.NEXT_PUBLIC_PATH}/${localePath}/login?s_url=unauthorized`)
    } else {
      nextContext?.res.status(500).send('<h1>Failed to request page data<h1>')
    }
  }
  return err.data || {}
}

export const $post = (url = '', data = {}, context = null) => {
  nextContext = context
  return instance.post(url, data).then(sucFun).catch(errFun)
}
export const $get = (url = '', data = {}, context = null) => {
  nextContext = context
  return instance.get(url, {params: data}).then(sucFun).catch(errFun)
}
