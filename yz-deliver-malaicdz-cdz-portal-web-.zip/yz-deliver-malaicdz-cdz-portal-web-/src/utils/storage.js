export function getItem (k) {
  let value = ''
  try {
    value = JSON.parse(localStorage.getItem(k))
  } catch (e) {
    console.log(e)
  }
  return value
}

export function setItem (k, v) {
  localStorage.setItem(k, JSON.stringify(v))
}

export function removeItem (k) {
  localStorage.removeItem(k)
}

export function clearAll () {
  localStorage.clear()
}

export function setCookie (cname, cvalue, exhours) {
  var d = new Date()
  d.setTime(d.getTime() + (exhours * 60 * 60 * 1000))
  var expires = 'expires=' + d.toGMTString()
  document.cookie = cname + '=' + cvalue + '; ' + 'path=/;' + expires
}

export function getCookie (cname)
{
  var name = cname + "="
  var ca = document.cookie.split(';')
  for(var i=0; i<ca.length; i++)
  {
    var c = ca[i].trim()
    if (c.indexOf(name)==0) return c.substring(name.length,c.length)
  }
  return ""
}

export function clearAllCookie () {
  var cookies = document.cookie.split(";")
  for (var i = 0; i < cookies.length; i++) {
    var cookie = cookies[i]
    var eqPos = cookie.indexOf("=")
    var name = eqPos > -1 ? cookie.substring(0, eqPos) : cookie
    document.cookie = name + "=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT"
  }
}
