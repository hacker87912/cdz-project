package com.cdz.common.swagger.annotation;

import com.cdz.common.swagger.config.CdzSwaggerAutoConfiguration;
import com.cdz.common.swagger.support.SwaggerProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@EnableConfigurationProperties(SwaggerProperties.class)
@Import({CdzSwaggerAutoConfiguration.class})
public @interface EnableSwaggerDoc {

}
