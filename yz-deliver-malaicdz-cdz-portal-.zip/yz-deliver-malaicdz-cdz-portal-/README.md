#cdz-portal

马来西亚CDZ云管项目

采用技术：

> SpringCloud Alibaba + Mysql8.0 + Redis + TDMQ + Nacos + MyBatis plus

# cdz架构
https://docs.qq.com/flowchart/DU2taWWRGelRpd25J

## swagger

```markdown
开发环境文档地址： 
```

## cdz模块说明
```lua

cdz-portal
└── cdz-common -- 系统公共模块
     ├── cdz-common-parent -- 全局依赖管理控制
     ├── cdz-common-core -- 公共工具类核心包
     ├── cdz-common-datasource -- 动态数据源包
     ├── cdz-common-job -- xxl-job 封装
     ├── cdz-common-log -- 日志服务
     ├── cdz-common-mybatis -- mybatis 扩展封装
     ├── cdz-common-swagger -- 接口文档
├── cdz-gateway -- Spring Cloud Gateway网关[8088]
├── cdz-auth -- 用户服务[8081]
├── cdz-order -- 订单服务[8082]
├── cdz-xxxx -- 计费服务[8083]
```

## 代码模块规范
- common 公共工具和静态类型资源
- api 服务门面层
- service 业务实现层
- dao 数据模型层
- manager 通用业务处理层
- web 前置层和服务启动层

## 分支管理
功能开发分支： dev
开发同学基于dev分支创建特性分支进行开发，开发完成再提交dev合并请求

## 代码提交规范

feat：提交新功能

fix：修复了bug

docs：只修改了文档

style：调整代码格式，未修改代码逻辑（比如修改空格、格式化、缺少分号等）

refactor：代码重构，既没修复bug也没有添加新功能

perf：性能优化，提高性能的代码更改

test：添加或修改代码测试

chore：对构建流程或辅助工具和依赖库（如文档生成等）的更改

## nacos配置中心

- 访问地址： 

## 代码生成工具
- mybatis plus文档：https://baomidou.com/