package com.cdz.auth.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author RachelHwang
 * @version 1.0.0
 * @description: 运营用户控制层
 * @date 2023/2/14 14:38
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/operator")
@Tag(name = "运营人员管理模块")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class UserController {

    @RequestMapping("/login")
    public String require() {
        return "str";
    }
}
