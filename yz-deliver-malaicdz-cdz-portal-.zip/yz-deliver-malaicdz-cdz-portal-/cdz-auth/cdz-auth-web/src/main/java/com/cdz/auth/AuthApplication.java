package com.cdz.auth;

import com.cdz.common.swagger.annotation.EnableSwaggerDoc;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author RachelHwang
 * @version 1.0.0
 * @description: 用户服务启动类
 * @date 2023/2/14 00:56
 */
@EnableSwaggerDoc
@EnableDiscoveryClient
@ComponentScan(basePackages = {"com.cdz.auth.*"})
@SpringBootApplication
public class AuthApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthApplication.class, args);
    }
}
